
export class Accyear {
  departmentId: String;
  startYear: String;
  endYear: String;
  type: String;
  noOfYears: String;
  currentYear: String;
  currentSem: String;
  regulationId: String;
  id: String;
  regulation: String;
  etype: String;
}