import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssignmentModule } from 'projects/assignment/src/app/app.module';
import { CommentModule } from 'projects/comment/src/app/app.module';
import { CourseMaterialModule } from 'projects/courseMaterial/src/app/app.module';
import { NaacModule } from 'projects/naac/src/app/app.module';

const routes: Routes = [{

    path: '', redirectTo: 'naac/home', pathMatch: 'full' 
  },
  {
  path: 'naac',
  loadChildren: '../../projects/naac/src/app/app.module#NaacModule'
},
{
  path: 'assignment',
  loadChildren: '../../projects/assignment/src/app.module#AssignmentModule'
},
{
  path: 'coursematerial',
  loadChildren: '../../projects/coursematerial/src/app.module#CourseMaterialModule'
},

];

@NgModule({
  imports: [RouterModule.forRoot(routes), 
    // NaacSharedModule.forRoot(),
    // AssignmentSharedModule.forRoot(),
    // CourseMaterialSharedModule.forRoot(),
    // CommentSharedModule.forRoot(),
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
