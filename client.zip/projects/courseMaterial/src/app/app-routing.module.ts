import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeCourseMaterialComponent } from './_components/home-course-material/home-course-material.component';
import { StaffCourseMaterialComponent } from './_components/staff-course-material/staff-course-material.component';
import { StudentCourseMaterialComponent } from './_components/student-course-material/student-course-material.component';
import { AppComponent } from './app.component';


const routes: Routes = [
  
    {path:'', redirectTo:'home',pathMatch:'full'},
    {
    path: '', component: AppComponent, children: [
        { path: 'home', component: HomeCourseMaterialComponent },
        { path: 'staffCourseMaterial', component: StaffCourseMaterialComponent },
        { path: 'studentCourseMaterial', component: StudentCourseMaterialComponent }
    ]
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
