import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-move-students',
  templateUrl: './move-students.component.html',
  styleUrls: ['./move-students.component.css']
})
export class MoveStudentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
