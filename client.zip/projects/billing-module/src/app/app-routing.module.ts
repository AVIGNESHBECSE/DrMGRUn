import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { BillingCreateHomeComponent } from './_components/billing-create-home/billing-create-home.component';
import { FeesStructureComponent } from './_components/fees-structure/fees-structure.component';
import { BillingCreatePopupComponent } from './_components/billing-create-popup/billing-create-popup.component';
import { BillingNavbarComponent } from './_components/billing-navbar/billing-navbar.component';
import { FeesTypeSettingsComponent } from './_components/fees-type-settings/fees-type-settings.component';
import { FeesReportDateWiseComponent } from './_components/fees-report-date-wise/fees-report-date-wise.component';
import { PrintBillComponent } from './_components/print-bill/print-bill.component';
import { PaymentHistoryComponent } from './_components/payment-history/payment-history.component';
import { CreateEditFeesTypeComponent } from './_components/create-edit-fees-type/create-edit-fees-type.component';
import { CreateEditFeesStructureComponent } from './_components/create-edit-fees-structure/create-edit-fees-structure.component';
import { DayWiseBillReportComponent } from './_components/day-wise-bill-report/day-wise-bill-report.component';
import { BillingFilterComponent } from './_components/billing-filter/billing-filter.component';
import { BillingReportsComponent } from './_components/billing-reports/billing-reports.component';

const routes: Routes = [
  {path:'', redirectTo:'home',pathMatch:'full'},
  { path: '', component: AppComponent ,children:[
    { path:'home', component: BillingNavbarComponent,children:[
      {path:'',redirectTo:'createHome',pathMatch:'full'},
      { path: 'createHome', component: BillingCreateHomeComponent},
      { path: 'feeStructure', component: FeesStructureComponent},
      { path: 'feesTypeSettings', component: FeesTypeSettingsComponent},
      { path: 'feesReportDate', component: FeesReportDateWiseComponent},
      { path: 'dayWiseReport', component: DayWiseBillReportComponent},
      { path: 'filter',component:BillingFilterComponent},
      { path: 'reports',component:BillingReportsComponent}
      
      ] },
{path:'billPrint/:id',component:PrintBillComponent},
      { path: 'createPopup', component: BillingCreatePopupComponent},
      { path: 'paymentHistory', component: PaymentHistoryComponent},
      { path: 'createEditFeeStructure', component: CreateEditFeesStructureComponent},
      { path: 'createEditFeesType', component: CreateEditFeesTypeComponent}

  ]
}
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
