import { Component } from '@angular/core';
import { UserService } from 'src/services/UserService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'billingModule';
  currentUser: any;

  constructor(private userService :UserService){}
  ngOnInit() {
    this.getCurrentUser();
     
     
    }
    
  getCurrentUser(){
    this.userService.getCurrentUser().then((data:any)=>{
      this.currentUser = data;
    });
  }
}
