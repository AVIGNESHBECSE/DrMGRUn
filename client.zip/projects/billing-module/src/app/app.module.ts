import { BrowserModule } from '@angular/platform-browser';
import { ModuleWithProviders, NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { NgbAlertModule, NgbModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule, DatePipe } from '@angular/common';
import { CommonNavModule } from 'src/app/common/common-nav.module';
import { MainPipe } from 'src/app/common/pipe/main-pipe.module';
import { FeesStructureComponent } from './_components/fees-structure/fees-structure.component';
import { BillingCreateHomeComponent } from './_components/billing-create-home/billing-create-home.component';
import { BillingCreatePopupComponent } from './_components/billing-create-popup/billing-create-popup.component';
import { BillingNavbarComponent } from './_components/billing-navbar/billing-navbar.component';
import { FeeStructureImportComponent } from './_components/fee-structure-import/fee-structure-import.component';
import { FeesTypeSettingsComponent } from './_components/fees-type-settings/fees-type-settings.component';
import { FeesReportDateWiseComponent } from './_components/fees-report-date-wise/fees-report-date-wise.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PrintBillComponent } from './_components/print-bill/print-bill.component';
import { PaymentHistoryComponent } from './_components/payment-history/payment-history.component';
import { CreateEditFeesTypeComponent } from './_components/create-edit-fees-type/create-edit-fees-type.component';
import { CreateEditFeesStructureComponent } from './_components/create-edit-fees-structure/create-edit-fees-structure.component';
import { DayWiseBillReportComponent } from './_components/day-wise-bill-report/day-wise-bill-report.component';
import { BillingFilterComponent } from './_components/billing-filter/billing-filter.component';
import { BillingReportsComponent } from './_components/billing-reports/billing-reports.component';



// @NgModule({  declarations: []
// })
// export class BillingSharedModule {
//   static forRoot(): ModuleWithProviders<any> {
//     return {
//       ngModule: AppModule,
//       providers: []
//     }
//   }
// }
@NgModule({
  declarations: [
    AppComponent,
    FeesStructureComponent, 
    BillingCreateHomeComponent, 
    BillingCreatePopupComponent,
    BillingNavbarComponent,
    FeeStructureImportComponent,
    FeesTypeSettingsComponent,
    FeesReportDateWiseComponent,
    PrintBillComponent,
    PaymentHistoryComponent,
    CreateEditFeesTypeComponent,
    CreateEditFeesStructureComponent,
    DayWiseBillReportComponent,
    BillingFilterComponent,
    BillingReportsComponent
  ],
  imports: [
    // BrowserModule,
    AppRoutingModule,
    // HttpClientModule,
    NgbModule,
    FormsModule,
    RouterModule,

    NgbAlertModule,
    NgbTooltipModule,
    // BrowserAnimationsModule,
    CommonModule,
    CommonNavModule,
    MainPipe,
    BsDatepickerModule


  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class BillingModule { }
