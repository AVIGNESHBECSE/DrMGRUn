import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingFilterComponent } from './billing-filter.component';

describe('BillingFilterComponent', () => {
  let component: BillingFilterComponent;
  let fixture: ComponentFixture<BillingFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillingFilterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
