import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/services/StudentService';
import { BillingService } from 'src/services/BillingService';
import { UserService } from 'src/services/UserService';
import { DepartmentService } from 'src/services/DepartmentService';
import { AccyearService } from 'src/services/AccyearService';
import { GroupService } from 'src/services/GroupService';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { ManageStudentViewComponent } from 'projects/manage-student/src/app/_components/manage-student-view/manage-student-view.component';
import { PaymentHistoryComponent } from '../payment-history/payment-history.component';
@Component({
  selector: 'app-billing-filter',
  templateUrl: './billing-filter.component.html',
  styleUrls: ['./billing-filter.component.css']
})
export class BillingFilterComponent implements OnInit {

  primeFilters = ["Bills","PaymentInfo"]
  filters = ["Register Number","Student Name","Department"];
  filterBills = ["Register Number","Bill Number"];
  filterBill:any;
  primeFilter:any;
  filter:any;
  registerNumber:any;
  studentData: any;
  paymentInfo: any;
  allStudents: any;
  allDegDepDatas: any;
  accyearList: any;
  groups: any;
  students: any;
  deptId:any;
  accYearId:any;
  group:any;
  filteredBills: any;
  field: any;
  value: any;
  billNumber: any;
  constructor(private studentService:StudentService,private billingService:BillingService,private userService:UserService,
    private departmentService:DepartmentService,private accYearService:AccyearService,private groupService:GroupService,
    private modalService:NgbModal,private router:Router) { }

  ngOnInit(): void {
  }

  showDiv(type)
  {
     if(type == "Student Name")
     {
        this.getAllStudents();
     }
     if(type == "Department")
     {
      this.getDepts();
     }
  }

  getAllStudents(){
    this.userService.getAllStudents().then((data:any)=>{
      this.allStudents=data;
    })
  }

  getDepts(){
      this.departmentService.getDepartment().then((data:any)=>{
        this.allDegDepDatas = data;
      })
  }
    getAccyears(deptId){
      this.accYearService.getAcademicByDep(deptId).then((data:any)=>{
        this.accyearList=data;
      })
    }
    getGroups(accyearId){
      this.groupService.getGroupByAccId(accyearId).then((data:any)=>{
        this.groups=data;
      })
    }
    getStudentList(grp){
      this.groupService.getStudents(grp.id).then((data:any)=>{
        this.students=data;
      })
    }
  
  getFilterData()
  {
      this.studentService.getStudentByRegNo(this.registerNumber).then((data:any)=>{
        this.studentData = data;
        if(this.studentData != null)
        {
          this.getPaymentInfo(this.studentData[0].id);
        }
      })
  }

  getPaymentInfo(stdId)
  {
      this.billingService.getPaymentInfo(stdId).then((data:any)=>{
      this.paymentInfo = data;
      this.paymentInfo.sort((a, b) => {
      return parseInt(b.sem) - parseInt(a.sem);
      });
      })
  }

  getFilterData2()
  {
    if(this.filterBill == "Register Number")
    {
      this.studentService.getStudentByRegNo(this.registerNumber).then((data:any)=>{
        this.studentData = data;
        if(this.studentData != null)
        {
          this.field = "studentId";
          this.value = this.studentData[0].id;

          this.getBillsByFilter(this.field,this.value);
        }
      })
    }
    if(this.filterBill == "Bill Number")
    {
       this.field = "billNumber";
       this.value = this.billNumber;
       this.getBillsByFilter(this.field,this.value);
    }
  }

  getBillsByFilter(field,value)
  {
    this.billingService.getBillsByFilter(field,value).then((data:any)=>{
      this.filteredBills = data;

    })
  }

viewStudent(studentId)
{
 const modalRef = this.modalService.open(PaymentHistoryComponent, { size: "xl", backdrop: 'static' });
 modalRef.componentInstance.studentId = studentId;
}

print(billId){
  this.router.navigate(['/billing-module/billPrint/'+ billId]);
}

}
