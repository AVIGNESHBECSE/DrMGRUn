import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BillingService } from 'src/services/BillingService';

@Component({
  selector: 'app-print-bill',
  templateUrl: './print-bill.component.html',
  styleUrls: ['./print-bill.component.css']
})
export class PrintBillComponent implements OnInit {
  id: any;
  printBillData: any;
  studentData: any;
  studentId: any;
  groupId: any;
  feesStructureList: any;
  //totalFees: number = 0;
  //totalFeesPaid: number = 0;
  //balanceFees:number = 0;

  balFees:any=[];

  constructor(private activatedRoute: ActivatedRoute,private billingService:BillingService) { }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get("id");
    this.getBill(this.id);
  }
getBill(id){
  this.billingService.getBillById(id).then((data:any)=>{
    this.printBillData=data;
    this.groupId = this.printBillData.groupId;
    this.studentId = this.printBillData.studentId;
   
    this.getFeesStructureList(this.studentId);
   
    this.printBillData.amount.toString();
    
    this.billingService.getBill(this.printBillData.studentId).then((data:any)=>{
      this.studentData=data;
      this.getBalPayInfo();
    })
  })
}

getFeesStructureList(studId)
{
  this.billingService.getFeesStructureByStudentId(studId).then((data:any)=>{
         this.feesStructureList = data;
  })
}

getBalPayInfo()
{
  this.balFees=[];

  for(var i=0 ; i<this.feesStructureList.length;i++)
  {
     if(this.feesStructureList[i].groupId == this.groupId)
     {
      var bal = {feesType:"",totalAmt:0,totalAmtPaid:0,totalAmtRem:0};
       
      bal.feesType = this.feesStructureList[i].feesType;

        bal.totalAmt = this.feesStructureList[i].fees;

        for(var j=0 ; j<this.studentData.length;j++)
          {
          if(this.studentData[j].groupId == this.groupId && this.feesStructureList[i].feesTypeId == this.studentData[j].feesTypeId)
          {
             bal.totalAmtPaid = bal.totalAmtPaid+this.studentData[j].amount;
          }
        }
        bal.totalAmtRem = bal.totalAmt - bal.totalAmtPaid;
        this.balFees.push(bal);
     }
  }
}

print(){
   window.print();
}
  
}
