import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
import { UserService } from 'src/services/UserService';

@Component({
  selector: 'app-billing-navbar',
  templateUrl: './billing-navbar.component.html',
  styleUrls: ['./billing-navbar.component.css']
})
export class BillingNavbarComponent implements OnInit {

  currentUser: any;
  singleUser: any;
  

  constructor(private userService :UserService,private router: Router,private loadingService:LoadingAlertService,
    private route: ActivatedRoute,private modalService: NgbModal) { }

  ngOnInit(): void {
    this.getCurrentUser();
    this.currentUser={};
    this.getSingleUser();
    this.singleUser={};
  }

  getCurrentUser(){
    this.userService.getCurrentUser().then((data:any)=>{
      this.currentUser = data;
    });
  }

  getSingleUser(){
    this.loadingService.showLoading();
    this.userService.getSingleUser().then((data:any)=>{
         this.singleUser = data;
         this.loadingService.hideLoading();
    });
  }


}
