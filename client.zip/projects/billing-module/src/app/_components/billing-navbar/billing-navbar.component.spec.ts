import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingNavbarComponent } from './billing-navbar.component';

describe('BillingNavbarComponent', () => {
  let component: BillingNavbarComponent;
  let fixture: ComponentFixture<BillingNavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillingNavbarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
