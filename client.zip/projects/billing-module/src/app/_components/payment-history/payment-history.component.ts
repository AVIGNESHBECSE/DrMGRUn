import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { BillingService } from 'src/services/BillingService';
import { UserService } from 'src/services/UserService';

@Component({
  selector: 'app-payment-history',
  templateUrl: './payment-history.component.html',
  styleUrls: ['./payment-history.component.css']
})
export class PaymentHistoryComponent implements OnInit {
@Input() value: any;
  //singleStuHistory: any;
  paymentInfo: any;
  student: any;
  constructor(private billingService:BillingService,private userService:UserService,
    private activeModal:NgbActiveModal) { }

  ngOnInit(): void {
    //this.getHistory(this.value);
    this.getPaymentInfo(this.value);
    this.getStudentDataById(this.value);
  }

  // getHistory(stdId) {
  //   this.billingService.getBill(stdId).then((data:any)=>{
  //   this.singleStuHistory=data;
  //  })
  // }

  getPaymentInfo(stdId)
  {
      this.billingService.getPaymentInfo(stdId).then((data:any)=>{
      this.paymentInfo = data;
      this.paymentInfo.sort((a, b) => {
      return parseInt(b.sem) - parseInt(a.sem);
      });
      })
  }

close(){
  this.activeModal.close();
}

getStudentDataById(studId)
  {
     this.userService.getUserId(studId).then((data:any)=>{
         this.student = data;
     })
  }

}
