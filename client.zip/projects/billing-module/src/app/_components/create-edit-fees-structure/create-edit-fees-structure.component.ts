import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { BillingService } from 'src/services/BillingService';
import { UserService } from 'src/services/UserService';

@Component({
  selector: 'app-create-edit-fees-structure',
  templateUrl: './create-edit-fees-structure.component.html',
  styleUrls: ['./create-edit-fees-structure.component.css']
})
export class CreateEditFeesStructureComponent implements OnInit {
  @Input() value:any;
  @Output('reload') reload=new EventEmitter();
    // feesTypes: any;
    editStudents: any;
    showCreateMessage: boolean;
    showEditMessage: boolean;
    getStudent: any;
    showMessages: boolean;
    editData: any;
    updatedFee: any;
    createFeesStructure: any={};
    addfeesStructure: any;
    constructor(private activeModal:NgbActiveModal,private billingService:BillingService,
      private userService:UserService) { }
  
    ngOnInit(): void {
      this.getStdFeesStructure(this.value);
      // this.getFeesType();
    }
    getStdFeesStructure(value){
      if(value.id != undefined){
        // this.getFeesType();
         this.billingService.getFeesStructure(value.id).then((data:any)=>{
          this.editStudents = data;
          this.showEditMessage = true;
          this.showCreateMessage = false;
          });
      
        }else{
          // this.getFeesType();
          this.showCreateMessage = true;
          this.showEditMessage = false;
          this.userService.getUserById(value.userId).then((data:any)=>{
          this.getStudent = data;
          this.getStudent.feesType = this.value.feesType;
          this.showMessages = true;
          });
        }    
    }
    // getFeesType(){
    //   this.billingService.getFeesType().then((data:any)=>{
    //     this.feesTypes=data;
    //   });
    // }
    updateFees(details){
      this.editData = details;
        this.billingService.updateFeeStructure(this.editData.id,this.editData).then((data:any)=>{
        this.updatedFee = data;
    this.reload.emit();
      });
      this.activeModal.close();
    }
  createFees(newDetail){
    this.createFeesStructure={};
      this.createFeesStructure.userId = newDetail.id;
      this.createFeesStructure.regNo = newDetail.registerNo;
      this.createFeesStructure.name = newDetail.name;
      this.createFeesStructure.fees = newDetail.fees;
      this.createFeesStructure.feesType = newDetail.feesType;
      this.createFeesStructure.feesTypeId = this.value.feesTypeId;
      this.createFeesStructure.sem = this.value.sem;
    this.billingService.createFeeStructure(this.createFeesStructure).then((data:any)=>{
        this.addfeesStructure = data;
    this.reload.emit();
      });
      this.activeModal.close();
    }
  close(){
  this.activeModal.close();
  }
  
}
