import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateEditFeesTypeComponent } from './create-edit-fees-type.component';

describe('CreateEditFeesTypeComponent', () => {
  let component: CreateEditFeesTypeComponent;
  let fixture: ComponentFixture<CreateEditFeesTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateEditFeesTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateEditFeesTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
