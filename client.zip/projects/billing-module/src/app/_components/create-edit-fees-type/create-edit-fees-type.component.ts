import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { BillingService } from 'src/services/BillingService';

@Component({
  selector: 'app-create-edit-fees-type',
  templateUrl: './create-edit-fees-type.component.html',
  styleUrls: ['./create-edit-fees-type.component.css']
})
export class CreateEditFeesTypeComponent implements OnInit {
  @Output('reload') reload=new EventEmitter();
  @Input() value:any;
addFeesType:any={};
  feesTypeData: any;
  feesTypeForm: any;
  showEditMessage: boolean;
  showCreateMessage: boolean;
  constructor(private billingService:BillingService,
    private activeModal:NgbActiveModal,
    private toaterService:ToastrService,
    ) { }

  ngOnInit(): void {
    if(this.value != undefined){
    this.getFeesTypeById(this.value);
    }
    else{
      this.showCreateMessage=true;
    }
  }
  getFeesTypeById(id){
    this.showEditMessage=true;
    this.billingService.getFeesTypeById(id).then((data:any)=>{
      this.feesTypeForm=data;
    })
  }
  createFeesType(addFeesType){
	
		this.billingService.createFeesType(addFeesType).then((data:any)=>{
		this.feesTypeData=data;
    this.reload.emit();
		this.toaterService.success("Fees type successfully created");
	});
	
  this.addFeesType={};
  this.activeModal.close();
	}

  updateFeesType(updateFeesType){
    this.billingService.updateFeesType(updateFeesType.id,updateFeesType).then((data:any)=>{
      this.updateFeesType=data;
      this.reload.emit();
    })
    this.activeModal.close();
  }
close(){
  this.activeModal.close();
}


}
