import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/services/UserService';
import { DepartmentService } from 'src/services/DepartmentService';
import { AccyearService } from 'src/services/AccyearService';
import { GroupService } from 'src/services/GroupService';
import { StudentService } from 'src/services/StudentService';
import { BillingService } from 'src/services/BillingService';
import { FacultyDepartmentService } from 'src/services/FacultyDepartmentService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
@Component({
  selector: 'app-billing-reports',
  templateUrl: './billing-reports.component.html',
  styleUrls: ['./billing-reports.component.css']
})
export class BillingReportsComponent implements OnInit {
  reports = ["PENDING FEES","CONSOLIDATE","COURSE WISE"];
  filters = ["Register Number","Student Name","Department"];
  report:any;
  allStudents: any;
  allDegDepDatas: any;
  filter:any;
  registerNumber:any;
  deptId:any;
  accyearList: any;
  accYearId:any;
  groups: any;
  students: any;
  group:any;
  studentData: any;
  paymentInfo: any;
  consolidated: any;
  facultyDept:any;
  facultyData: unknown;
  departments: any;
  dept: any;
  deptReports: any;
  consol={totalStudents:0,totalFees:0,totalFeesPaid:0,totalFeesBalance:0};
  currentYears: string[];
  semType: string[];
  currentYear:any;
  semester:any;
  constructor(private userService:UserService,private departmentService:DepartmentService,private accYearService:AccyearService,
    private groupService:GroupService,private studentService:StudentService,private billingService:BillingService,
    private facultyDepartmentService:FacultyDepartmentService,private loading:LoadingAlertService) { }

  ngOnInit(): void {
    this.loading.showLoading();
    this.facultyDepartmentService.getAllFacultyDepartments().then(
      data => {
        this.facultyData = data
        this.loading.hideLoading()
    })
  }

  showDiv(type)
  {
     if(type == "Student Name")
     {
        this.getAllStudents();
     }
     if(type == "Department")
     {
      this.getDepts();
     }
  }

  getAllStudents(){
    this.userService.getAllStudents().then((data:any)=>{
      this.allStudents=data;
    })
  }

  getDepts(){
      this.departmentService.getDepartment().then((data:any)=>{
        this.allDegDepDatas = data;
      })
  }

  getAccyears(deptId){
    this.accYearService.getAcademicByDep(deptId).then((data:any)=>{
      this.accyearList=data;
    })
  }

  getGroups(accyearId){
    this.groupService.getGroupByAccId(accyearId).then((data:any)=>{
      this.groups=data;
    })
  }
  getStudentList(grp){
    this.groupService.getStudents(grp.id).then((data:any)=>{
      this.students=data;
    })
  }

  getFilterData()
  {
      this.studentService.getStudentByRegNo(this.registerNumber).then((data:any)=>{
        this.studentData = data;
        if(this.studentData != null)
        {
          this.getPaymentInfo(this.studentData[0].id);
        }
      })
  }

  getPaymentInfo(stdId)
  {
      this.billingService.getPaymentInfo(stdId).then((data:any)=>{
      this.paymentInfo = data;
      this.paymentInfo.sort((a, b) => {
      return parseInt(b.sem) - parseInt(a.sem);
      });
      })
  }

  getConsolidated()
  {
    //this.loading.showLoading();
    this.clearConsolidatedFees();

    this.billingService.getConsolidated(this.facultyDept.id,this.currentYear,this.semester).then((data:any)=>{
      this.consolidated = data;
      console.log(this.consolidated);

      for(var i=0;i<this.consolidated.length;i++)
      {
         this.consol.totalFees =  this.consol.totalFees + Number(this.consolidated[i].totalFees);
         this.consol.totalFeesPaid = this.consol.totalFeesPaid + Number(this.consolidated[i].totalFeespaid);
         this.consol.totalFeesBalance = this.consol.totalFeesBalance + Number(this.consolidated[i].balance);
         this.consol.totalStudents = this.consol.totalStudents + Number(this.consolidated[i].stuSize);
      }
    })
  }

  clearConsolidatedFees()
  {
    this.consol.totalFees = 0;
    this.consol.totalFeesPaid = 0;
    this.consol.totalFeesBalance = 0;
    this.consol.totalStudents = 0;
  }

  getDepartmentById(facultyDep)
  {
    this.departmentService.getDepartmentWise(facultyDep.id).then((data:any)=>{
      this.departments = data;
    })
  }

  getDepartmentReport()
  {
    this.billingService.getDeptReport(this.dept.id,this.currentYear,this.semester).then((data:any)=>{
         this.deptReports = data;
    })
  }

  getCurrentYears()
  {
    this.currentYears=["2010","2011","2012","2013","2014","2015","2016","2017","2018","2019",
    "2020","2021","2022","2023","2024","2025","2026","2027","2028","2029","2030"];
  }

  getSemTypes()
  {
    this.semType=["Odd","Even"];
  }

  removeBind()
  {
    this.filter = '';
    this.registerNumber = '';
    this.deptId = '';
    this.accYearId = '';
    this.group = '';
    this.currentYear = '';
    this.semester = '';
    this.dept = '';
    this.facultyDept = '';
    this.deptReports = undefined;
    this.consolidated = undefined;
    this.paymentInfo = undefined;
  }

}
