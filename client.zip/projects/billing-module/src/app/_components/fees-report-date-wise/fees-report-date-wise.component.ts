import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { BillingService } from 'src/services/BillingService';
import { FacultyService } from 'src/services/FacultyService';

@Component({
  selector: 'app-fees-report-date-wise',
  templateUrl: './fees-report-date-wise.component.html',
  styleUrls: ['./fees-report-date-wise.component.css']
})
export class FeesReportDateWiseComponent implements OnInit {
  ranges: any = [
    {
      value: [new Date(new Date().setDate(new Date().getDate())), new Date()],
      label: 'Today',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 1)),
        new Date(new Date().setDate(new Date().getDate() - 1)),
      ],
      label: 'Yesterday',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 7)),
        new Date(),
      ],
      label: 'Last 7 Days',
    },
   
  ];
  startDate: any;
  endDate: any;
  fromDate: string;
  toDate: string;
  fac:any;
  facReport: any;
  facultyId: any;
  facultys: any;
  showTable: boolean;
 

  constructor(private facService:FacultyService,private billingService:BillingService) { }

  ngOnInit(): void {
    this.getFaculty();
  }

  demo($event:any){
    this.startDate=$event[0].toString();
    this.endDate=$event[1].toString();
    this.fromDate=moment(new Date(this.startDate)).format('DD-MMM-YYYY');
    this.toDate=moment(new Date(this.endDate)).format('DD-MMM-YYYY');
    
    }
getFaculty(){
  this.facService.getAllFacultys().then((data:any)=>{
    this.facultys=data;
  })
}

onChange(fac){
  this.facultyId=fac.id;
  
}

getFacultyDateReport(){
  this.billingService.getFacultyDateReport(this.facultyId,this.fromDate,this.toDate).then((data:any)=>{
    this.facReport=data;
    if(this.facReport.length != 0){
      this.showTable=true;
    }
  })
}
}
