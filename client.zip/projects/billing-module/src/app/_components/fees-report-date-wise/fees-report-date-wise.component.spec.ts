import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeesReportDateWiseComponent } from './fees-report-date-wise.component';

describe('FeesReportDateWiseComponent', () => {
  let component: FeesReportDateWiseComponent;
  let fixture: ComponentFixture<FeesReportDateWiseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeesReportDateWiseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FeesReportDateWiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
