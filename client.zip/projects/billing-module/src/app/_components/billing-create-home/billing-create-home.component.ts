import { Component, OnInit } from '@angular/core';
import { BillingCreatePopupComponent } from '../billing-create-popup/billing-create-popup.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { BillingService } from 'src/services/BillingService';
import { Router } from '@angular/router';
import { PaymentHistoryComponent } from '../payment-history/payment-history.component';

@Component({
  selector: 'app-billing-create-home',
  templateUrl: './billing-create-home.component.html',
  styleUrls: ['./billing-create-home.component.css']
})
export class BillingCreateHomeComponent implements OnInit {
  allBillsData: any;
  startCount=0;
  limit:any;
  count: number;

  constructor(private billingService:BillingService,
    private date:DatePipe,
    private modalService:NgbModal,
    private router : Router,

    ) { }

  ngOnInit(): void {
    this.getCount(0,'fresh')
  }
createBill(){
const modalRef = this.modalService.open(BillingCreatePopupComponent,{size:'lg',backdrop:'static'});
modalRef.componentInstance.reload.subscribe(() => {
  this.reload();
})
}
  reload() {
    this.getAllBills(0);
  }
  getCount(limit, type){
    if(type=='prev'){
      this.count=this.startCount-limit;
    }
    if(type=='new'){
      this.count=this.startCount+limit;
    }
    if(type=='fresh'){
      this.count=limit;
    }
this.getAllBills(this.count);
  }
getAllBills(startCount){

  this.billingService.getAllBills(this.count).then((data:any)=>{
    this.allBillsData= data.sort((a,b) => b - a);
    this.allBillsData.startCount=this.count;
    this.startCount=this.count;
  
  })
}
print(billId){
  this.router.navigate(['/billing-module/billPrint/'+ billId]);

}
viewStudent(studentId)
{
  const modalRef = this.modalService.open(PaymentHistoryComponent,{size:'xl',backdrop:'static'});
  modalRef.componentInstance.value=studentId;
}

}
