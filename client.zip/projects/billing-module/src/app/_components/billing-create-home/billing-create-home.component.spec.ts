import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingCreateHomeComponent } from './billing-create-home.component';

describe('BillingCreateHomeComponent', () => {
  let component: BillingCreateHomeComponent;
  let fixture: ComponentFixture<BillingCreateHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillingCreateHomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingCreateHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
