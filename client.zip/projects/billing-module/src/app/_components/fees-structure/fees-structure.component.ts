import { Component, OnInit } from '@angular/core';
import { AccyearService } from 'src/services/AccyearService';
import { BillingService } from 'src/services/BillingService';
import { DepartmentService } from 'src/services/DepartmentService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
import { FeeStructureImportComponent } from '../fee-structure-import/fee-structure-import.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CreateEditFeesStructureComponent } from '../create-edit-fees-structure/create-edit-fees-structure.component';
import { FacultyDepartmentService } from 'src/services/FacultyDepartmentService';
import { PaymentHistoryComponent } from '../payment-history/payment-history.component';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-fees-structure',
  templateUrl: './fees-structure.component.html',
  styleUrls: ['./fees-structure.component.css']
})
export class FeesStructureComponent implements OnInit {
  departments: unknown;
  dept:any;
  accyear:any;
  sem:any;
  semesters: any=[];
  accyears: any;
  feeStructureList: any;
  showTable: boolean;
  facultyDept:any;
  facultyData: any;
  feesTypes: any;
  feesType: any;
  globalFees = {accYearId:"",feesTypeId:"",sem:"",fees:""}
  showGlobCreate: boolean;
  showGlobEdit: boolean;
  globalFeesId: any;
  constructor(private departmentService:DepartmentService,
    private loading:LoadingAlertService,
    private accyearService:AccyearService,
    private billingService: BillingService,
    private modalService: NgbModal,
    private facultyDepartmentService:FacultyDepartmentService,
    private toastr : ToastrService) { }

  ngOnInit(): void {
    this.onload();
  }
  onload() {
    this.loading.showLoading();
    this.facultyDepartmentService.getAllFacultyDepartments().then(
      data => {
        this.facultyData = data
        this.loading.hideLoading()
    })  
  }

  getDepartmentById(facultyDep)
  {
    this.departmentService.getDepartmentWise(facultyDep.id).then((data:any)=>{
      this.departments = data;
    })
  }

  getAccYear(dept){
    this.accyearService.getAcademicByDep(dept.id).then((data:any)=>{
    this.accyears=data;
    })
  }

  getSem(accyear){
    this.semesters = [];
    for(var i=0;i<accyear.years.length;i++){
      this.semesters.push(accyear.years[i].sem);
    }
  }

  getFeesType(){
    this.billingService.getFeesType().then((data:any)=>{
      this.feesTypes=data;
    });
  }

  getDetailStructure(accYearId,sem,feesTypeId){
  this.billingService.getFeesStructureList(accYearId,sem,feesTypeId).then((data:any)=>{
  this.getGlobalFees(accYearId,feesTypeId,sem);
  this.globalFees.accYearId = accYearId;
    this.globalFees.feesTypeId = feesTypeId;
    this.globalFees.sem = sem;
  this.feeStructureList=data;
   if(this.feeStructureList.length != 0){
    for(var i=0;i<this.feeStructureList.length;i++)
    {
      this.feeStructureList[i].feesType = this.feesType.name;
      this.feeStructureList[i].feesTypeId = this.feesType.id;
    }
   this.showTable=true;
   }
   else{
    this.showTable=false;
     }
   })
  }

  getGlobalFees(accYearId,feesTypeId,sem)
  {
     this.billingService.getGlobalFees(accYearId,feesTypeId,sem).then((data:any)=>{
      console.log(data);
      if(data.length > 0)
      {
        this.globalFees = data[0];
        this.globalFeesId = data[0].id;
        this.showGlobCreate = true;
        this.showGlobEdit = false;
      }
      else{
        this.showGlobCreate = false;
        this.showGlobEdit = true;
      }
     })
  }

  createGlobalFees()
  {
    if(this.globalFees.fees ==='')
    {
       this.toastr.error("Global Fees is Empty");
    }
    else{
      this.billingService.createGlobalFees(this.globalFees).then((data:any)=>{
        this.reload();
      })
    }
  }

  updateGlobalFees()
  {
    if(this.globalFees.fees ==='')
    {
      this.toastr.error("Global Fees is Empty");
    }
    else{
      var globFee = {fees:this.globalFees.fees}
      this.billingService.updateGlobalFees(this.globalFeesId,globFee).then((data:any)=>{
        this.reload();
      })
    }
  }

  edit(std){
  const modelRef=this.modalService.open(CreateEditFeesStructureComponent,{size:'lg',backdrop:'static'});
  modelRef.componentInstance.value=std;
  modelRef.componentInstance.reload.subscribe(()=>{
  this.reload();
   })
  }

  importFeesStructure(){
    const modalRef=this.modalService.open(FeeStructureImportComponent,{size:'lg',backdrop:'static'});
    modalRef.componentInstance.accId=this.accyear.id;
    modalRef.componentInstance.sem=this.sem;
    modalRef.componentInstance.reload.subscribe(()=>{
      this.reload();
    })
  }
  reload() {
    this.getDetailStructure(this.accyear.id,this.sem,this.feesType.id);
  }
  viewStudent(studentId)
{
  const modalRef = this.modalService.open(PaymentHistoryComponent,{size:'xl',backdrop:'static'});
  modalRef.componentInstance.value=studentId;
}

// getPaymentInfo(studId)
// {
//   const modalRef = this.modalService.open(PaymentHistoryComponent,{size:'lg',backdrop:'static'});
//   modalRef.componentInstance.value=studId;

// }
}
