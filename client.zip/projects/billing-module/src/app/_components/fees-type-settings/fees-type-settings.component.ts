import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BillingService } from 'src/services/BillingService';
import { CreateEditFeesTypeComponent } from '../create-edit-fees-type/create-edit-fees-type.component';

@Component({
  selector: 'app-fees-type-settings',
  templateUrl: './fees-type-settings.component.html',
  styleUrls: ['./fees-type-settings.component.css']
})
export class FeesTypeSettingsComponent implements OnInit {
  feesTypes: any;

  constructor(private billingService:BillingService,private modelService:NgbModal) { }

  ngOnInit(): void {
    this.getFeesType();
  }
  getFeesType(){
    this.billingService.getFeesType().then((data:any)=>
   {
     this.feesTypes=data;
   })
  }
reload(){
  this.getFeesType();
}
  create(){
const modelRef=this.modelService.open(CreateEditFeesTypeComponent,{size:'lg',backdrop:'static'});
modelRef.componentInstance.reload.subscribe(()=>{
  this.reload();
})
  }

  editFeesType(id){
    const modelRef=this.modelService.open(CreateEditFeesTypeComponent,{size:'lg',backdrop:'static'});
    modelRef.componentInstance.value=id;
    modelRef.componentInstance.reload.subscribe(()=>{
      this.reload();
    })
  }
}
