import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeesTypeSettingsComponent } from './fees-type-settings.component';

describe('FeesTypeSettingsComponent', () => {
  let component: FeesTypeSettingsComponent;
  let fixture: ComponentFixture<FeesTypeSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeesTypeSettingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FeesTypeSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
