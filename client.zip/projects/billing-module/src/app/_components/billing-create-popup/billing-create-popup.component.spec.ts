import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingCreatePopupComponent } from './billing-create-popup.component';

describe('BillingCreatePopupComponent', () => {
  let component: BillingCreatePopupComponent;
  let fixture: ComponentFixture<BillingCreatePopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillingCreatePopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingCreatePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
