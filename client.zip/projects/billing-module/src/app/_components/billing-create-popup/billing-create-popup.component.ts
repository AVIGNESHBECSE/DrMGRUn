import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { AccyearService } from 'src/services/AccyearService';
import { BillingService } from 'src/services/BillingService';
import { DepartmentService } from 'src/services/DepartmentService';
import { GroupService } from 'src/services/GroupService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
import { UserService } from 'src/services/UserService';
import { PaymentHistoryComponent } from '../payment-history/payment-history.component';
import { FileValidationService } from 'src/services/FileValidationService';
import { FileUploadService } from 'src/services/FileUploadService';

@Component({
  selector: 'app-billing-create-popup',
  templateUrl: './billing-create-popup.component.html',
  styleUrls: ['./billing-create-popup.component.css']
})
export class BillingCreatePopupComponent implements OnInit {
  @Output('reload') reload=new EventEmitter();
tab:any;
studentType:any;
group:any;
formData:any={};
accyear:any;
  student: any;
  studentId: any;
  accYear: any;
  accyearList: any;
  deptId:any;
  allDegDepDatas: unknown;
  groups: any;
  students: any;
  std: any;
  allStudents: any;
  feesTypes: any;
  feesModes: any;
  showAttachment: boolean;
  bill: any;
  fileAttached: boolean;
  fileToUpload: File;
  fileLable: string;
  showUploadButton: boolean;
  showLabel: boolean;
  createdFile: any;
  selectedFile: any={};
  deletedFile: any;
  feesAttachment: any={};
  

  constructor(private activeModal:NgbActiveModal,
    private userService:UserService,
    private accYearService:AccyearService,
    private departmentService:DepartmentService,
    private loading:LoadingAlertService,
    private groupService:GroupService,
    private billingService:BillingService,
    private toaterService:ToastrService,
    private router : Router,
    private modalService:NgbModal,
    private fileValidator: FileValidationService,
    private fileUploadService: FileUploadService,
    ) { }


  ngOnInit(): void {
 this.studentType='registerNumber';
 this.getAllStudents();
 this.getTab(1);
 this.formData.date=new Date();
  }

  clearPopupBind()
  {
    this.formData.registerNumber = "";
    this.deptId = "";
    this.accyear = "";
    this.group = "";
    this.student = "";
    this.formData.name = "";
    this.formData.department = "";
    this.formData.sem = "";
    this.formData.date = "";
    this.formData.amount = "";
    this.formData.feesTypeId = "";
    this.formData.paymentMode = "";
    this.formData.referenceBillNumber = "";
    this.formData.purpose = "";
    this.formData.date1="";
  }


  getAllStudents(){
    this.userService.getAllStudents().then((data:any)=>{
      this.allStudents=data;
    })
    this.getFeesType();
  }
  close(){
    this.activeModal.close();
  }
  getStdPayementHistory(){
    const modalRef = this.modalService.open(PaymentHistoryComponent,{size:'lg',backdrop:'static'});
    modalRef.componentInstance.value=this.studentId;

  }
  source(type){
    if(type=="department"){
      this.getDepts();
    }
    this.studentType=type;
  }
  getTab(val){
    this.clearPopupBind()
    this.tab=val;
  }

  getStudentDetails(regNo){
    this.userService.getUserByRegNo(regNo).then((data:any)=>{
      this.std=data;
      this.formData.name = this.std[0].name;
			this.formData.studentId = this.std[0].id;
			this.formData.department = this.std[0].degreeName + '-' + this.std[0].departmentName;
			this.formData.departmentId = this.std[0].deptId
			this.studentId = this.std[0].id;

      this.accYearService.getById(this.std[0].accYearId).then((data:any)=>{
        this.accYear=data;
        this.formData.sem=this.accYear.currentSem;
      })
    })
  }
getDepts(){
  this.loading.showLoading();
  this.departmentService.getDepartment().then(
    data => {
      this.allDegDepDatas = data
      this.loading.hideLoading()
    })
}
  getAccyears(deptId){
    this.accYearService.getAcademicByDep(deptId).then((data:any)=>{
      this.accyearList=data;
    })
  }
  getGroups(accyear){
    this.groupService.getGroupByAccId(accyear.id).then((data:any)=>{
      this.groups=data;
    })
  }
  getStudentList(grpId){
    this.groupService.getStudents(grpId).then((data:any)=>{
      this.students=data;
    })
  }
  bindStudentInfo(std){
    this.formData.name = std.name;
    this.formData.studentId = std.id;
    this.studentId =  std.id;
    this.formData.registerNumber = std.registerNo;
    this.formData.department = std.degreeName;
    this.formData.departmentId = std.deptId;
    
  }
  bindStudentInfos(stud){
    this.formData.name = stud.name;
	this.formData.studentId = stud.id;
	this.studentId =  stud.id;
	this.formData.registerNumber = stud.registerNo;
	this.formData.department = stud.degreeName +'-'+ stud.departmentName;
	this.formData.departmentId = stud.deptId;

  }
  getFeesType(){
    this.billingService.getFeesType().then((data:any)=>{
      this.feesTypes=data;
    });
    this.getFeesMode();
  }
  getFeesMode() {
this.billingService.getFeesMode().then((data:any)=>{
  this.feesModes=data;
})
}
checkFeesMode(feeMode){
  if(feeMode == "ONLINE" || feeMode == "SCHOLARSHIP"){
		this.showAttachment = true;
		}
		else{
			this.showAttachment = false;
		}
}

change(files: FileList) {

  this.fileAttached = true;
  this.fileToUpload = files.item(0);
  if (this.fileValidator.validate(this.fileToUpload) == true) {

    this.fileLable = this.fileToUpload.name;
    this.showUploadButton = true;
    this.showLabel=false;
  }
  else {
    this.showLabel = true;
    return this.fileToUpload = null
  }
}

uploadAttachment(){
  this.fileUploadService.uploadFileData(this.fileToUpload).then((data:any)=>{
    this.createdFile=data;
    this.selectedFile.fileKey=this.createdFile.fileKey;
    this.selectedFile.versionId=this.createdFile.versionId;
  })
}
removeFile(){
  this.fileUploadService.deleteFile(this.selectedFile.versionId,this.selectedFile.fileKey).then((data:any)=>{
    this.deletedFile=data;
  })
  this.selectedFile = {};
}
createAndPrint(valid,print){
  this.createBillForm(valid,print);
}
createAndPrintOthers(valid,printOthers){
  this.createBillForm(valid,printOthers);
}
createBillForm(valid,print){
  if(valid){
  var prinStatus = print;
  if(this.formData.paymentMode == "ONLINE" || this.formData.paymentMode == "SCHOLARSHIP" ){
  this.feesAttachment.feesMode = this.formData.paymentMode;
  this.feesAttachment.fileAttachment=this.selectedFile;
  this.formData.feesAttachment=this.feesAttachment;
  }
  this.formData.date = new Date(this.formData.date).getTime();
  this.billingService.createBillForm(this.formData).then((data:any)=>{
  this.bill=data;
  this.toaterService.success("Bill created successfully");
  this.reload.emit();
  if(prinStatus === "print"){
    this.router.navigate(['/billing-module/billPrint/'+ this.bill.id]);

    }
  
})
  this.formData = {};
  this.studentId = undefined;
  this.student = undefined;

this.activeModal.close();
  }
}
}
