import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeeStructureImportComponent } from './fee-structure-import.component';

describe('FeeStructureImportComponent', () => {
  let component: FeeStructureImportComponent;
  let fixture: ComponentFixture<FeeStructureImportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeeStructureImportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FeeStructureImportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
