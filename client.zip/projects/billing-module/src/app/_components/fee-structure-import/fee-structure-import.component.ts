import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { BillingService } from 'src/services/BillingService';
import { FileUploadService } from 'src/services/FileUploadService';
import { FileValidationService } from 'src/services/FileValidationService';

@Component({
  selector: 'app-fee-structure-import',
  templateUrl: './fee-structure-import.component.html',
  styleUrls: ['./fee-structure-import.component.css']
})
export class FeeStructureImportComponent implements OnInit {
  @Input() accId:any;
  @Input()  sem:any;
  @Output('reload') reload=new EventEmitter();


  
  createdFile: any;
  selectedFile:any={};
  fileAttached: boolean;
  fileToUpload= new FormData();
  fileLable: string;
  showUploadButton: boolean;
  showLabel: boolean;
  deletedFile: any;

  constructor(private activeModal:NgbActiveModal,
    private billingService:BillingService,
    private fileUploadService:FileUploadService,
    private fileValidator: FileValidationService,
    private toaster:ToastrService
    ) { }

  ngOnInit(): void {
  }
close(){
  this.activeModal.close();

}

change(files: FileList) {

  this.fileAttached = true;
  this.fileToUpload.append( 'file',files.item(0));
  this.showUploadButton=true;
}

uploadAttachment(){
  this.billingService.importFeesStructure(this.accId,this.sem,this.fileToUpload).then((data:any)=>{
    this.createdFile=data;
    if(this.createdFile=="success"){
      this.toaster.success("Fees Structure Imported Successfully");
    }
this.reload.emit();
  })
  this.fileToUpload=null;
this.activeModal.close();
}



downloadExcel(){
  this.billingService.downloadExcel()
}
}
