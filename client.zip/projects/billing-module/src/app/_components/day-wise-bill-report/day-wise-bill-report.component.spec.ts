import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DayWiseBillReportComponent } from './day-wise-bill-report.component';

describe('DayWiseBillReportComponent', () => {
  let component: DayWiseBillReportComponent;
  let fixture: ComponentFixture<DayWiseBillReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DayWiseBillReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DayWiseBillReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
