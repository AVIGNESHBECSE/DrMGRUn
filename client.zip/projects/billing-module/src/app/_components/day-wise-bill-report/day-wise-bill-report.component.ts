import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { BillingService } from 'src/services/BillingService';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PaymentHistoryComponent } from '../payment-history/payment-history.component';
@Component({
  selector: 'app-day-wise-bill-report',
  templateUrl: './day-wise-bill-report.component.html',
  styleUrls: ['./day-wise-bill-report.component.css']
})
export class DayWiseBillReportComponent implements OnInit {
  allBillsData: any;
   selectedDate:any;
  billDate: string;
  showTable: boolean;
  feesTypes: any;
  feesType : any;
  constructor(private billingService:BillingService,
    private router : Router,private modalService:NgbModal) { }

  ngOnInit(): void {
    this.getFeesType();
  }
  getBills(date){
    this.billDate=moment(new Date(date)).format('DD-MMM-YYYY');
      this.billingService.getBills(this.billDate,this.feesType.id).then((data:any)=>{
      this.allBillsData = data;
      if(this.allBillsData.length != 0){
        this.showTable=true;
      }
      else{
        this.showTable=false;
      }
    })
   }

   getFeesType(){
    this.billingService.getFeesType().then((data:any)=>{
      this.feesTypes=data;
    });
  }

   print(billId){
    this.router.navigate(['/billing-module/billPrint/'+ billId]);
  
  }
  viewStudent(studentId)
   {
    const modalRef = this.modalService.open(PaymentHistoryComponent,{size:'xl',backdrop:'static'});
    modalRef.componentInstance.value=studentId;
   }
}
