import { Component, OnInit } from '@angular/core';
import { AccyearService } from 'src/services/AccyearService';
import { DepartmentService } from 'src/services/DepartmentService';
import { ExaminationService } from 'src/services/ExaminationService';
import { MarksService } from 'src/services/MarksService';
import { RegulationService } from 'src/services/RegulationService';
import { SubjectService } from 'src/services/SubjectService';
import { TestService } from 'src/services/TestService';

@Component({
  selector: 'app-obe-and-other-mark-report',
  templateUrl: './obe-and-other-mark-report.component.html',
  styleUrls: ['./obe-and-other-mark-report.component.css']
})
export class ObeAndOtherMarkReportComponent implements OnInit {
  departments: any;
  accyears: any;
  dept:any;
  accyearId: any;
  regulationId: any;
  subId:any;
  testName:any;
  semesters: string[];
  sem:any;
  batchId:any;
  accYear: any;
  regSubjects: any;
  batches: any;
  allExamMarkDetails: any;
  testList: any;
  globalBean: any;
  markData: any;
  questionPapers: any;
  questionPaperId: any;
  questionPaperDetails: any;
  coDetails: any;
  coReport: any;
  questionWiseMarkList: any;
  resultDiv: boolean;
  subjectWiseDiv: boolean;
  showSubjectMark: boolean;
  questionWiseObeMarkList: any;
  overAllMarkReport: any;
  show: boolean;

  constructor(private departmentService:DepartmentService,
    private accYearService:AccyearService,
    private subjectService:SubjectService,
    private testService:TestService,
    private regulationService: RegulationService,
    private examinationService:ExaminationService,
    private marksService:MarksService) { }

  ngOnInit(): void {
    
    this.getDepartments();
    this.semesters=['1','2','3','4','5','6','7','8'];
     }

  getDepartments()
  {
   this.departmentService.getDepartment().then((data:[])=>{
     this.departments = data;
    });
  }
  

  getAccyears(deptId){
    this.accYearService.getAcademicByDep(deptId).then((data:any)=>{
this.accyears=data;


    })
  }
  getRegulation(accyearId){
    this.accYearService.getById(accyearId.id).then((data:any)=>{
      this.accYear=data;
this.regulationId=this.accYear.regulationId;
    });
}
getRegSubjects(sem){
  this.regulationService.getRegSub(this.dept,this.regulationId,sem).then((data:any)=>{
    this.regSubjects=data.datas;
  })
}
getBatches(sub){
  this.subjectService.getActiveBatch(sub).then((data:any)=>{
    this.batches=data;
    this.batches.sort((a,b)=>a.batchName.localeCompare(b.batchName));
  })

}

 getTests(batchId){
  
      this.testService.getTestsBySubject(batchId).then(async(data:any)=>{
    this.testList=data;
    this.testName=this.testList[0].id;
    
    this.source(this.testList[0]);

  })

}

source(test){
  this.testName=test.id;
  this.questionPapers = test.questionPapers;
  this.globalBean = {};
  var SubjectArray = new Array();
  SubjectArray.push(this.batchId)
   this.globalBean.listOfString = SubjectArray;
 this.marksService.createMarksList(test.id,this.globalBean).then((data:any)=>{
      this.markData=data;
    })
for(var j=0;j<this.questionPapers.length;j++){
  if(this.questionPapers[j].subjectId == this.batchId){
    this.questionPaperId=this.questionPapers[j].questionPaperId;
  }
}
  this.getAllExamMarkReport(this.batchId,this.questionPaperId,test.id);
   }
  

  async getAllExamMarkReport(batchId,questionPaperId,testId){
    await this.examinationService.getMarkReportQuesionPaperWise(batchId, questionPaperId,testId).then((data:any)=>{
      this.questionWiseMarkList=data;
    })
    await  this.examinationService.getObeMark(questionPaperId,batchId,testId).then((data:any)=>{
        this.questionPaperDetails = data;
    })
         await this.examinationService.getObeQuestiontemp(questionPaperId,batchId,testId).then((data:any)=>{
            this.coDetails = data;
          })
      
    
   await this.examinationService.obecoWiseReport(questionPaperId,testId,batchId).then((data:any)=>{
    this.coReport = data;

    
  })
this.show=true;
 }

 obeMarkExport(subjectId){
  this.examinationService.getObeMarkReportQuesionPaperWiseExport(this.questionPaperId,this.testName,subjectId).then((data:any)=>{
    this.questionWiseObeMarkList=data;
   
  })
}

showTotalMark() {
  this.resultDiv = false;
  this.subjectWiseDiv = true;
  this.showSubjectMark = true;
}
calculateTotal(marks) {
  var total = 0;
  for (var i = 0; i < marks.length; i++) {
    if (marks[i].mark != "---" && marks[i].mark != "N/A" && marks[i].mark != "" && marks[i].mark.toUpperCase() != "AB") {
      total = total + parseInt(marks[i].mark);
    }
  }
  return total;
}

DownloadOverallExamsMarkReportExcel(subId){
  this.examinationService.getOverallExamMarkReportExcel(subId).then((data:any)=>{
    this.overAllMarkReport=data;
  })
}
 
}
