import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObeAndOtherMarkReportComponent } from './obe-and-other-mark-report.component';

describe('ObeAndOtherMarkReportComponent', () => {
  let component: ObeAndOtherMarkReportComponent;
  let fixture: ComponentFixture<ObeAndOtherMarkReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObeAndOtherMarkReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ObeAndOtherMarkReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
