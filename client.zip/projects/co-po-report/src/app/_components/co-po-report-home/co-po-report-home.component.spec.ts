import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoPoReportHomeComponent } from './co-po-report-home.component';

describe('CoPoReportHomeComponent', () => {
  let component: CoPoReportHomeComponent;
  let fixture: ComponentFixture<CoPoReportHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoPoReportHomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoPoReportHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
