import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AccyearService } from 'src/services/AccyearService';
import { DepartmentService } from 'src/services/DepartmentService';
import { ExaminationService } from 'src/services/ExaminationService';
import { FacultyDepartmentService } from 'src/services/FacultyDepartmentService';
import { GroupService } from 'src/services/GroupService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
import { CoPoSubListComponent } from '../co-po-sub-list/co-po-sub-list.component';

@Component({
  selector: 'app-co-po-report-home',
  templateUrl: './co-po-report-home.component.html',
  styleUrls: ['./co-po-report-home.component.css']
})
export class CoPoReportHomeComponent implements OnInit {
  departments: unknown;
  groups: any;
  accyears: any;
  grpId:any;
  acc:any;
  dept:any;
  yearOfBatch: number;
  selectedSem: any;
  semType: any;
  studentList: any;
  reports: any;
  showTable: boolean;

  constructor(private accYearService: AccyearService,
    private loading: LoadingAlertService,
    private examSerive:ExaminationService,
    private Modalservice: NgbModal,
    private activatedRoute: ActivatedRoute,
    private facDeptService: FacultyDepartmentService,
    private departmentService: DepartmentService,
    private groupService: GroupService) { }

  ngOnInit(): void {
    this.onload();
  }
  onload() {
    this.loading.showLoading();
    this.departmentService.getDepartment().then(
      data => {
        this.departments = data
        this.loading.hideLoading()
      })

  }
  onChange(dept) {
    this.accYearService.getAcademicyear(dept.id).then((data: []) => {
      this.accyears = data;
        })
  }
  getGroup(acc) {
    this.groupService.getGroupByAccId(acc.id).then((data: []) => {
      this.groups = data;
    });
  }
  getStudents(grpId){
    for(var i=0;i<grpId.accYearDoc.years.length;i++){
      if(grpId.sem==grpId.accYearDoc.years[i].sem){
        this.yearOfBatch=grpId.accYearDoc.years[i].year;
        this.semType=grpId.accYearDoc.years[i].semType;
        this.selectedSem=grpId.accYearDoc.years[i].sem;
      }
    }
    this.groupService.getGroupStudents(grpId.id).then((data:any)=>{
      this.studentList=data;
      this.showTable=true;
    })
  }
  getReport(stdId){
    this.examSerive.getCoPoReport(stdId,this.yearOfBatch,this.selectedSem,this.semType).then((data:any)=>{
    this.reports=data;
    this.popupReport(this.reports);
    })
  }
  popupReport(subReport){
    const modelRef = this.Modalservice.open(CoPoSubListComponent,{size:"lg",backdrop:'static'});
    modelRef.componentInstance.value=subReport;
  }
}
