import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AccyearService } from 'src/services/AccyearService';
import { DepartmentService } from 'src/services/DepartmentService';
import { ExaminationService } from 'src/services/ExaminationService';
import { FacultyDepartmentService } from 'src/services/FacultyDepartmentService';
import { GroupService } from 'src/services/GroupService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
import { RegulationService } from 'src/services/RegulationService';

@Component({
  selector: 'app-co-po-sub-report',
  templateUrl: './co-po-sub-report.component.html',
  styleUrls: ['./co-po-sub-report.component.css']
})
export class CoPoSubReportComponent implements OnInit {
  departments: unknown;
  accyears: any;
  acc:any;
  sub:any;
  dept:any;
  regSubjects: any;
  semesters: string[];
  sem:any;
  deptId: any;
  yearOfBatch: any;
  semType: any;
  coPoSubReport: any;
  showTable: boolean;

  constructor(private accYearService: AccyearService,
    private loading: LoadingAlertService,
    private examSerive:ExaminationService,
    private Modalservice: NgbModal,
    private activatedRoute: ActivatedRoute,
    private facDeptService: FacultyDepartmentService,
    private departmentService: DepartmentService,
    private regService: RegulationService) { }

  ngOnInit(): void {
    this.onload();
    this.semesters=["1","2","3","4","5","6","7","8"];
  }
  onload() {
    this.loading.showLoading();
    this.departmentService.getDepartment().then(
      data => {
        this.departments = data
        this.loading.hideLoading()
      })

  }
  onChange(dept) {
    this.deptId=dept.id;
    this.accYearService.getAcademicyear(dept.id).then((data: []) => {
      this.accyears = data;
        })
  }

  getSubjects(acc,sem){

    for(var i=0;i<acc.years.length;i++){
      if(sem==acc.years[i].sem){
        this.yearOfBatch=acc.years[i].year;
        this.semType=acc.years[i].semType;
      }
    }
this.regService.getRegSub(this.deptId,acc.regulationId,sem).then((data:any)=>{
  this.regSubjects=data.datas;
})
  }

  getSemAndYear(sub){
this.examSerive.getCoPoSubjectReport(this.deptId,sub.id,this.semType,this.yearOfBatch).then((data:any)=>{
  this.coPoSubReport=data;
  this.showTable=true;
})
  }
}
