import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoPoSubReportComponent } from './co-po-sub-report.component';

describe('CoPoSubReportComponent', () => {
  let component: CoPoSubReportComponent;
  let fixture: ComponentFixture<CoPoSubReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoPoSubReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoPoSubReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
