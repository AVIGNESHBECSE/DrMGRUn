import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoPoSubListComponent } from './co-po-sub-list.component';

describe('CoPoSubListComponent', () => {
  let component: CoPoSubListComponent;
  let fixture: ComponentFixture<CoPoSubListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoPoSubListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoPoSubListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
