import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-co-po-sub-list',
  templateUrl: './co-po-sub-list.component.html',
  styleUrls: ['./co-po-sub-list.component.css']
})
export class CoPoSubListComponent implements OnInit {
@Input() value:any;
  constructor(    private activeModal: NgbActiveModal
    ) { }

  ngOnInit(): void {
  }
  close(){
    this.activeModal.close();
  }
}
