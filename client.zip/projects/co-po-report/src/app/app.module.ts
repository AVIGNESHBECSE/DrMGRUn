import { BrowserModule } from '@angular/platform-browser';
import { ModuleWithProviders, NgModule } from '@angular/core';
import { MainPipe } from 'src/app/common/pipe/main-pipe.module';
import { OrderByPipe } from 'src/app/common/pipe/orderbyPipe';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoPoReportHomeComponent } from './_components/co-po-report-home/co-po-report-home.component';
import { NgbAlertModule, NgbModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { CommonNavModule } from 'src/app/common/common-nav.module';
import { CoPoSubListComponent } from './_components/co-po-sub-list/co-po-sub-list.component';
import { CoPoSubReportComponent } from './_components/copo-subwise-report/co-po-sub-report/co-po-sub-report.component';
import { ObeAndOtherMarkReportComponent } from './_components/obe-and-other-mark-report/obe-and-other-mark-report.component';

// @NgModule({  declarations: []
// })
// export class CoPoReportSharedModule {
//   static forRoot(): ModuleWithProviders<any> {
//     return {
//       ngModule: AppModule,
//       providers: []
//     }
//   }
// }
@NgModule({
  declarations: [
    AppComponent,
    CoPoReportHomeComponent,
    CoPoSubListComponent,
    CoPoSubReportComponent,
    ObeAndOtherMarkReportComponent
  ],
  imports: [
    // BrowserModule,
    AppRoutingModule,
    // HttpClientModule,
    NgbModule,
    FormsModule,
    RouterModule,
    NgxMaterialTimepickerModule,
    ReactiveFormsModule,
    NgbAlertModule,
    NgbTooltipModule,
    // BrowserAnimationsModule,
    CommonModule,
    CommonNavModule,
    MainPipe
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class CoPoReportModule { }
