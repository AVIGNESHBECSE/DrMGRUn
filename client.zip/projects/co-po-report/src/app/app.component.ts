import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
import { UserService } from 'src/services/UserService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'coPoReport';
  currentUser: any;

    constructor(private userService :UserService,
      private router: Router,
      private route: ActivatedRoute,
      private modalService: NgbModal, 
      private loadingService: LoadingAlertService) { }
  
  
    ngOnInit() {
    this.getCurrentUser();
     
     
    }
    
  getCurrentUser(){
    this.userService.getCurrentUser().then((data:any)=>{
      this.currentUser = data;
    });
  }
}
