import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { CoPoReportHomeComponent } from './_components/co-po-report-home/co-po-report-home.component';
import { CoPoSubListComponent } from './_components/co-po-sub-list/co-po-sub-list.component';
import { CoPoSubReportComponent } from './_components/copo-subwise-report/co-po-sub-report/co-po-sub-report.component';
import { ObeAndOtherMarkReportComponent } from './_components/obe-and-other-mark-report/obe-and-other-mark-report.component';

const routes: Routes = [
  {path:'', redirectTo:'home',pathMatch:'full'},
  { path: '', component: AppComponent ,children:[
    { path: 'home', component: CoPoReportHomeComponent },
    {path:'coPoSubList', component:CoPoSubListComponent},
    {path:'coPoSubReport', component:CoPoSubReportComponent},
    { path:'markReport', component:ObeAndOtherMarkReportComponent}
  ]
}
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
