import { BrowserModule } from '@angular/platform-browser';
import { ModuleWithProviders, NgModule } from '@angular/core';
import { GroupByPipe } from 'src/app/common/pipe/groupByPipe';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainPipe } from 'src/app/common/pipe/main-pipe.module';
import { RouterModule } from '@angular/router';
import { CommonModule, DatePipe } from '@angular/common';
import { CommonNavModule } from 'src/app/common/common-nav.module';
import { HttpClientModule } from '@angular/common/http';
import { NgbAlertModule, NgbModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AttendanceComponent } from './_components/attendance/attendance.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { PopupComponent } from './_components/popup/popup.component';
import { AttendanceHomeComponent } from './_components/attendanceStaffBody/attendance-home/attendance-home.component';
import { AttendanceDeadlineComponent } from './_components/attendanceStaffBody/attendance-deadline/attendance-deadline.component';
import { AttendanceSettingsComponent } from './_components/attendanceStaffBody/attendance-settings/attendance-settings.component';
import { MyAttendanceComponent } from './_components/attendanceStaffBody/my-attendance/my-attendance.component';
import { SubjectAttendanceComponent } from './_components/attendanceStaffBody/subject-attendance/subject-attendance.component';
import { StaffAttendanceComponent } from './_components/attendanceStaffBody/staff-attendance/staff-attendance.component';
import { DepartmentAttendanceComponent } from './_components/attendanceStaffBody/department-attendance/department-attendance.component';
import { AttendancePopupComponent } from './_components/attendanceStaffBody/attendance-popup/attendance-popup.component';
import { AttendanceRestrictComponent } from './_components/attendanceStaffBody/attendance-restrict/attendance-restrict.component';
import { CopyAttendanceComponent } from './_components/attendanceStaffBody/copy-attendance/copy-attendance.component';
import { CompletedLPPopupComponent } from './_components/attendanceStaffBody/completed-lppopup/completed-lppopup.component';
import { AttendanceTimeLimitComponent } from './_components/attendanceStaffBody/attendance-time-limit/attendance-time-limit.component';
import { EditAttendanceTimeLimitComponent } from './_components/attendanceStaffBody/edit-attendance-time-limit/edit-attendance-time-limit.component';
// @NgModule({  declarations: []
// })
// export class AttendanceSharedModule {
//   static forRoot(): ModuleWithProviders<any> {
//     return {
//       ngModule: AppModule,
//       providers: []
//     }
//   }
// }

@NgModule({
  declarations: [
    AppComponent,
    AttendanceComponent,
    PopupComponent,
    AttendanceHomeComponent,
     AttendanceDeadlineComponent, 
     AttendanceSettingsComponent,
     MyAttendanceComponent, 
     SubjectAttendanceComponent, 
     StaffAttendanceComponent, 
     DepartmentAttendanceComponent,
     AttendancePopupComponent,
     AttendanceRestrictComponent,
     AttendanceTimeLimitComponent,
     CopyAttendanceComponent,
     CompletedLPPopupComponent,
     EditAttendanceTimeLimitComponent
  ],
  imports: [
    // BrowserModule,
    AppRoutingModule,
    // HttpClientModule,
    NgbModule,
    FormsModule,
    RouterModule,
    NgxMaterialTimepickerModule,
    ReactiveFormsModule,
    NgbAlertModule,
    MainPipe,
    NgbTooltipModule,
    // BrowserAnimationsModule,
    CommonModule,
    CommonNavModule,
    BsDatepickerModule.forRoot()
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AttendanceModule { }
 