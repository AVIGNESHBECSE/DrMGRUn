import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { DepartmentService } from 'src/services/DepartmentService';
import { EventService } from 'src/services/EventService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';

@Component({
  selector: 'app-edit-attendance-time-limit',
  templateUrl: './edit-attendance-time-limit.component.html',
  styleUrls: ['./edit-attendance-time-limit.component.css']
})
export class EditAttendanceTimeLimitComponent implements OnInit {
@Input() value:any;
@Input() totValue:any;
@Input() index:any;
@Output('reload') reload = new EventEmitter();
  days: number[];
  departments: unknown;
  updateAttConfig: any;

  constructor(private loading:LoadingAlertService,
    private departmentService:DepartmentService, private activeModal: NgbActiveModal, 
    public toasterService: ToastrService,public eventService:EventService) { }

  ngOnInit(): void {
    this.onload();
    this.days=[0, 1, 2, 3, 4, 5, 10, 15, 20, 25, 30, 45, 60, 90, 180];
 
  }
  onload() {
    this.loading.showLoading();
    this.departmentService.getDepartment().then(
      data => {
        this.departments = data
        this.loading.hideLoading()
      })
  }
updateTimeLimit(valid) {
 
  if(valid){
    for (var i =0; i<this.totValue.timeLimit.length; i++){
       if(this.index == i){
          this.totValue.timeLimit[i].departmentId=this.value.departmentId;
        this.totValue.timeLimit[i].time=this.value.time;
        this.totValue.timeLimit[i].day=this.value.day;
      }
    }
      this.eventService.updateAttTimeLimit(this.totValue).then((data:any)=>{
      this.updateAttConfig=data;
      this.reload.emit();
      this.toasterService.success("Changes Added Sucessfully.");

     })
  }
  this.activeModal.close();

}
close(){
  this.activeModal.close();
}
}
