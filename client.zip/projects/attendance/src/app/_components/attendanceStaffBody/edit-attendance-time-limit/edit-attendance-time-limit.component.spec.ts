import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAttendanceTimeLimitComponent } from './edit-attendance-time-limit.component';

describe('EditAttendanceTimeLimitComponent', () => {
  let component: EditAttendanceTimeLimitComponent;
  let fixture: ComponentFixture<EditAttendanceTimeLimitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditAttendanceTimeLimitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditAttendanceTimeLimitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
