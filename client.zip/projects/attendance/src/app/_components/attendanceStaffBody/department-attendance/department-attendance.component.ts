import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { DepartmentService } from 'src/services/DepartmentService';
import { EventService } from 'src/services/EventService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
import { SubjectService } from 'src/services/SubjectService';
import { AttendancePopupComponent } from '../attendance-popup/attendance-popup.component';
import { AttendanceRestrictComponent } from '../attendance-restrict/attendance-restrict.component';

@Component({
  selector: 'app-department-attendance',
  templateUrl: './department-attendance.component.html',
  styleUrls: ['./department-attendance.component.css']
})
export class DepartmentAttendanceComponent implements OnInit {
  departments: unknown;
  dept:any;
  timeTables: any;
  timeTable:any;
  startDate = new Date();
  endDate = new Date();
  fromDate: string;
  toDate: string;
  ranges: any = [
    {
      value: [new Date(new Date().setDate(new Date().getDate())), new Date()],
      label: 'Today',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 1)),
        new Date(new Date().setDate(new Date().getDate() - 1)),
      ],
      label: 'Yesterday',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 7)),
        new Date(),
      ],
      label: 'Last 7 Days',
    },
   
  ];
  timetableRefCode: any;
  deptEvents: any;
  eventData: any;
  status: any;
  subject: any;
  absent: number;
  present: number;
  showTable: boolean;
  constructor(private loading:LoadingAlertService,
    private departmentService:DepartmentService,
    private eventService:EventService,
    private modalService: NgbModal,private datepipe:DatePipe,private subjectService:SubjectService) { }

  ngOnInit(): void {
    this.onload();
  }
  demo($event:any){
    this.startDate=$event[0].toString();
    this.endDate=$event[1].toString();
    this.fromDate=moment(new Date(this.startDate)).format('DD-MMM-YYYY');
    this.toDate=moment(new Date(this.endDate)).format('DD-MMM-YYYY');
    
    }
  onload() {
    this.loading.showLoading();
    this.departmentService.getDepartment().then(
      data => {
        this.departments = data
        this.loading.hideLoading()
      })

  }
  getTimeTable(dept){
this.eventService.getTimetableView(dept.id).then((data:any)=>{
  this.timeTables=data;
  this.timeTables.sort((a, b) => a.timetableName.localeCompare(b.timetableName));


})
  }
  getSelectedTimeTable(timeTable){
    this.timetableRefCode=timeTable.referenceCode;
  }

  getEventStatus(){
    if (this.timetableRefCode == undefined){
			var refCode = new Array();
			for (var i=0; i<this.timeTables.length;i++){
				if (this.timeTables[i].referenceCode != undefined){
				refCode.push(this.timeTables[i].referenceCode);  
				}
			}
			this.timetableRefCode = refCode.toString();
		}
this.eventService.getDepartmentTimeTable(this.fromDate, this.toDate, this.timetableRefCode).then((data:any)=>{
  this.deptEvents=data;
  if(this.deptEvents.length != 0){
    this.showTable=true;
  }
  else{
    this.showTable=false;
  }
})
  }

  totalPresent(eachEvent){
    this.present=0;
    this.absent=0;
          for (var i=0; i<eachEvent.attendance.length; i++) {
             if (eachEvent.attendance[i].status == "PRESENT") {
                this.present = this.present+1;
             } else {
             this.absent = this.absent+1;
             }
           }
            return "Tot Pre:" + this.present + " Tot Abs:" + this.absent;
  }

  getEventStudentListVal(eventId,subId,batchId){
    this.subjectService.getSubjectById(subId).then((data:any)=>{
      this.subject=data;
      this.getEvent(eventId,batchId);

    })
  }
  getEvent(eventId,batchId){
    this.eventService.getDeadlineStatus(eventId).then((data:any)=>{
      this.status=data;
      if(this.status.errorStatus){
        const modalRef = this.modalService.open(AttendanceRestrictComponent,{size:"lg",backdrop:'static'});
        
      }
      else{
        this.eventService.getEventtable(eventId).then((data:any)=>{
          this.eventData=data;
          const modalRef= this.modalService.open(AttendancePopupComponent,{size:"lg",backdrop:'static'});
          modalRef.componentInstance.value = this.eventData;
          modalRef.componentInstance.subValue = this.subject;
          modalRef.componentInstance.batchId = batchId;
          modalRef.componentInstance.reload.subscribe(() => {
            this.reload();
          }) 

        })
      }
    })

  }
  reload(){
    this.getEventStatus();
  }
}
