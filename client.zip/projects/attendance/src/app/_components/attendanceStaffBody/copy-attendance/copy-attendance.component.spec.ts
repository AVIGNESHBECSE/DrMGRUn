import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyAttendanceComponent } from './copy-attendance.component';

describe('CopyAttendanceComponent', () => {
  let component: CopyAttendanceComponent;
  let fixture: ComponentFixture<CopyAttendanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CopyAttendanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyAttendanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
