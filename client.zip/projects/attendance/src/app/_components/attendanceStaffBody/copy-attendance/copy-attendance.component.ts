import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-copy-attendance',
  templateUrl: './copy-attendance.component.html',
  styleUrls: ['./copy-attendance.component.css']
})
export class CopyAttendanceComponent implements OnInit {

  constructor(    private activeModal: NgbActiveModal
    ) { }

  ngOnInit(): void {
  }
  close(){
    this.activeModal.close();
  }

}
