import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { EventService } from 'src/services/EventService';
import { DatePipe } from '@angular/common';
import { SubjectService } from 'src/services/SubjectService';
import { AttendanceRestrictComponent } from '../attendance-restrict/attendance-restrict.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AttendancePopupComponent } from '../attendance-popup/attendance-popup.component';


@Component({
  selector: 'app-my-attendance',
  templateUrl: './my-attendance.component.html',
  styleUrls: ['./my-attendance.component.css']
})
export class MyAttendanceComponent implements OnInit {
  ranges: any = [
    {
      value: [new Date(new Date().setDate(new Date().getDate())), new Date()],
      label: 'Today',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 1)),
        new Date(new Date().setDate(new Date().getDate() - 1)),
      ],
      label: 'Yesterday',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 7)),
        new Date(),
      ],
      label: 'Last 7 Days',
    },
   
  ];
  startDate=new Date();
  endDate=new Date();
  fromDate: string;
  toDate: string;
  facultyEvents: any;
  present: number;
  absent: number;
  subject: any;
  status: any;
  eventData: any;
  showTable: boolean;
  constructor(private eventService:EventService, 
    private modalService: NgbModal,private datepipe:DatePipe,private subjectService:SubjectService) { }

  ngOnInit(): void {
  }
  demo($event:any){
    this.startDate=$event[0].toString();
    this.endDate=$event[1].toString();
    this.fromDate=moment(new Date(this.startDate)).format('DD-MMM-YYYY');
    this.toDate=moment(new Date(this.endDate)).format('DD-MMM-YYYY');
    
    }
    getFacultyEvents(){
      this.eventService.getTimetable(this.fromDate,this.toDate).then((data:any)=>{
        this.facultyEvents=data;
        if(this.facultyEvents.length != 0){
          this.showTable=true;
        }
        else{
          this.showTable=false;
        }
      })
    }

    totalPresent(eachEvent){
      this.present=0;
		  this.absent=0;
		        for (var i=0; i<eachEvent.attendance.length; i++) {
			         if (eachEvent.attendance[i].status == "PRESENT") {
			          	this.present = this.present+1;
			         } else {
				       this.absent = this.absent+1;
			         }
		         }
		          return "Tot Pre:" + this.present + " Tot Abs:" + this.absent;
    }

    getEventStudentListVal(eventId,subId,batchId){
      this.subjectService.getSubjectById(subId).then((data:any)=>{
        this.subject=data;
        this.getEvent(eventId,batchId);

      })
    }
    getEvent(eventId,batchId){
      this.eventService.getDeadlineStatus(eventId).then((data:any)=>{
        this.status=data;
        if(this.status.errorStatus){
          const modalRef = this.modalService.open(AttendanceRestrictComponent,{size:"lg",backdrop:'static'});
          
        }
        else{
          this.eventService.getEventtable(eventId).then((data:any)=>{
            this.eventData=data;
            const modalRef= this.modalService.open(AttendancePopupComponent,{size:"lg",backdrop:'static'});
            modalRef.componentInstance.value = this.eventData;
            modalRef.componentInstance.subValue = this.subject;
            modalRef.componentInstance.batchId = batchId;
            modalRef.componentInstance.reload.subscribe(() => {
              this.reload();
            }) 

          })
        }
      })

    }
    reload(){
      this.getFacultyEvents();
    }
}
