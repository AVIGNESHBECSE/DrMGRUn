import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { DepartmentService } from 'src/services/DepartmentService';
import { EventService } from 'src/services/EventService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
import { RegulationService } from 'src/services/RegulationService';
import { SubjectService } from 'src/services/SubjectService';
import { AttendancePopupComponent } from '../attendance-popup/attendance-popup.component';
import { AttendanceRestrictComponent } from '../attendance-restrict/attendance-restrict.component';

@Component({
  selector: 'app-subject-attendance',
  templateUrl: './subject-attendance.component.html',
  styleUrls: ['./subject-attendance.component.css']
})
export class SubjectAttendanceComponent implements OnInit {
  departments: unknown;
dept:any;
  regulations: any;
  reg:any;
  sub:any;
  subjects: any;
  batches: any;
  batchId:any;
  date:any;
  ranges: any = [
    {
      value: [new Date(new Date().setDate(new Date().getDate())), new Date()],
      label: 'Today',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 1)),
        new Date(new Date().setDate(new Date().getDate() - 1)),
      ],
      label: 'Yesterday',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 7)),
        new Date(),
      ],
      label: 'Last 7 Days',
    },
   
  ];
  startDate=new Date();
  endDate= new Date();
  fromDate: string;
  toDate: string;
  subjectEvents: any;
  present: number;
  absent: number;
  eventData: any;
  status: any;
  subject: any;
  showTable: boolean;

  constructor( private loading: LoadingAlertService,
    private departmentService: DepartmentService,
    private regulationService:RegulationService,
    private subjectService: SubjectService,
    private modalService: NgbModal,
    private eventService:EventService) { }

  ngOnInit(): void {
    this.onload();
  }
  demo($event:any){
    this.startDate=$event[0].toString();
    this.endDate=$event[1].toString();
    this.fromDate=moment(new Date(this.startDate)).format('DD-MMM-YYYY');
    this.toDate=moment(new Date(this.endDate)).format('DD-MMM-YYYY');
    
    }
  onload() {
    this.loading.showLoading();
    this.departmentService.getDepartment().then(
      data => {
        this.departments = data
        this.loading.hideLoading()
      })

  }
  onChange(dept){
    this.loading.showLoading();
    this.regulationService.list(dept.id).then((data:any)=>{
      this.regulations=data.datas;
    })
    this.loading.hideLoading();

  }

  getSubjects(reg){
this.loading.showLoading();
this.regulationService.getByRegulationId(reg.id).then((data:any)=>{
  this.subjects=data.datas;
})
  }


  getBatches(sub){
    this.subjectService.getActiveBatch(sub.id).then((data:any)=>{
      this.batches=data;
      this.batches.sort((a,b)=>a.batchName.localeCompare(b.batchName));
    })

  }

  getSubjectEvents(batchId){
    this.eventService.getSubjectTimetable(this.fromDate,this.toDate,batchId).then((data:any)=>{
      this.subjectEvents=data;
      if(this.subjectEvents.length != 0){
        this.showTable=true;
      }
      else{
        this.showTable=false;
      }
    })
  }

  totalPresent(eachEvent){
    this.present=0;
    this.absent=0;
          for (var i=0; i<eachEvent.attendance.length; i++) {
             if (eachEvent.attendance[i].status == "PRESENT") {
                this.present = this.present+1;
             } else {
             this.absent = this.absent+1;
             }
           }
            return "Tot Pre:" + this.present + " Tot Abs:" + this.absent;
  }
  getEventStudentListVal(eventId,subId,batchId){
    this.subjectService.getSubjectById(subId).then((data:any)=>{
      this.subject=data;
      this.getEvent(eventId,batchId);

    })
  }
  getEvent(eventId,batchId){
    this.eventService.getDeadlineStatus(eventId).then((data:any)=>{
      this.status=data;
      if(this.status.errorStatus){
        const modalRef = this.modalService.open(AttendanceRestrictComponent,{size:"lg",backdrop:'static'});
        
      }
      else{
        this.eventService.getEventtable(eventId).then((data:any)=>{
          this.eventData=data;
          const modalRef= this.modalService.open(AttendancePopupComponent,{size:"lg",backdrop:'static'});
          modalRef.componentInstance.value = this.eventData;
          modalRef.componentInstance.subValue = this.subject;
          modalRef.componentInstance.batchId = batchId;
          modalRef.componentInstance.reload.subscribe(() => {
            this.reload();
          }) 

        })
      }
    })

  }
  reload(){
    this.getSubjectEvents(this.batchId);
  }
}
