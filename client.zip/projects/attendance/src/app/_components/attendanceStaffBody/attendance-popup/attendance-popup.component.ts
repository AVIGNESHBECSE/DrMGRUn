import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { ConfigService } from 'src/services/ConfigService';
import { LessonPlanService } from 'src/services/LessonPlanService';
import { UserService } from 'src/services/UserService';
import { DatePipe } from '@angular/common';
import { CopyAttendanceComponent } from '../copy-attendance/copy-attendance.component';
import { FileValidationService } from 'src/services/FileValidationService';
import { FileUploadService } from 'src/services/FileUploadService';
import { AttendanceRestrictComponent } from '../attendance-restrict/attendance-restrict.component';
import { EventService } from 'src/services/EventService';
import { CompletedLPPopupComponent } from '../completed-lppopup/completed-lppopup.component';

@Component({
  selector: 'app-attendance-popup',
  templateUrl: './attendance-popup.component.html',
  styleUrls: ['./attendance-popup.component.css']
})
export class AttendancePopupComponent implements OnInit {
  @Input() value: any;
  @Input() subValue: any;
  @Input() batchId: any;
  @Output('reload') reload=new EventEmitter();


  filterType: any;
  configData: any;
  arr: any;
  pedagogyTypes: any=[];
  lessonPlanData: any;
  completedLPDs: any;
  studentList: any;
  totalStudentCount: any;
  fileDetails:any;
  studentListAttendanced: any;
  studIds:any= [];
  NotAppId:any=[];
  lessonPlanPedagogy: any;
  presentCount: number;
  absentCount: number;
  notAppCount: number;
  studRegNoList:any=[];
  studentListNew: any=[];
  showLessonPlan: boolean;
  selectedFile:any={};
  selectedLessonPlan:any={};

  showLessonPlanDetails: boolean;
  showOther: boolean;
  completedLpd: any;
  fileAttached: boolean;
  fileToUpload: File;
  fileLable: string;
  showBrowse: boolean;
  createdFile: any;
  showLabel: boolean;
  showUploadButton: boolean;
  deletedFile: any;
  lessonplanlp:any;
  pedagogylp:any;
  attendance:any=[];
  val:any={};
  event:any={};
  status: any;
  updateEventData: any;
  lessonPlanError: string;
  mSelect: string;
  disabledStudents:any = [];

  constructor(
    private modalService: NgbModal,
    private activeModal: NgbActiveModal,
    public toasterService: ToastrService,
    private configService: ConfigService,
    private userService: UserService,
    private lessonPlanService: LessonPlanService,
    private datePipe: DatePipe,
    private fileValidator: FileValidationService,
    private fileUploadService: FileUploadService,
    private eventService: EventService
  ) { }

  ngOnInit(): void {
    if (this.subValue.subbat != undefined) {
      for (var i = 0; i < this.subValue.subbat.length; i++) {
        if (this.subValue.subbat[i].batid == this.value.batid) {
          this.filterType = this.value.type;
          this.getEventStudentList(this.value.id, this.subValue.id, this.batchId);
          break;
        } else if (i == this.subValue.subbat.length - 1) {

          this.toasterService.error("You have created batch after creating timetable. Please use edit option to select batch");
        }
      }
    }
    else {
      this.filterType = this.value.type;
      this.getEventStudentList(this.value.id, this.subValue.id, this.batchId);
    }
 
    this.configService.getConfig().then((data:any)=>{
      this.configData=data;
      this.arr =this.configData.pedagogy[0];
      for (const key in this.arr) {
          // if (key != 'fromDate')
              this.pedagogyTypes.push({
                  'value': key,
                  'name': this.arr[key]
              })
      }
    })

    this.lessonPlanService.getLessonPlan(this.subValue.id).then((data:any)=>{
      this.lessonPlanData=data;
    })
    this.lessonPlanService.getCompletedLPD(this.subValue.id).then((data:any)=>{
      this.completedLPDs=data;
    })


  }

  
  isCompleted(lessonPlan){
    if (this.completedLPDs != undefined){
      for(var i = 0; i < this.completedLPDs.length; i++ ) {
        if (this.completedLPDs[i].id == lessonPlan.id){
          if (this.completedLPDs[i].plannedEvents.length > 0){
            return true;
          }
        }
      }
      }
  }

  getCompletedLessonPlan(lessonPlanId){
    if (this.completedLPDs != undefined){
      for(var i = 0; i < this.completedLPDs.length; i++ ) {
        if (this.completedLPDs[i].id == lessonPlanId){
            this.completedLpd = this.completedLPDs[i];
const modelRef=this.modalService.open(CompletedLPPopupComponent,{size:"lg",backdrop:'static'});
modelRef.componentInstance.value=this.completedLpd;
            break;
        }
      }
      }
  }
  getEventStudentList(eventId, subjectId, batchId) {
    this.showLessonPlan = false;

    if (batchId === undefined || batchId === '') {
      var value = eventId + "/" + subjectId + "?token=";
    }
    else {
      var value = eventId + "/" + subjectId + "?filter=bId eq" + batchId + "&token=";
    }
       this.userService.getStudSubject(value).then((data: any) => {
       this.studentList = data;

       for(var i=0;i<this.studentList.length;i++){
        if(this.studentList[i].accountStatus == 'DISABLE'){
          this.disabledStudents.push(this.studentList[i]);
          this.studentList.splice(i, 1);
        }
       }

      this.totalStudentCount = this.studentList.length; 
    
      if (this.value != undefined && this.value.attendance === undefined) {
        for (var k = 0; k < this.studentList.length; k++) {
          if (this.studentList[k].status != undefined) {
            this.studentList[k].selected = this.studentList[k].status === "PRESENT" ? "true" : "false";
          } else {
            this.studentList[k].selected = undefined;
          }
          console.log("this is for empty attendance");
        }
      }
      else if (this.value != undefined && this.value.attendance != undefined) {
        this.studentListAttendanced = this.value.attendance;

for (var u = 0; u < this.studentListAttendanced.length; u++) {
this.studIds.push(this.studentListAttendanced[u].userid)
}
        for (var i = 0; i < this.studentList.length; i++) {
            for (var j = 0; j < this.studentListAttendanced.length; j++) {

                if (this.studentListAttendanced[j].userid === this.studentList[i].id) {
                    this.studentList[i].selected = this.studentListAttendanced[j].status === "PRESENT" ? "true" : "false";
                    this.studentList[i].status = this.studentListAttendanced[j].status === "PRESENT" ? "true" : "false";
                }

}
if(!this.studIds.includes(this.studentList[i].id)){
  this.studentList[i].selected = "notApp";
  this.studentList[i].status == "notApp";
    this.NotAppId.push(this.studentList[i].id);

}
}
}
if (this.value != undefined && this.value.attendance != undefined && this.value.type === "lessonplandelivery" && this.value.lessonPlanId != undefined && this.value.pedagogy != undefined) {
for (var i = 0; i < this.pedagogyTypes.length; i++) {
if (this.pedagogyTypes[i].value === this.value.pedagogy) {

    this.lessonPlanPedagogy = this.pedagogyTypes[i].name;
}
}
if (this.lessonPlanPedagogy != undefined) {
for (var i = 0; i < this.lessonPlanData.length; i++) {
    if (this.lessonPlanData[i].id === this.value.lessonPlanId) {
      this.selectedLessonPlan.id=this.value.lessonPlanId;
      this.selectedLessonPlan.pedagogy=this.value.pedagogy;
        this.lessonPlanData[i].pedagogy = this.lessonPlanPedagogy;
    }
}
}

}
this.getStudentPresentCount(this.studentList);

    })
    
  }  

  multiSelect(multiValue){
    if(multiValue == "multiPre"){
this.mSelect = "true";
    }
    if(multiValue == "multiAbs"){
      this.mSelect = "false";
    }
    if(multiValue == "multiNotApp"){
      this.mSelect = "notApp"
    }
    for(var i=0;i<this.studentList.length;i++){
      this.studentList[i].selected=this.mSelect;
      this.studentList[i].status=this.mSelect;
    }
    this.getStudentPresentCount(this.studentList);
  }

  getStudentPresentCount(studentList) {
        this.presentCount = 0;
        this.absentCount = 0;
this.notAppCount=0;
        for(var i=0; i<studentList.length; i++){
      
       if(studentList[i].selected=="notApp"){
this.notAppCount=this.notAppCount+1;


}
        if(studentList[i].selected != null && studentList[i].selected=="true"){
            this.presentCount = this.presentCount +  1;
            var index = this.studRegNoList.indexOf(studentList[i].registerNo);
            if(index > -1){
              this.studRegNoList.splice(index, 1);
            }
          } if(studentList[i].selected == "false"){
            this.absentCount = this.absentCount +  1;
            if(this.studRegNoList.indexOf(studentList[i].registerNo) < 0){
            this.studRegNoList.push(studentList[i].registerNo)
            }

          } 


        }
        this.studRegNoList.sort(function(a, b){return a - b});
      }

      updateStudentStaffWarning(subId, stdList){
        var count=0;
		    	 for (var i=0; i < stdList.length; i++) {
		    		 if (stdList[i].selected != undefined) {
		    			count++;
		    	 }	
		         }
		         if (stdList.length == count) {
		        	 this.updateStudentAttendance(subId);
	        	 } else {
	        		const modelRef=this.modalService.open(CopyAttendanceComponent,{size:"lg",backdrop:'static'});
	        		 
	        	 }
      }
      updateStudentAttendance(subId){
		    	 this.showLessonPlan = true;
		        if (this.filterType === undefined || this.filterType === "lessonplandelivery") {
			        this.filterType = 'lessonplandelivery';
			        this.getLessonPlan(this.filterType);
			    } else if (this.filterType === "other") {
            this.filterType = 'other';
			    	this.getLessonPlan(this.filterType);
			    }
      }
      source(sourceType){
        this.value.sourceType=sourceType;
      }
      getLessonPlan(filter){
        if(filter === "lessonplandelivery") {
          this.filterType=filter;
          this.showLessonPlanDetails = true;
          this.showOther = false;
        } else {
          this.filterType=filter;
          this.showLessonPlanDetails = false;
          this.showOther = true;
        }
      }
      resetAttendance(){
        for(var i=0; i<this.studentList.length; i++){
          this.studentList[i].selected = undefined;
          this.studRegNoList = [];
        }
        this.getStudentPresentCount(this.studentList);
      }

      statusUpdate(index,val){
        this.studentList[index].status = val;
        this.studentList[index].selected = val;
                this.getStudentPresentCount(this.studentList);
      }
  close(){
    this.activeModal.close();

  }
  change(files: FileList) {

    this.fileAttached = true;
    this.fileToUpload = files.item(0);
    if (this.fileValidator.validate(this.fileToUpload) == true) {

      this.fileLable = this.fileToUpload.name;
      this.showUploadButton = true;
      this.showLabel=false;
    }
    else {
      this.showLabel = true;
      return this.fileToUpload = null
    }
  }
  
  uploadAttachment(){
    this.fileUploadService.uploadFileData(this.fileToUpload).then((data:any)=>{
      this.createdFile=data;
      this.selectedFile.fileKey=this.createdFile.fileKey;
      this.selectedFile.versionId=this.createdFile.versionId;
    })

  }
  removeFile(){
    this.fileUploadService.deleteFile(this.selectedFile.versionId,this.selectedFile.fileKey).then((data:any)=>{
      this.deletedFile=data;
    })
    this.selectedFile = {};
  }

  selectlpd(selectedId) {
    this.selectedLessonPlan.id=selectedId;
   }

cancelStudentAttendanceEvent(){
  this.activeModal.close();
}
updateStudentAttendanceOther(subId){
    for (var i = 0; i < this.studentList.length; i++) {
        this.val = {};
        this.val.userid = this.studentList[i].id;
if (this.studentList[i].selected == "notApp") {

this.studentList[i].id
continue;

}			           
else if (this.studentList[i].selected == "true") {
            this.val.status = "PRESENT";
        } else {
            this.val.status = "ABSENT";
        }
        this.attendance.push(this.val);
    }

    this.event.id = this.value.id;
    this.event.batid = this.batchId;
    this.event.comments = this.value.comments;
    this.event.source = this.value.source;
    this.event.attachment = this.selectedFile;
    this.event.lessonPlanId = "";
    this.event.etype="other";
    this.event.attendance = this.attendance;
    this.eventService.getDeadlineStatus(this.value.id).then((data:any)=>{
      this.status=data;
      if(this.status.errorStatus){
        const modalRef = this.modalService.open(AttendanceRestrictComponent,{size:"lg",backdrop:'static'});
        
      }
       else {
    if(this.event.attendance.length > 0) {
    this.eventService.updateAttendance(this.event.id,this.event).then((data:any)=>{
      this.updateEventData=data;
      this.reload.emit();

    });
  }
}
    })
 this.activeModal.close(); 
  
}  
getPedagogy(pedagogy){
  for(var i=0;i<this.pedagogyTypes.length;i++){
    if(this.pedagogyTypes[i].name == pedagogy){
      this.selectedLessonPlan.pedagogy=this.pedagogyTypes[i].value;
    }
    
  }
}

updateStudentAttendanceEvent(){
		    	var lessonplanId = this.selectedLessonPlan.id;
		    	if (lessonplanId == undefined || lessonplanId == "") {
		    		this.lessonPlanError = "Please select any one lessonplan Details";
		    	} else {
		        for (var i = 0; i < this.studentList.length; i++) {
              this.val = {};
		            this.val.userid = this.studentList[i].id;
if (this.studentList[i].selected == "notApp") {
					this.studentList[i].id
					continue;
				}			           
		           else if (this.studentList[i].selected == "true") {
		                this.val.status = "PRESENT";
		            } else {
		                this.val.status = "ABSENT";
		            }
		            this.attendance.push(this.val);
		        }
		        
		        this.event.id = this.value.id;
		        this.event.batid = this.batchId;
		        this.event.source = this.value.source;
		        this.event.attachment = this.selectedFile;
		        this.event.topicscovered = "";
		        this.event.unit = "";
		        this.event.comments = "";
		        this.event.etype = "lessonplandelivery";
		        this.event.lessonPlanId = this.selectedLessonPlan.id;
            this.event.pedagogy = this.selectedLessonPlan.pedagogy;
            this.event.attendance = this.attendance;
            this.eventService.getDeadlineStatus(this.value.id).then((data:any)=>{
              this.status=data;
              if(this.status.errorStatus){
                const modalRef = this.modalService.open(AttendanceRestrictComponent,{size:"lg",backdrop:'static'});
                
              } else {
		        if(this.event.attendance.length > 0) {
              this.eventService.updateAttendance(this.event.id,this.event).then((data:any)=>{
                this.updateEventData=data;
                this.reload.emit()

		           
		        });
		        
		    	}
		    	}
     	    	 });
     	    
		    	}
this.activeModal.close();
}
}
