import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendancePopupComponent } from './attendance-popup.component';

describe('AttendancePopupComponent', () => {
  let component: AttendancePopupComponent;
  let fixture: ComponentFixture<AttendancePopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AttendancePopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendancePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
