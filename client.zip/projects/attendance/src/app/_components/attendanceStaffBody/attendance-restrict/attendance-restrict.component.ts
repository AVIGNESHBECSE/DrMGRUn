import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-attendance-restrict',
  templateUrl: './attendance-restrict.component.html',
  styleUrls: ['./attendance-restrict.component.css']
})
export class AttendanceRestrictComponent implements OnInit {

  constructor(   private ngmodel: NgbModal, 
    private activeModal: NgbActiveModal) { }

  ngOnInit(): void {
  }

  close(){
    this.activeModal.close();
  }
}
