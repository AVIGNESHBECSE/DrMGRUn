import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendanceRestrictComponent } from './attendance-restrict.component';

describe('AttendanceRestrictComponent', () => {
  let component: AttendanceRestrictComponent;
  let fixture: ComponentFixture<AttendanceRestrictComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AttendanceRestrictComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendanceRestrictComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
