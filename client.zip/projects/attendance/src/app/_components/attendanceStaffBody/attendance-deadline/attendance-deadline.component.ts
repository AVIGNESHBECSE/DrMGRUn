import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EventService } from 'src/services/EventService';

@Component({
  selector: 'app-attendance-deadline',
  templateUrl: './attendance-deadline.component.html',
  styleUrls: ['./attendance-deadline.component.css']
})
export class AttendanceDeadlineComponent implements OnInit {
  deadLine: any;

  constructor(private eventService: EventService,
    private ngmodel: NgbModal, 
    private activeModal: NgbActiveModal) { }

  ngOnInit(): void {
    this.getDeadLine();
  }
getDeadLine(){
  this.eventService.getAttendanceDeadline().then((data:any)=>{
    this.deadLine=data;
  });
}

close(){
  this.activeModal.close();
}
}
