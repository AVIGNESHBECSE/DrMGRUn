import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompletedLPPopupComponent } from './completed-lppopup.component';

describe('CompletedLPPopupComponent', () => {
  let component: CompletedLPPopupComponent;
  let fixture: ComponentFixture<CompletedLPPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompletedLPPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompletedLPPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
