import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-completed-lppopup',
  templateUrl: './completed-lppopup.component.html',
  styleUrls: ['./completed-lppopup.component.css']
})
export class CompletedLPPopupComponent implements OnInit {
@Input() value:any;
  constructor( private ngmodel: NgbModal, 
    private activeModal: NgbActiveModal) { }

  ngOnInit(): void {
  }
close(){
  this.activeModal.close();
}
}
