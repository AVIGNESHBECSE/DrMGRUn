import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EventService } from 'src/services/EventService';
import { AttendanceTimeLimitComponent } from '../attendance-time-limit/attendance-time-limit.component';
import { EditAttendanceTimeLimitComponent } from '../edit-attendance-time-limit/edit-attendance-time-limit.component';

@Component({
  selector: 'app-attendance-settings',
  templateUrl: './attendance-settings.component.html',
  styleUrls: ['./attendance-settings.component.css']
})
export class AttendanceSettingsComponent implements OnInit {
  deadLine: any;

  constructor(private eventService: EventService,private router:Router,
    private route: ActivatedRoute,private modalService: NgbModal) { }

  ngOnInit(): void {
    this.getDeadLine();
  }
getDeadLine(){
  this.eventService.getAttendanceDeadline().then((data:any)=>{
    this.deadLine=data;
  });
}

backToHome(){
  this.router.navigate(['/attendance/staffHome']);
}
createDeptTimeLimit(){
  const modalRef = this.modalService.open(AttendanceTimeLimitComponent,{size:"lg",backdrop:'static'});
  modalRef.componentInstance.value=this.deadLine[0];
  modalRef.componentInstance.reload.subscribe(()=>{
    this.reload();
  }
  )
}
reload(){
  this.getDeadLine();
}
editDeadLine(eachDeadLine,index){
  const modalRef = this.modalService.open(EditAttendanceTimeLimitComponent,{size:"lg",backdrop:'static'});
  modalRef.componentInstance.value=eachDeadLine;
  modalRef.componentInstance.totValue=this.deadLine[0];
  modalRef.componentInstance.index=index;
  modalRef.componentInstance.reload.subscribe(()=>{
    this.reload();
  })
}
}
