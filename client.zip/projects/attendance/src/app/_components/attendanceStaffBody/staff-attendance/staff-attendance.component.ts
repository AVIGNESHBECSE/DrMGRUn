import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { EventService } from 'src/services/EventService';
import { FacultyDepartmentService } from 'src/services/FacultyDepartmentService';
import { SubjectService } from 'src/services/SubjectService';
import { UserService } from 'src/services/UserService';
import { AttendancePopupComponent } from '../attendance-popup/attendance-popup.component';
import { AttendanceRestrictComponent } from '../attendance-restrict/attendance-restrict.component';

@Component({
  selector: 'app-staff-attendance',
  templateUrl: './staff-attendance.component.html',
  styleUrls: ['./staff-attendance.component.css']
})
export class StaffAttendanceComponent implements OnInit {
  facultyDepts: any;
fac:any;
  staffs: any;
  staff:any;
  ranges: any = [
    {
      value: [new Date(new Date().setDate(new Date().getDate())), new Date()],
      label: 'Today',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 1)),
        new Date(new Date().setDate(new Date().getDate() - 1)),
      ],
      label: 'Yesterday',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 7)),
        new Date(),
      ],
      label: 'Last 7 Days',
    },
   
  ];
 
  startDate=new Date();
  endDate=new Date();
  fromDate: string;
  toDate: string;
  staffHandledEvents: any;
  present: number;
  absent: number;
  eventData: any;
  status: any;
  subject: any;
  showTable: boolean;
  constructor(private facDeptService:FacultyDepartmentService,
    private userService:UserService,
    private eventService:EventService,
    private subjectService: SubjectService,
    private modalService: NgbModal,) { }

  ngOnInit(): void {
    this.getFaculty();
  }
getFaculty(){
  this.facDeptService.getAllFacultyDepartments().then((data:any)=>{
    this.facultyDepts=data;
  })
}
onChange(fac){
this.userService.getFacultyDepDatas(fac.id).then((data:any)=>{
  this.staffs=data;
})
}

selectedStaff(staff){
this.selectedStaff=staff.id;
}
demo($event:any){
  this.startDate=$event[0].toString();
  this.endDate=$event[1].toString();
  this.fromDate=moment(new Date(this.startDate)).format('DD-MMM-YYYY');
  this.toDate=moment(new Date(this.endDate)).format('DD-MMM-YYYY');
  
  }
getStaffHandleEvents(){
  this.eventService.getStaffAttendance(this.fromDate,this.toDate,this.selectedStaff).then((data:any)=>{
    this.staffHandledEvents=data;
    if(this.staffHandledEvents.length != 0){
      this.showTable=true;
    }
    else{
      this.showTable=false;
    }
  })

}
totalPresent(eachEvent){
  this.present=0;
  this.absent=0;
        for (var i=0; i<eachEvent.attendance.length; i++) {
           if (eachEvent.attendance[i].status == "PRESENT") {
              this.present = this.present+1;
           } else {
           this.absent = this.absent+1;
           }
         }
          return "Tot Pre:" + this.present + " Tot Abs:" + this.absent;
}

getEventStudentListVal(eventId,subId,batchId){
  this.subjectService.getSubjectById(subId).then((data:any)=>{
    this.subject=data;
    this.getEvent(eventId,batchId);

  })
}
getEvent(eventId,batchId){
  this.eventService.getDeadlineStatus(eventId).then((data:any)=>{
    this.status=data;
    if(this.status.errorStatus){
      const modalRef = this.modalService.open(AttendanceRestrictComponent,{size:"lg",backdrop:'static'});
      
    }
    else{
      this.eventService.getEventtable(eventId).then((data:any)=>{
        this.eventData=data;
        const modalRef= this.modalService.open(AttendancePopupComponent,{size:"lg",backdrop:'static'});
        modalRef.componentInstance.value = this.eventData;
        modalRef.componentInstance.subValue = this.subject;
        modalRef.componentInstance.batchId = batchId;
        modalRef.componentInstance.reload.subscribe(() => {
          this.reload();
        }) 

      })
    }
  })

}
reload(){
  this.getStaffHandleEvents();
}
}
