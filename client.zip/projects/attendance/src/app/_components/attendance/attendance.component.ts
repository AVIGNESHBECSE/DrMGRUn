import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { EventService } from 'src/services/EventService';
import { UserService } from 'src/services/UserService';
import { PopupComponent } from '../popup/popup.component';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit { 
  currentUser: any;
  singleUser: any;
  dateCtrl:any;
  fromDate: string;
  toDate: any;
  events: any;
  event: any;

  constructor( private userService :UserService,
    private modalService: NgbModal,
    private router: Router, 
    private toastr:ToastrService, 
    private eventSerive:EventService,
    private datePipe:DatePipe,
    ) { 
     
   }

 ngOnInit(): void {
   

  

   this.getCurrentUser();
  
   this. getSingleUser();
 }
   
 

 


 getCurrentUser(){
   this.userService.getCurrentUser().then((data:any)=>{
     this.currentUser = data;
   
    
   });
 }


 getSingleUser() {
   this.userService.getSingleUser().then((data: any) => {
     this.singleUser = data;
   
   });
 }


 getEvents(date) {
  this.datePipe.transform(date, 'yyyy/MM/dd')
  this.fromDate =  this.datePipe.transform(date, 'dd-MMM-yyyy');
  this.toDate=this.datePipe.transform(date, 'dd-MMM-yyyy');
  console.log(this.fromDate+"vfdgfdgvdf"+ this.toDate);
this.eventSerive.getEventAttendents(this.fromDate,this.toDate).then((data: any) => {
  
    this.events = data;
});
 }


showEventDetailsPopup(event){
  const modalRef = this.modalService.open(PopupComponent, { size:"lg"});
  modalRef.componentInstance.value = event;
  
}

}
