import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';

import { AttendanceComponent } from './_components/attendance/attendance.component';
import { AttendanceDeadlineComponent } from './_components/attendanceStaffBody/attendance-deadline/attendance-deadline.component';
import { AttendanceHomeComponent } from './_components/attendanceStaffBody/attendance-home/attendance-home.component';
import { AttendancePopupComponent } from './_components/attendanceStaffBody/attendance-popup/attendance-popup.component';
import { AttendanceRestrictComponent } from './_components/attendanceStaffBody/attendance-restrict/attendance-restrict.component';
import { AttendanceSettingsComponent } from './_components/attendanceStaffBody/attendance-settings/attendance-settings.component';
import { AttendanceTimeLimitComponent } from './_components/attendanceStaffBody/attendance-time-limit/attendance-time-limit.component';
import { CompletedLPPopupComponent } from './_components/attendanceStaffBody/completed-lppopup/completed-lppopup.component';
import { CopyAttendanceComponent } from './_components/attendanceStaffBody/copy-attendance/copy-attendance.component';
import { DepartmentAttendanceComponent } from './_components/attendanceStaffBody/department-attendance/department-attendance.component';
import { EditAttendanceTimeLimitComponent } from './_components/attendanceStaffBody/edit-attendance-time-limit/edit-attendance-time-limit.component';
import { MyAttendanceComponent } from './_components/attendanceStaffBody/my-attendance/my-attendance.component';
import { StaffAttendanceComponent } from './_components/attendanceStaffBody/staff-attendance/staff-attendance.component';
import { SubjectAttendanceComponent } from './_components/attendanceStaffBody/subject-attendance/subject-attendance.component';
const routes: Routes = [
  {path:'', redirectTo:'home',pathMatch:'full'},
  { path: '', component: AppComponent ,children:[
    { path: 'home', component: AttendanceComponent },
    { path:'staffHome', component: AttendanceHomeComponent,children:[
      {path:'',redirectTo:'myAttendance',pathMatch:'full'},
      { path: 'myAttendance', component: MyAttendanceComponent},
      { path: 'subAttendance', component: SubjectAttendanceComponent},
      { path: 'staffAttendance', component: StaffAttendanceComponent},
      { path: 'deptAttendance', component: DepartmentAttendanceComponent},
      ] },
    { path: 'attDeadline', component: AttendanceDeadlineComponent},
    { path: 'attSettings', component: AttendanceSettingsComponent},
    {path:'attendanceModal', component: AttendancePopupComponent},
    {path: 'attendanceRestrict', component: AttendanceRestrictComponent},
    {path: 'copyAtt', component: CopyAttendanceComponent},
    {path: 'completedLP', component: CompletedLPPopupComponent},
    {path: 'timeLimit', component: AttendanceTimeLimitComponent},
    {path: 'editAttTimeLimit', component:EditAttendanceTimeLimitComponent}
  ]
}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
