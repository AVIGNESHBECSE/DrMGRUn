import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssignmentComponent } from './_components/assignment/assignment.component';
import { ComposeAssignmentComponent } from './_components/assignment/composeAssignment/composeAssignment.component';
import { AssignmentParentComponent } from './_components/assignment/assignment-parent/assignment-parent.component';
import { StudentViewComponent } from './_components/assignment/studentView/studentView.component';
import { StudentSubmissionComponent } from './_components/assignment/studentSubmission/studentSubmission.component';

const routes: Routes = [
 {path:'', redirectTo:'home',pathMatch:'full'},
  { path: '', component: AssignmentParentComponent ,children:[
    { path: 'home', component: AssignmentComponent },
    { path: 'compose', component: ComposeAssignmentComponent },
   { path: 'studentView', component: StudentViewComponent },
   { path: 'viewSubmission/:id', component: StudentSubmissionComponent }
  ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
