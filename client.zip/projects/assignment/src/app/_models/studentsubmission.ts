export class Studentsubmission {
    id: string;
    name: string;
    filekey: string;
    attendanceDate:string;
}