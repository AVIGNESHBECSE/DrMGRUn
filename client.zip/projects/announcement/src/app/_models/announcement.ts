export class Announcement {
    id: string;
    title: string;
    createdOn: string;
    name:string;
    fileKey:string;
}