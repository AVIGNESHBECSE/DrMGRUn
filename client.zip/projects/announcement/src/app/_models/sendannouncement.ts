export class Sendannouncement {
    id: string;
    title: string;
    createdOn: string;
    fileKey:string;
}