import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AnnouncementService } from 'src/services/AnnouncementService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
import { SmsService } from 'src/services/SmsService';
// import { AnnouncementService } from 'projects/Shared-providerAndService/Announcement-ServiceAndProvider/AnnouncementService';
// import { LoadingAlertService } from 'src/app/common/service/loadingAlert.service';
 
@Component({
  selector: 'app-monthly-sms',
  templateUrl: './monthly-sms.component.html',
  styleUrls: ['./monthly-sms.component.css']
})
export class MonthlySmsComponent implements OnInit {
  smsCount: any;
  smsReview: any;

  constructor(private smsService:SmsService,
    private loadingService:LoadingAlertService,
    private datepipe:DatePipe) { }

  ngOnInit(): void {
  this.getMonthly()
  this.smsCount()
  }

  getMonthly(){
    this.loadingService.showLoading();
    this.smsService.getMonthlySms().then((data:any)=>{
      this.smsReview = data;
      //console.log(this.smsCount)
    })
    this.loadingService.hideLoading();
    
}
getSmsCount(){
  this.loadingService.showLoading();
  this.smsService.getSmsCount().then((data:any)=>{
    this.smsCount = data;
    //console.log(this.smsCount)
  })
  this.loadingService.hideLoading();
  }


  exportAsXLSX(id) {
    this.smsService.exportAsXLSX(id);
   
  }

}
