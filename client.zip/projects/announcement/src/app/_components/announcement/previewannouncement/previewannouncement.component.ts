import { Component, Input, OnInit } from '@angular/core';
import { AnnouncementService } from 'src/services/AnnouncementService';
// import { SelectMembersService } from 'projects/Shared-providerAndService/Announcement-ServiceAndProvider/SelectMemberService';
 
@Component({
  selector: 'app-previewannouncement',
  templateUrl: './previewannouncement.component.html',
  styleUrls: ['./previewannouncement.component.css']
})
export class PreviewannouncementComponent implements OnInit {
  announcement:any;

  // constructor(private selectMembersService :SelectMembersService) { }
  constructor(private announcementService :AnnouncementService) { }
  ngOnInit() {
    this.announcement ={};
    this.announcementData()
  }
announcementData():any{
  this.announcement = this.announcementService.announcementData;
}  
}
