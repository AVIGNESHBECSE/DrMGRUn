import { Component, OnInit } from '@angular/core';

import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Announcement } from 'src/models/Announcement';
import { AnnouncementService } from 'src/services/AnnouncementService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
// import { Announcement } from '../../_models/announcement';
  // import { LoadingAlertService } from 'src/app/common/service/loadingAlert.service';
import { PopmodelComponent } from './displayMessage/popmodel/popmodel.component';
import { ViewHomeMessageComponent } from './view-home-message/view-home-message.component';
// import { AnnouncementService } from 'projects/Shared-providerAndService/Announcement-ServiceAndProvider/AnnouncementService';

@Component({
  selector: 'app-announcement',
  templateUrl: './announcement.component.html',
  styleUrls: ['./announcement.component.css']
})
export class AnnouncementComponent implements OnInit {
  
  public announcements:any [];
  public loading :boolean;
  page = 1;
  pageSize =50;
  constructor(private modalService: NgbModal, 
              private announcementService:AnnouncementService,
              private loadingService :LoadingAlertService) { }

  ngOnInit() {
    this.getAnnouncement();
    this.announcements=[]
  }

  getAnnouncement()
  {
    this.loadingService.showLoading();
   this.announcementService.getCurrentUserAnnouncement().then((data:Announcement[])=>{
     this.announcements = data;
     this.announcements = this.announcements.sort((a, b) => {
      const dateA = new Date(a.createdOn).getTime();
      const dateB = new Date(b.createdOn).getTime();
      return dateB - dateA;
    });
     this.loadingService.hideLoading();
   });

       
 }

//  viewMessage(announcement) {
//   const modalRef = this.modalService.open(PopmodelComponent,{size:"lg"});
//   //modalRef.componentInstance.facultyDepartments = this.facultyDepartments;
//    modalRef.componentInstance.value = announcement;
// }


viewMessage(announcement) {
  const modalRef = this.modalService.open(ViewHomeMessageComponent,{size:"lg"});
   modalRef.componentInstance.value = announcement;
}

}
