import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AnnouncementService } from 'src/services/AnnouncementService';
import { LoadingAlertService } from 'src/services/LoadingAlertService';
// import { AnnouncementService } from 'projects/Shared-providerAndService/Announcement-ServiceAndProvider/AnnouncementService';
// import { LoadingAlertService } from 'src/app/common/service/loadingAlert.service';
 

@Component({
  selector: 'app-view-home-message',
  templateUrl: './view-home-message.component.html',
  styleUrls: ['./view-home-message.component.css']
})
export class ViewHomeMessageComponent implements OnInit {
  @Input() value;
  constructor(public activeModal: NgbActiveModal,
    private announcementService : AnnouncementService,
                private modalService: NgbModal,
           
                private loadingService : LoadingAlertService) { }

  ngOnInit(): void {
  }

}
