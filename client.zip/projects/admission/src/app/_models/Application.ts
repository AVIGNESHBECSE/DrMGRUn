export class Application {
  public name: string;
  public fees: string;
  public rule: Array<string>;
  public courseName :Array<string>;
}
