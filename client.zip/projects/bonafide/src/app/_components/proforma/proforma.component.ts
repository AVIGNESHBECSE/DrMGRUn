import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router ,RoutesRecognized } from '@angular/router';
import { LoadingAlertService } from 'src/app/common/service/loadingAlert.service';
import { BonafideService } from 'src/services/BonafideService';
import { StudentService } from 'src/services/StudentService';
import { AccyearService } from 'src/services/AccyearService';
import { DepartmentService } from 'src/services/DepartmentService';
import { DatePipe, Location } from '@angular/common';
import * as moment from 'moment';
@Component({
  selector: 'app-proforma',
  templateUrl: './proforma.component.html',
  styleUrls: ['./proforma.component.css']
})
export class ProformaComponent implements OnInit {
  save1={
    companyInfo:{
      companyName:'',
      address:'',
      address2:'',
      city:'',
      district:'',
      state:'',
      pincode:'',
    },
    proposedPeriod:'',
    refNo:'',
    issueDate:'',
    studentName:'',
    studentPhone:'',
    gender:'',
    registerNumber:'',
    year:0,
    course:'',
    bonafide:'',
    purposeOfApplication:'',
    currentYear:'',
    signature:''
  };
  student: any;
  startYear: number;
  accYear: any;
  current: any;
  department: any;
  issuedDate: any;
  routeData: any;
  profId: string;
  proposedDate : any;
  propDate : any;
  from: any;
  to: any;
  bonafide:any = {};
  includeText:any=true;
  
  constructor(private router : Router ,private activatedRoute :ActivatedRoute,private studentService : StudentService, private location :Location,
     private loadingService : LoadingAlertService, private bonafideService:BonafideService, private accyearService : AccyearService,
     private depService : DepartmentService, private datePipe : DatePipe) { }

     ranges: any = [
      {
        value: [new Date(new Date().setDate(new Date().getDate())), new Date()],
        label: 'Today',
      },
      {
        value: [
          new Date(new Date().setDate(new Date().getDate() - 1)),
          new Date(new Date().setDate(new Date().getDate() - 1)),
        ],
        label: 'Yesterday',
      },
      {
        value: [
          new Date(new Date().setDate(new Date().getDate() - 7)),
          new Date(),
        ],
        label: 'Last 7 Days',
      },
  
    ];

  ngOnInit(): void {

   this.save1.bonafide = this.activatedRoute.snapshot.paramMap.get('type');
   this.save1.purposeOfApplication = this.activatedRoute.snapshot.paramMap.get('purpose');
   this.save1.registerNumber = this.activatedRoute.snapshot.paramMap.get('registerNo');

     this.profId = this.activatedRoute.snapshot.paramMap.get('id');
     if(this.activatedRoute.snapshot.paramMap.get('include') != null){
      const myCheckbox = document.getElementById('includeText') as HTMLInputElement;
      myCheckbox.checked = JSON.parse(this.activatedRoute.snapshot.paramMap.get('include'));
    }

     if(this.profId != null)
     {
      this.getbonafideData(this.profId);
     }
     else
     {
      this.getStudentDataByRegisterNumber(this.save1.registerNumber);
     }
  }

  getbonafideData(id)
  {
    this.bonafideService.getProformaStudent(id).then((data:any)=>{
      this.bonafide  = {};
      for(var i=0;i<data.customData.length;i++)
      {
         this.bonafide[data.customData[i].key] = data.customData[i].value;
      }
      this.save1 = this.bonafide;
    })
  }

  getStudentDataByRegisterNumber(regNo)
  {
    this.studentService.getStudentByRegNo(regNo).then((data:any)=>{
      this.student = data[0];
      if(this.student.gender != undefined)
      {
        this.save1.gender = this.student.gender;
      }
      if(this.student.phone != undefined)
      {
        this.save1.studentPhone = this.student.phone;
      }
      this.save1.studentName = this.student.name;
      this.getAccYear();
    })
  }


  getAccYear()
  {
    this.accyearService.getById(this.student.accYearId).then((data:any)=>{
      this.accYear = data;
      this.getCurrentYear(this.accYear.startYear,this.accYear.currentYear);
      this.save1.currentYear = this.convertCurrentYearToWord(this.accYear.currentYear);
      this.getDepartment();
    })
  }

   convertCurrentYearToWord(n)
   {
    var special = ['zeroth','first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth',
     'eleventh', 'twelfth', 'thirteenth', 'fourteenth', 'fifteenth', 'sixteenth', 'seventeenth', 'eighteenth', 'nineteenth'];
    var deca = ['twent', 'thirt', 'fort', 'fift', 'sixt', 'sevent', 'eight', 'ninet'];
  
      if (n < 20) return special[n];
      if (n%10 === 0) return deca[Math.floor(n/10)-2] + 'ieth';
      return deca[Math.floor(n/10)-2] + 'y-' + special[n%10];
   }

  getDepartment()
  {
    this.depService.getDepartmentDatas(this.accYear.departmentId).then((data:any)=>{
      this.department = data;
      this.save1.course = this.department.degreeName.concat("(").concat(this.department.departmentName.toString()).concat(")");
    })
  }

  getCurrentYear(year,current)
  {
     this.save1.year = parseInt(year) + parseInt(current);
  }

  include(include)
  {
     this.includeText = include.target.checked;
  }

  next(postData,isvalid)
  {
    if(isvalid){
    
    delete postData.companyName;
    delete postData.address;
    delete postData.city;
    delete postData.district;
    delete postData.state;
    delete postData.pincode;
    delete postData.bonafideType;
   
    this.loadingService.showLoading();

    var customData = [];

    for(var i=0;i<Object.keys(postData).length;i++)
    {
      if(Object.keys(postData)[i] == "companyInfo")
      {
        var company = Object.values(postData)[i];
        for(var j=0;j<Object.keys(company).length;j++)
        {
          customData.push({key:Object.keys(company)[j],value:Object.values(company)[j],order:'',show:'true'});
        }
      }
      customData.push({key:Object.keys(postData)[i],value:Object.values(postData)[i],order:'',show:'true'});
    }

    customData.push({key:'bonafideType',value:'default',order:'',show:'false'});

    var data = null;
    if(this.profId != undefined)
    {
      data = {customData,bonafide: postData.bonafide, purposeOfApplication:postData.purposeOfApplication,
        studentId:this.bonafide.studentId, id: this.profId};
    }
    else
    {
      data = {customData,bonafide: postData.bonafide, purposeOfApplication:postData.purposeOfApplication,
        studentId:this.student.id};
    }
      this.bonafideService.create(data).then((data:any)=>{
      this.loadingService.hideLoading();
      this.router.navigate(['/bonafide/pdf/',data.id,this.includeText]);
      })
    }
  }

  goBack() {
    this.router.navigate(['/bonafide/hodapproval', this.save1.bonafide,this.save1.purposeOfApplication,this.save1.registerNumber]);
  }

}
