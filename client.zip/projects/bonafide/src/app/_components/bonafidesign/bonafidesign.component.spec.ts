import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BonafidesignComponent } from './bonafidesign.component';

describe('BonafidesignComponent', () => {
  let component: BonafidesignComponent;
  let fixture: ComponentFixture<BonafidesignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BonafidesignComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BonafidesignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
