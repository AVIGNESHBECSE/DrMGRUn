import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { BonafideServiceService } from 'projects/Shared-providerAndService/BonafideServiceAndProvider/bonafide-service.service';
import { LoadingAlertService } from 'src/app/common/service/loadingAlert.service';
import { UserService } from 'projects/user/_service/user.service';
import { BonafideEsignService } from 'projects/Shared-providerAndService/BonafideEsignServiceAndProvider/bonafideEsignService';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-bonafidesign',
  templateUrl: './bonafidesign.component.html',
  styleUrls: ['./bonafidesign.component.css']
})
export class BonafidesignComponent implements OnInit {
  @Input() value: any;
  @Output('reload') reload=new EventEmitter();

  bonafideData: any;
  updateBonafide: any;
  showStudent: boolean;
  student: any;
  userDetail: any;
  proforma1: boolean;
  proforma2: boolean;
  proforma3: boolean;
  signedData: any;
  currentUser: any;
  signedStatus: boolean;
  esign={
    userId:'',
    documentId:'',
    documentType: ''
  }
  createEign: any;

 
    constructor(private userService: UserService,
      private bonafideEsignService: BonafideEsignService,
      private modalService: NgbModal,
      private config: NgbModalConfig,
      private router: Router,
      private datepipe:DatePipe,
      private loadingService: LoadingAlertService,
      public activeModal: NgbActiveModal,
       private bonafideService:BonafideServiceService) {
    config.backdrop = "static";
    config.keyboard = false
   }
  ngOnInit(): void {
    // this.getProformaStudent(this.value);

    this.getCurrentUser();
    this.bonafideService.getProformaStudent(this.value).then((data:any)=>{
      this.bonafideData=data;

      if(this.bonafideData.bonafide=='PROFORMA1'){
                  this.proforma1=true;
                  this.proforma2=false;
                  this.proforma3=false;
                }
                else if(this.bonafideData.bonafide=='PROFORMA2'){
                  this.proforma1=false;
                  this.proforma2=true;
                  this.proforma3=false;
                }
                else if(this.bonafideData.bonafide=='PROFORMA3'){
                  this.proforma1=false;
                  this.proforma2=false;
                  this.proforma3=true;
                }
    })

    

  } 
  getCurrentUser(){
    this.userService.getCurrentUser().then((data:any)=>{
      this.currentUser = data;
      this.isSignedByCurrentUser(this.value);

    });
  }
  
  isSignedByCurrentUser(proformaId){ 
  
  

    this.bonafideEsignService.getBonafideEsignList(proformaId).then((data:any)=>{
      this.signedData=data;
      this.signedData.signedCount=data.length;
      for(var b=0;b<this.signedData.length;b++){
       if( this.signedData[b].userId==this.currentUser.userId)
       {
        this.signedStatus= true;
        return;
       }
       
      }
  
      
  })
  this.signedStatus= false;
  }
  // getProformaStudent(val){ 
  
  //   this.bonafideService.getProformaStudent(val).then((data:any)=>{
  //     this.bonafideData=data; 
     
  //     if(this.bonafideData.studendId != undefined){
  //       this.bonafideService.getuserById(this.bonafideData.studendId).then((data:any)=>{
  //         this.userDetail=data; 
  //         this.bonafideData.name = this.userDetail.name;
  //         this.bonafideData.regno = this.userDetail.registerNo;
  //         this.bonafideData.accyear = this.userDetail.accYear;
  //         this.bonafideData.Fname = this.userDetail.fatherName;
  //         this.bonafideData.phone = this.userDetail.phone;
  //         this.bonafideData.community = this.userDetail.category;
  //         this.bonafideData.dob = this.userDetail.dateofBirth;
  //         this.bonafideData.address = this.userDetail.addressline1;
  //         this.bonafideData.city= this.userDetail.city;
  //         this.bonafideData.district = this.userDetail.district;
  //         this.bonafideData.state = this.userDetail.state;
  //         this.bonafideData.pin = this.userDetail.pin;

  //         if(this.bonafideData.bonafide=='PROFORMA1'){
  //           this.proforma1=true;
  //           this.proforma2=false;
  //           this.proforma3=false;
  //         }
  //         else if(this.bonafideData.bonafide=='PROFORMA2'){
  //           this.proforma1=false;
  //           this.proforma2=true;
  //           this.proforma3=false;
  //         }
  //         else if(this.bonafideData.bonafide=='PROFORMA3'){
  //           this.proforma1=false;
  //           this.proforma2=false;
  //           this.proforma3=true;
  //         }

       
  //       })
  //     }
  //   })
  // }
  // decline(){
  //   this.bonafideData.status="PENDING";
  //   this.loadingService.showLoading();
  //   this.bonafideService.updateProformaStudent(this.bonafideData).then((data:any)=>{
  //     this.updateBonafide=data;
  //     this.activeModal.close();
  //     this.loadingService.hideLoading();
  //   })
  // }
  dismiss(){
    this.activeModal.close();
  }
  // accept(){
  //   this.bonafideData.status="APPROVED";
  //   this.loadingService.showLoading();
  //   this.bonafideService.updateProformaStudent(this.bonafideData).then((data:any)=>{
  //     this.updateBonafide=data;
  //     this.activeModal.close();
  //     this.loadingService.hideLoading();
      
  //   })
  // } 


  accept(id){
      this.loadingService.showLoading();

      this.bonafideData.status="APPROVED";
    this.bonafideService.updateProformaStudent(this.bonafideData).then((data:any)=>{
      this.updateBonafide=data;
    })
    this.esign.documentType="PROFORMA";
    this.esign.userId=this.currentUser.userId;
    this.esign.documentId=id;
    this.bonafideEsignService.createBonafideEsign(this.esign).then((data:any)=>{
      this.createEign=data;
      this.activeModal.close();
      this.loadingService.hideLoading();
      this.reload.emit();
      
    })
  
  }  


}
