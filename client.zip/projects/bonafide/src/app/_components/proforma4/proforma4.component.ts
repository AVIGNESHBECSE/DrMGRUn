import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder, Validators } from '@angular/forms'  
import { BonafideService } from 'src/services/BonafideService';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from 'src/services/StudentService';
@Component({
  selector: 'app-proforma4',
  templateUrl: './proforma4.component.html',
  styleUrls: ['./proforma4.component.css']
})
export class Proforma4Component implements OnInit {
  student:any;
  studentName:any;
  productForm: FormGroup;  
  profId: string;
  bonafide:any;
  purpose:any;
  registerNo:any;
  purposeOfApplication:any;
  registerNumber:any;
  constructor(private fb:FormBuilder,private bonafideService:BonafideService,private activatedRoute : ActivatedRoute,
    private router:Router,private studentService : StudentService) {
    this.profId = this.activatedRoute.snapshot.paramMap.get('id');

    this.productForm = this.fb.group({ 
      bonafide: [{value:''}],
      purposeOfApplication: [{value:''}],
      registerNumber: [{value:''}],
      issueDate:['',Validators.required],
      refNo:['',Validators.required],
      studentName: ['',Validators.required], 
      year: ['',Validators.required],
      customData: this.fb.array([]) ,  
    });  
   }

  ngOnInit(): void {
    this.bonafide = this.activatedRoute.snapshot.paramMap.get('type');
    this.purpose = this.activatedRoute.snapshot.paramMap.get('purpose');
    this.registerNo = this.activatedRoute.snapshot.paramMap.get('registerNo');
    this.productForm.controls['bonafide'].setValue(this.bonafide);
    this.productForm.controls['purposeOfApplication'].setValue(this.purpose);
    this.productForm.controls['registerNumber'].setValue(this.registerNo);
    if(this.profId != null){
      this.getbonafideData(this.profId);
    }
    else{
      this.getStudentDataByRegisterNumber(this.activatedRoute.snapshot.paramMap.get('registerNo'));
    }
  }

  getbonafideData(id)
  {
    this.bonafideService.getProformaStudent(id).then((data:any)=>{
    this.bonafide = data.bonafide;
    this.purpose = data.purposeOfApplication

      this.productForm.controls['bonafide'].setValue(data.bonafide);
      this.productForm.controls['purposeOfApplication'].setValue(data.purposeOfApplication);
        for(var i=0;i<data.customData.length;i++){
          if(data.customData[i].key == 'bonafide' || data.customData[i].key == 'purposeOfApplication'){
            continue;}
          if(data.customData[i].key == 'studentName'){
            this.productForm.controls['studentName'].setValue(data.customData[i].value);
            continue;}
          if(data.customData[i].key == 'issueDate'){
            this.productForm.controls['issueDate'].setValue(data.customData[i].value);
            continue;}
          if(data.customData[i].key == 'refNo'){
            this.productForm.controls['refNo'].setValue(data.customData[i].value);
            continue;}
          if(data.customData[i].key == 'year'){
              this.productForm.controls['year'].setValue(data.customData[i].value);
              continue;}
          if(data.customData[i].key == 'registerNumber'){
            this.registerNo = data.customData[i].value;
            this.productForm.controls['registerNumber'].setValue(data.customData[i].value);
            this.getStudentDataByRegisterNumber(data.customData[i].value);
            continue;}
          if(data.customData[i].key == 'bonafideType'){
              continue;}
              this.customData().push(this.fb.group(data.customData[i]));
        }
      })
  }

  getStudentDataByRegisterNumber(regNo)
  {
    this.studentService.getStudentByRegNo(regNo).then((data:any)=>{
      this.student = data[0];
      this.productForm.controls['studentName'].setValue(this.student.name);
    })
  }

  customData() : FormArray {  
    return this.productForm.get("customData") as FormArray  
  }  

  newQuantity(): FormGroup {  
    return this.fb.group({  
      key: '',  
      value: '',
      order:'',
      show:'true'
    })  
  }  

  addQuantity() {  
    this.customData().push(this.newQuantity());  
  }  
     
  removeQuantity(i:number) {  
    this.customData().removeAt(i);  
  }  
     
  onSubmit(isvalid) {  
    if(isvalid){
    var postData = this.productForm.value;

    for(var i=0;i<Object.keys(postData).length;i++)
    {
      if(Object.keys(postData)[i] == "customData")
      {
        continue;
      }
      postData.customData.push({key:Object.keys(postData)[i],value:Object.values(postData)[i],order:'',show:'true'});
    }
    postData.customData.push({key:'bonafideType',value:'custom',order:'',show:'false'});
    var customData = postData.customData;
    var data = null;
    if(this.profId != null){
      data = {id:this.profId,studentId:this.student.id,customData,bonafide:postData.bonafide,purposeOfApplication:postData.purposeOfApplication};
    }
    else{
      data = {customData,studentId:this.student.id,bonafide:postData.bonafide,purposeOfApplication:postData.purposeOfApplication};
    }
    this.bonafideService.create(data).then((data:any)=>{
      var type = "custom";
      this.router.navigate(['/bonafide/pdf/'+data.id,type]);
     })
    }
    else{
      Object.keys(this.productForm.controls).forEach(field => { 
        const control = this.productForm.get(field);         
        control.markAsTouched({ onlySelf: true });    
      });
    }
  }  

  goBack() {
    this.router.navigate(['/bonafide/hodapproval', this.bonafide,this.purpose,this.registerNo]);
  }

}
