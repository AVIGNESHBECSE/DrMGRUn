import { Component, OnInit } from '@angular/core';
import { BonafideService } from 'src/services/BonafideService';
import { AccyearService } from 'src/services/AccyearService';
import { UserService } from 'src/services/UserService';
import { Common } from 'src/app/common';
import { CookieService } from 'ngx-cookie';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-proforma-filter',
  templateUrl: './proforma-filter.component.html',
  styleUrls: ['./proforma-filter.component.css']
})
export class ProformaFilterComponent implements OnInit {

  ranges: any = [
    {
      value: [new Date(new Date().setDate(new Date().getDate())), new Date()],
      label: 'Today',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 1)),
        new Date(new Date().setDate(new Date().getDate() - 1)),
      ],
      label: 'Yesterday',
    },
    {
      value: [
        new Date(new Date().setDate(new Date().getDate() - 7)),
        new Date(),
      ],
      label: 'Last 7 Days',
    },
  ];

  filters = ["Proforma","Purpose","Date"]
  filter:any;
  proformaType = ["PROFORMA1","PROFORMA2",
 // "PROFORMA3"
]
  profType:any;
  proformaData: any;
  bonafideArray: any[];
  bonafideData: any;
  fileName: string;
  url: string;
  dateRange:any;
  fromDate:any;
  toDate:any;
  startDate=new Date();
  endDate=new Date();
  types1: string[];
  purpose:any;
  profDiv: boolean;
  purpDiv: boolean;
  dateDiv: boolean;
  export:boolean = true;
  student: any;
  accYear: any;
  bonafideArrayFilled: boolean;
  constructor(private bonafideService:BonafideService , private cookie : CookieService, private toastr:ToastrService, private datePipe : DatePipe,
    private accYearService: AccyearService, private userService:UserService) { }

  ngOnInit(): void { }

  getPurpose(type: any)
  {
    this.export = true;
      if(type == 'PROFORMA1')
      {
        this.types1=["INTERNSHIP","INPLANT","VOCATIONAL","INDUSTRIAL","PROJECT"];
      }
      if(type == 'PROFORMA2')
      {
        this.types1 = ["GENERAL_BONAFIDE_PASSEDOUT_STUDENTS","GENERAL_BONAFIDE_CURRENT_STUDENTS","MEDIUM_OF_INSTRUCTION_PASSEDOUT",
        "MEDIUM_OF_INSTRUCTION_CURRENT","CHARACTER","EXPENDITURE","EDUCATIONAL_LOAN","FIRST_GRADUATE","NAME_VERIFICATION","DUE_LETTER"];
      }
      if(type == 'PROFORMA3')
      {
        this.types1=["BANK_LOAN_BONAFIDE","FOR_SCHOLARSHIP_BONAFIDE"];
      }
  }
  
  downloadProforma(id){
    this.fileName="Proforma";
    var showText = false;
    var printId = undefined;
    this.url=Common.URI + '/api/proforma/download/'+id+'/'+showText+'/'+printId+'?token='+this.cookie.get("token");
     fetch(this.url)
    //.then(res => res.blob()) 
    .then(response => {
      if (!response.ok) {
        response.json().then(errorData => {
          this.toastr.warning(errorData.error,'Error',{timeOut:2000});
        });
        throw new Error('Network response was not ok');
      }
      return response.blob();
    })
    .then(blob => {
        const data1 = window.URL.createObjectURL(blob); 
     const link = document.createElement('a');
     link.href = data1; 
     link.target="_blank";
     document.body.appendChild(link)
     link.download= this.fileName + '.pdf';
          link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); 
      link.remove();
    })
    }

  deleteProforma(id)
  {
      this.bonafideService.deleteProforma(id).then((data:any)=>{
      this.toastr.success("Sucessfully Deleted");
      this.search();
    })
  }

  demo($event:any)
  {
    if($event != undefined)
    {
      this.startDate=$event[0];
      this.endDate=$event[1];
    }
  }

  showDiv(filter)
  {
    this.export = true;
    this.profType = "";
    this.purpose = "";
    this.dateRange = "";
      if(filter == 'Proforma')
      {
        this.profDiv = true;
        this.purpDiv = false;
        this.dateDiv = false;
      }
      if(filter == 'Purpose')
      {
        this.profDiv = true;
        this.purpDiv = true;
        this.dateDiv = false;
      }
      if(filter == 'Date')
      {
        this.profDiv = true;
        this.purpDiv = true;
        this.dateDiv = true;
      }
  }

  async search()
  {
    // this.export = false;
    const date = this.datePipe.transform(this.startDate, 'dd-MMM-yyyy hh:mm a')+'/'+this.datePipe.transform(this.endDate, 'dd-MMM-yyyy hh:mm a')

   await this.bonafideService.getProformaByType(this.filter,this.profType,this.purpose,date).then((data:any)=>{
      this.proformaData = data;

      this.proformaData.sort((a, b) => new Date(b.createdOn).getTime() - new Date(a.createdOn).getTime());
            
      this.bonafideArray = [];
    for(var j=0;j<this.proformaData.length;j++)
      {
       var bonafide  = {};
       for(var i=0;i<this.proformaData[j].customData.length;i++)
       {
          bonafide[this.proformaData[j].customData[i].key] = this.proformaData[j].customData[i].value;
          if(this.proformaData[j].customData[i].key == "companyInfo")
          {
            bonafide["companyName"] = this.proformaData[j].customData[i].value.companyName;
          }
       }
       bonafide["id"] = this.proformaData[j].id;
       bonafide["purposeOfApplication"] = this.proformaData[j].purposeOfApplication;
       bonafide["bonafide"] = this.proformaData[j].bonafide;
       bonafide["year"] = this.proformaData[j].academicYear;
       if(this.proformaData[j].bonafideQrCode != undefined)
       {
       bonafide["url"] = this.proformaData[j].bonafideQrCode.url;
       }
       this.bonafideArray.push(bonafide);
     }
  })
  this.export = false;
  }

  exportAsXLSX(type)
  {
      this.bonafideService.getProformaFilterExcel(type);
  }

  getStudent(studId)
  {
    this.userService.getUserId(studId).then((data:any)=>{
       this.student = data;
    })
  }

  getAccYear(accYearId)
  {
    this.accYearService.getById(accYearId).then((data:any)=>{
      this.accYear = data;
    })
  }

}
