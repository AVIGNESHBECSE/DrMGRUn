import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProformaFilterComponent } from './proforma-filter.component';

describe('ProformaFilterComponent', () => {
  let component: ProformaFilterComponent;
  let fixture: ComponentFixture<ProformaFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProformaFilterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProformaFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
