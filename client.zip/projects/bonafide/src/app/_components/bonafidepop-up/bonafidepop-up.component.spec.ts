import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BonafidepopUpComponent } from './bonafidepop-up.component';

describe('BonafidepopUpComponent', () => {
  let component: BonafidepopUpComponent;
  let fixture: ComponentFixture<BonafidepopUpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BonafidepopUpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BonafidepopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
