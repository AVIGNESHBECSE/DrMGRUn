import { Component,EventEmitter, OnInit, Input, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbActiveModal, NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { BonafideServiceService } from 'projects/Shared-providerAndService/BonafideServiceAndProvider/bonafide-service.service';
import { UserService } from 'projects/user/_service/user.service';
import { LoadingAlertService } from 'src/app/common/service/loadingAlert.service';
import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'app-bonafidepop-up',
  templateUrl: './bonafidepop-up.component.html',
  styleUrls: ['./bonafidepop-up.component.css']
})
export class BonafidepopUpComponent implements OnInit {
  @Input() value: any;
  // @Output() passEntry: EventEmitter<any> = new EventEmitter();

  types1: string[];
  
  currentUser: any;
  student: any;
  showStudent: boolean;
  save1={
    companyInfo:{
      contactOfPerson:'',
      designation:'',
      companyName:'',
      address:'',
      city:'',
      district:'',
      state:'',
      pincode:'',
    },
    curriculum:'',
    studentSign:'',  
    
  };
  
save2={
  bonafideCertificate:'',
  studentSign:'',
};
save3={
  addressOfInstittute:'',
  conductAndCharacter:'',
  studentSign:''
};

  
  userdata: any;
course:any;
  userdatas: any;
  types2: string[];
  formType: any;
  types3: string[];
  textShow: boolean;
 
  

  constructor(private userService :UserService,private modalService: NgbModal,private loadingService: LoadingAlertService,private router: Router, 
    private toastr:ToastrService, public activeModal: NgbActiveModal, private bonafideService:BonafideServiceService) { }

  ngOnInit(): void {
    this.currentUser ={};
    this.getCurrentUser();
    
    this.types1=["INTERNSHIP","PAID_INTERSHIP"];
    this.types2=["for Job","student visa registration","Higher Studies","Education Loan","documents given","conduct and character","leaving condandchar","First Graduate"];
    this.types3=["Scholarship bonafide","bank loan bonafide","Visa extension bonafide","for scholarship bonafide"]
  }

  getCurrentUser(){
    this.userService.getCurrentUser().then((data:any)=>{
      this.currentUser = data;
      this.getUserDetails()
    });
  }

  
  
  getUserDetails(){
    this.loadingService.showLoading();
    this.bonafideService.getStudentById(this.currentUser.userId).then((data:any)=>{
      this.student=data;
      this.showStudent = true;
      this.loadingService.hideLoading();
     
    })
  }

create(details){
  if(this.value=='PROFORMA1'){
    details.studendId=this.student.id;
    details.bonafide='PROFORMA1';
    details.purposeOfApplication=this.formType;
    // details.status='PENDING';
    this.loadingService.showLoading();
      this.bonafideService.create(details).then((data:any)=>{
        this.userdata=data;
    this.activeModal.close()
    // this.passEntry.emit(details);

            this.loadingService.hideLoading();
            this.close();
      })
    
  }

    if(this.value=='PROFORMA2'){
      details.studendId=this.student.id;
      details.bonafide='PROFORMA2';
      // details.purposeOfApplication=this.formType;
      this.loadingService.showLoading();
        this.bonafideService.create(details).then((data:any)=>{
          this.userdata=data;
      this.activeModal.close()
              this.loadingService.hideLoading();
              this.close();
        })
    } 
    if(this.value=='PROFORMA3'){
      details.studendId=this.student.id;
      details.bonafide='PROFORMA3';
      // details.purposeOfApplication=this.formType;
      this.loadingService.showLoading();
        this.bonafideService.create(details).then((data:any)=>{
          this.userdata=data;
      this.activeModal.close()
              this.loadingService.hideLoading();
              this.close();
        })
    } 
}



  getformType(purpose){
  
    this.formType=purpose;
    console.log(this.formType)
  }

 
  
close(){
this.activeModal.close()
} 

}
