import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProformaImportComponent } from './proforma-import.component';

describe('ProformaImportComponent', () => {
  let component: ProformaImportComponent;
  let fixture: ComponentFixture<ProformaImportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProformaImportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProformaImportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
