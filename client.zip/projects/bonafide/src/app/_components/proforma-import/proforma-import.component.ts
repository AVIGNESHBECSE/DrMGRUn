import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { BonafideService } from 'src/services/BonafideService';
import { Common } from 'src/app/common';
import { CookieService } from 'ngx-cookie';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-proforma-import',
  templateUrl: './proforma-import.component.html',
  styleUrls: ['./proforma-import.component.css']
})
export class ProformaImportComponent implements OnInit {
  id: any;
  proformaGroup: any;
  file: File;
  proformaTemplateData: any;
  proformaTemplateDatas:any = [];
  fileName: string;
  url: string;

  constructor(private activatedRoute : ActivatedRoute, private bonafideService : BonafideService, private router : Router,
    private toastr :ToastrService,private cookie : CookieService) { }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get("id");
    this.getProformaGroupById(this.id);
  }

  getProformaGroupById(id)
  {
    this.bonafideService.getProformaPrintById(id).then((data:any)=>{
      this.proformaGroup = data;
      // this.getProformaTemplateData();
    })
  }

  // getProformaTemplateData()
  // {
  //   this.bonafideService.getProformaTemplateData(this.proformaGroup.type,this.proformaGroup.name).then((data:any)=>{
  //     this.proformaTemplateData = data;
      
  //     for(var i=0;i<data.length;i++)
  //     {
  //       var bonafide= {};
  //       for(var j=0;j<data[i].customData.length;j++)
  //       {
  //         bonafide[data[i].customData[j].key] = data[i].customData[j].value;
  //       }
  //         bonafide["purposeOfApplication"] = data[i].purposeOfApplication;
  //         bonafide["url"] = data[i].bonafideQrCode.url;
  //         bonafide["id"] = data[i].id;
  //        this.proformaTemplateDatas.push(bonafide);
  //     }

  //   })
  // }


  onSelect(e: File[])
  {
    this.file = e[0];
  }

  upload()
  {
    const formData: FormData = new FormData();
    formData.append('file', this.file);
          return new Promise((resolve, reject) => {
            this.bonafideService.importProformaData(formData).then((data:any) => {
                resolve(data);
                if(data.error != undefined){
                  if(data.error.error != undefined)
                  {
                   window.alert(data.error.error);
                  }
              }
              else{
                let ref = document.getElementById('close');
                ref?.click();
                this.proformaTemplateDatas = [];
                // this.getProformaTemplateData();
              }
            },
                (error) => {console.log("Error :: " + error)});
        });
  }

  downloadProforma(id){
    this.fileName="Proforma";
    var showText = false;
    this.url=Common.URI + '/api/proforma/download/'+id+'/'+showText+'?token='+this.cookie.get("token");
     fetch(this.url)
    //.then(res => res.blob()) 
    .then(response => {
      if (!response.ok) {
        response.json().then(errorData => {
          this.toastr.warning(errorData.error,'Error',{timeOut:2000});
        });
        throw new Error('Network response was not ok');
      }
      return response.blob();
    })
    .then(blob => {
        const data1 = window.URL.createObjectURL(blob); 
     const link = document.createElement('a');
     link.href = data1; 
     link.target="_blank";
     document.body.appendChild(link)
     link.download= this.fileName + '.pdf';
          link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); 
      link.remove();
    })
    }

  deleteProforma(id)
  {
    this.bonafideService.deleteProforma(id).then((data:any)=>{
      this.toastr.success("Sucessfully Deleted");
      this.proformaTemplateDatas = [];
      // this.getProformaTemplateData();
    })
  }


  goBack()
  {
    this.router.navigate(['/bonafide/proforma-settings']);
  }

  exportAsXLSX(){ 
    this.bonafideService.getTemplateExcel(this.proformaGroup.type);
  }

}
