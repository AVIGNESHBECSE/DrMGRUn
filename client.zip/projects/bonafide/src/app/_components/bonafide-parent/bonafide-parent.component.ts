import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bonafide-parent',
  templateUrl: './bonafide-parent.component.html',
  styleUrls: ['./bonafide-parent.component.css']
})
export class BonafideParentComponent implements OnInit {
 
  constructor() { }
  
  ngOnInit() { }

}
