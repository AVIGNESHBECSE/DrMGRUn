import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BonafideService } from 'src/services/BonafideService';

@Component({
  selector: 'app-proforma-view',
  templateUrl: './proforma-view.component.html',
  styleUrls: ['./proforma-view.component.css']
})
export class ProformaViewComponent implements OnInit {
  id: string;
  bonafideData: any;
  issueDate: string;
  fromDate: string;
  toDate: string;

  constructor(private bonafideService:BonafideService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get("id");
    this.getProformaStudent();
  }

  getProformaStudent(){ 
    this.bonafideService.getProformaStudent(this.id).then((data:any)=>{
    this.bonafideData=data; 

    for(var i=0;i<this.bonafideData.customData.length;i++)
     {
       this.bonafideData.customData[i].key = this.bonafideData.customData[i].key.replace(/([A-Z])/g, ' $1').trim()
     }
      // this.bonafideData.issueDate = this.datePipe.transform(this.bonafideData.issueDate, 'dd/MM/yyyy');
      // this.bonafideData.fromDate  =  this.datePipe.transform(this.bonafideData.fromDate,"dd/MM/yyyy");
      // this.bonafideData.toDate =  this.datePipe.transform(this.bonafideData.toDate,"dd/MM/yyyy");

    })
  }

}
