import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BonafideService } from 'src/services/BonafideService';
@Component({
  selector: 'app-proforma-text',
  templateUrl: './proforma-text.component.html',
  styleUrls: ['./proforma-text.component.css']
})
export class ProformaTextComponent implements OnInit {
  profId: string;
  bonafideContent : any;
  bonafideData: any;
  content1 : any;
  content2 : any;
  content3 : any;
  showContent1 : any;
  showContent2 : any;
  showContent3 : any;
  constructor(private activatedRoute : ActivatedRoute, private bonafideService : BonafideService , private router : Router) { }

  ngOnInit(): void {

    this.profId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getProformaData(this.profId);
  }

  getProformaContent(id,type)
  {
      this.bonafideService.getProformaContent(id).then((data:any)=>{
        this.bonafideContent = data;
        this.content1 = this.bonafideContent[0];
        this.content2 = this.bonafideContent[1];
        this.content3 = this.bonafideContent[2];
      
        this.getshowContent(type);
      })
  }

 async getProformaData(id)
  {
     this.bonafideService.getProformaStudent(id).then((data:any)=>{
     this.bonafideData = data;
     var randomcontent = true;
     for(var i=0; i< this.bonafideData.customData.length ; i++)
       {
        if(this.bonafideData.customData[i].key == 'Text1')
         {
          randomcontent = false;
          this.showContent1 = this.bonafideData.customData[i].value;
         }
         if(this.bonafideData.customData[i].key == 'Text2')
         {
          this.showContent2 = this.bonafideData.customData[i].value;
         }
         if(this.bonafideData.customData[i].key == 'Text3')
         {
          this.showContent3 = this.bonafideData.customData[i].value;
         }
       }
       if(randomcontent == true)
       {
       this.getProformaContent(this.profId,this.bonafideData.purposeOfApplication);
       }
     })
  }

  getshowContent(contentType)
  {
    switch(contentType)
    {
      case 'GENERAL_BONAFIDE_PASSEDOUT_STUDENTS':
      this.showContent1 = this.content1[1];
      this.showContent2 = this.content2[1];
      break;
      case 'GENERAL_BONAFIDE_CURRENT_STUDENTS':
      this.showContent1 = this.content1[2];
      this.showContent2 = this.content2[2];
      break;
      case 'MEDIUM_OF_INSTRUCTION_PASSEDOUT':
      this.showContent1 = this.content1[3];
      this.showContent2 = this.content2[2];
      break;
      case 'MEDIUM_OF_INSTRUCTION_CURRENT':
        this.showContent1 = this.content1[7];
        this.showContent2 = this.content2[2];
        break;
      case 'CHARACTER':
      this.showContent1 = this.content1[4];
      break;
      case 'EXPENDITURE':
      this.showContent1 = this.content1[10];
      this.showContent2 = this.content2[9];
      this.showContent3 = this.content3[6];
      break;
      case 'EDUCATIONAL_LOAN':
      this.showContent1 = this.content1[9];
      this.showContent2 = this.content2[6];
      this.showContent3 = this.content3[4];
      break;
      case 'FIRST_GRADUATE_CURRENT':
      this.showContent1 = this.content1[11];
      this.showContent2 = this.content2[8];
      this.showContent3 = this.content3[1];
      break;
      case 'FIRST_GRADUATE_PASSEDOUT':
      this.showContent1 = this.content1[5];
      this.showContent2 = this.content2[3];
      this.showContent3 = this.content3[1];
      break;
      case 'NAME_VERIFICATION':
      this.showContent1 = this.content1[6];
      this.showContent2 = this.content2[4];
      this.showContent3 = this.content3[2];
      break;
      case 'DUE_LETTER':
      this.showContent1 = this.content1[8];
      this.showContent2 = this.content2[5];
      this.showContent3 = this.content3[3];
      break;
    }

  }

  clearContent(contentType)
  {
    if(contentType == "Text1")
    {
      this.showContent1 = "";
    }
    if(contentType == "Text2")
    {
      this.showContent2 = "";
    }
    if(contentType == "Text3")
    {
      this.showContent3 = "";
    }
  }

  next()
  {

    for(var i=0; i< this.bonafideData.customData.length ; i++)
    {
      if(this.bonafideData.customData[i] != undefined){
      if(this.bonafideData.customData[i].key == 'Text1' || this.bonafideData.customData[i].key == 'Text2'|| this.bonafideData.customData[i].key == 'Text3' )
      {
        delete this.bonafideData.customData[i];
      }
    }
    }

    this.removeNullValue();

    this.bonafideData.customData.push({key:'Text1', value:this.showContent1 ,order:'',show:'false'});
    this.bonafideData.customData.push({key:'Text2', value:this.showContent2 ,order:'',show:'false'});
    this.bonafideData.customData.push({key:'Text3', value:this.showContent3 ,order:'',show:'false'});


    var data = {customData : this.bonafideData.customData , id : this.bonafideData.id};

    this.bonafideService.updateProformaStudent(data).then((data:any)=>{

      this.router.navigate(['/bonafide/pdf/'+ this.bonafideData.id]);

    });

  }

  removeNullValue(): void {
   this.bonafideData.customData = this.bonafideData.customData.filter(s => s.value != null);
}

  goBack() 
    {   
    this.router.navigate(['/bonafide/proforma2/',this.bonafideData.id]);
    }

}
