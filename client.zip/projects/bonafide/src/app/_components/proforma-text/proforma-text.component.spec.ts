import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProformaTextComponent } from './proforma-text.component';

describe('ProformaTextComponent', () => {
  let component: ProformaTextComponent;
  let fixture: ComponentFixture<ProformaTextComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProformaTextComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProformaTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
