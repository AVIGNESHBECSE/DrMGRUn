import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbActiveModal, NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { BonafideServiceService } from 'projects/Shared-providerAndService/BonafideServiceAndProvider/bonafide-service.service';
import { UserService } from 'projects/user/_service/user.service';
import { LoadingAlertService } from 'src/app/common/service/loadingAlert.service';
import { ToastrService } from 'ngx-toastr';
import { BonafidepopUpComponent } from '../bonafidepop-up/bonafidepop-up.component';
// import { BonafidepdfComponent } from '../bonafidepdf/bonafidepdf.component';
import { BonafideEsignService } from 'projects/Shared-providerAndService/BonafideEsignServiceAndProvider/bonafideEsignService';
import { BonafideEsignPopupComponent } from '../bonafide-esign-popup/bonafide-esign-popup.component';

@Component({
  selector: 'app-bonafide',
  templateUrl: './bonafide.component.html',
  styleUrls: ['./bonafide.component.css']
})
export class BonafideComponent implements OnInit {
  types: string[];
  
  currentUser: any;
  student: any;
  showStudent: boolean;
  save:any;
  bonafideType:any;

  bonafideData: any;
  
  eachStudent: any;
  
  applntype: any;
  textShow: boolean;
  suser: any;
  
  btn="New";
  
 
  constructor( private userService :UserService,private modalService: NgbModal,private loadingService: LoadingAlertService,private router: Router, 
     private toastr:ToastrService, private bonafideService:BonafideServiceService,private bonafideEsignService : BonafideEsignService) { 
      
    }

  ngOnInit(): void {
    this.currentUser ={};

    this.types=["PROFORMA1","PROFORMA2"];

    // this.types=["PROFORMA1","PROFORMA2","PROFORMA3"];
    this.getCurrentUser();
    this.save = {};
    this. getSingleUser();
  }
    
  

  
 

  getCurrentUser(){
    this.userService.getCurrentUser().then((data:any)=>{
      this.currentUser = data;
    
      this.getStudent();
    });
  }

  getSingleUser() {
    this.loadingService.showLoading();
    this.userService.getSingleUser().then((data: any) => {
      this.suser = data;
    
    });
  }

getBonafideType(appln){
  
  this.applntype=appln;
}






createRequest() {

  const modalRef = this.modalService.open(BonafidepopUpComponent, { size:"lg"});
  modalRef.componentInstance.value = this.applntype;
  // modalRef.componentInstance.passEntry.subscribe((receivedEntry) => 
  // {
  //  var  objIndex =  this.leave.leaveAllocation.findIndex((obj => obj.id == val));
  //  this.leave.leaveAllocation[objIndex].reAllotedStaffId = receivedEntry.id;
  //  this.leave.leaveAllocation[objIndex].reAllotedStaffName = receivedEntry.name;
  // })

  modalRef.componentInstance.reload.subscribe(() => {
    this.reload();
  })   
}
showText(){
  

  this.textShow = ! this.textShow;
  this.btn="Close";
 }

 reload()
 {
   this.getStudent();
 }
 getStudent(){
 
  this.loadingService.showLoading();
  this.bonafideService.getProformaByStudent(this.currentUser.userId).then(async(data:any)=>{
    this.bonafideData=data;
   
   
    if(this.bonafideData  != undefined){
    for(var b=0;b<this.bonafideData.length;b++){
      await this.bonafideEsignService.getBonafideEsignList(this.bonafideData[b].id).then((data:any)=>{
        this.bonafideData[b].esign=data;
        this.bonafideData[b].esignCount=data.length;

        

    });
  }
  }
});
  this.loadingService.hideLoading();
}

signdetail(esigndata){
  const modalRef = this.modalService.open(BonafideEsignPopupComponent, { size:"lg"});
  modalRef.componentInstance.value = esigndata;
}

openTab(id):void{
  window.open('/bonafide/pdf/'+id);
  // this.getStudent();
}


}

