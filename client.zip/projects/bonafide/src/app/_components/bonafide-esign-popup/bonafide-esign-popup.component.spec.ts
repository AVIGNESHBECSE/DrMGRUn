import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BonafideEsignPopupComponent } from './bonafide-esign-popup.component';

describe('BonafideEsignPopupComponent', () => {
  let component: BonafideEsignPopupComponent;
  let fixture: ComponentFixture<BonafideEsignPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BonafideEsignPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BonafideEsignPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
