import { DatePipe } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-bonafide-esign-popup',
  templateUrl: './bonafide-esign-popup.component.html',
  styleUrls: ['./bonafide-esign-popup.component.css']
})
export class BonafideEsignPopupComponent implements OnInit {
  @Input() value:any;

  constructor(    private modalService: NgbModal,
    public activeModal: NgbActiveModal,
    private datepipe:DatePipe

    ) { }

  ngOnInit(): void {


  }
  close(){
    this.activeModal.close()
  }

}

