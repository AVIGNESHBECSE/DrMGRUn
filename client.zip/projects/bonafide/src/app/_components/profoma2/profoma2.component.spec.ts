import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Profoma2Component } from './profoma2.component';

describe('Profoma2Component', () => {
  let component: Profoma2Component;
  let fixture: ComponentFixture<Profoma2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Profoma2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Profoma2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
