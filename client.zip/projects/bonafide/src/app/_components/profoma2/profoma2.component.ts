import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router ,RoutesRecognized } from '@angular/router';
import { LoadingAlertService } from 'src/app/common/service/loadingAlert.service';
import { BonafideService } from 'src/services/BonafideService';
import { StudentService } from 'src/services/StudentService';
import { AccyearService } from 'src/services/AccyearService';
import { DepartmentService } from 'src/services/DepartmentService';
import { DatePipe, Location } from '@angular/common';
@Component({
  selector: 'app-profoma2',
  templateUrl: './profoma2.component.html',
  styleUrls: ['./profoma2.component.css']
})
export class Profoma2Component implements OnInit {
  save1={
    // bankDetails:{
    //   employeeDesignation:'',
    //   bankName:'',
    //   address:'',
    //   city:'',
    //   district:'',
    //   state:'',
    //   pincode:'',
    // },
    sibling:'',
    community:'',
    conductAndCharacter:'',
    academicYear:'',
    period:'',
    purpose:'',
    moi:'',
    surname:'',
    passPortNo:'',
    fatherName:'',
    refNo:'',
    issueDate:'',
    studentName:'',
    studentPhone:'',
    registerNumber:'',
    course:'',
    bonafide:'',
    purposeOfApplication:'',
    currentYear:'',
    currentYearInWords:'',
    tuitionFees:'',
    admissionFees:'',
    transportationFees:'',
    signature:'',
    greeting:'',
    gender:'',
    employee:'',
    bankName:'',
    address:'',
    address2:'',
    city:'',
    district:'',
    courseDuration:'',
    state:'',
    pincode:'',
  };

  student: any;
  accYear: any;
  department: any;
  profId: any;
  bonafide:any = {};
  genBonPasDiv: boolean;
  genBonCurDiv: boolean;
  moiDiv: boolean;
  charDiv: boolean;
  expenDiv: boolean;
  eduLoanDiv: boolean;
  gradDiv: boolean;
  gradCurDiv: boolean;
  nmVerDiv: boolean;
  greetings: any;
  dueDiv: boolean;


  constructor(private router : Router ,private activatedRoute :ActivatedRoute,private studentService : StudentService, private location :Location,
    private loadingService : LoadingAlertService, private bonafideService:BonafideService, private accyearService : AccyearService,
    private depService : DepartmentService, private datePipe : DatePipe) { }

  ngOnInit(): void {
   this.save1.bonafide = this.activatedRoute.snapshot.paramMap.get('type');
   this.save1.purposeOfApplication = this.activatedRoute.snapshot.paramMap.get('purpose');
   this.save1.registerNumber = this.activatedRoute.snapshot.paramMap.get('registerNo');

     this.showDivElement();
     this.profId = this.activatedRoute.snapshot.paramMap.get('id');

     if(this.profId != null)
     {
      this.getbonafideData(this.profId);
     }
     else
     {
      this.getStudentDataByRegisterNumber(this.save1.registerNumber);
     }

     this.greetings = ["BONAFIDE CERTIFICATE","TO WHOMSOEVER IT MAY CONCERN"];
  }

  getbonafideData(id)
  {
    this.bonafideService.getProformaStudent(id).then((data:any)=>{

      this.bonafide = {};

      for(var i=0;i<data.customData.length;i++)
      {
        this.bonafide[data.customData[i].key] = data.customData[i].value;
      }

      this.save1 = this.bonafide;
    
      this.showDivElement();

     // this.getStudentDataByRegisterNumber(this.save1.registerNumber);

    })
  }


  showDivElement()
  {
    this.genBonPasDiv = this.save1.purposeOfApplication == 'GENERAL_BONAFIDE_PASSEDOUT_STUDENTS' ? true : false;
    this.genBonCurDiv = this.save1.purposeOfApplication == 'GENERAL_BONAFIDE_CURRENT_STUDENTS' ? true : false;
    this.moiDiv = this.save1.purposeOfApplication == 'MEDIUM_OF_INSTRUCTION_PASSEDOUT' || this.save1.purposeOfApplication == 'MEDIUM_OF_INSTRUCTION_CURRENT' ? true : false;
    this.charDiv = this.save1.purposeOfApplication == 'CHARACTER' ? true : false;
    this.expenDiv = this.save1.purposeOfApplication == 'EXPENDITURE' ? true : false;
    this.eduLoanDiv = this.save1.purposeOfApplication == 'EDUCATIONAL_LOAN' ? true : false;
    this.gradDiv = this.save1.purposeOfApplication == 'FIRST_GRADUATE_PASSEDOUT' ? true : false;
    this.gradCurDiv = this.save1.purposeOfApplication == 'FIRST_GRADUATE_CURRENT' ? true : false;
    this.nmVerDiv = this.save1.purposeOfApplication == 'NAME_VERIFICATION' ? true : false;
    this.dueDiv = this.save1.purposeOfApplication == 'DUE_LETTER' ? true : false;
  }

  getStudentDataByRegisterNumber(regNo)
  {
    this.studentService.getStudentByRegNo(regNo).then((data:any)=>{
      this.student = data[0];
      this.save1.studentName = this.student.name;
      if(this.student.gender != undefined)
      {
        this.save1.gender = this.student.gender;
      }
      if(this.student.phone != undefined)
      {
        this.save1.studentPhone = this.student.phone;
      }
    
      this.getAccYear();
    })
  }

  getAccYear()
  {
    this.accyearService.getById(this.student.accYearId).then((data:any)=>{
      this.accYear = data;
     this.save1.currentYearInWords = this.convertCurrentYearToWord(this.accYear.currentYear);
     this.save1.courseDuration = this.convertNumberToWord(this.accYear.noOfYears);
      this.getDepartment();
    })
  }

   convertCurrentYearToWord(n)
   {
    var special = ['zeroth','first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth',
     'eleventh', 'twelfth', 'thirteenth', 'fourteenth', 'fifteenth', 'sixteenth', 'seventeenth', 'eighteenth', 'nineteenth'];
    var deca = ['twent', 'thirt', 'fort', 'fift', 'sixt', 'sevent', 'eight', 'ninet'];
  
      if (n < 20) return special[n];
      if (n%10 === 0) return deca[Math.floor(n/10)-2] + 'ieth';
      return deca[Math.floor(n/10)-2] + 'y-' + special[n%10];
   }

   convertNumberToWord(number: number): string {
    const words: string[] = [
      'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine',
      'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen',
      'seventeen', 'eighteen', 'nineteen'
    ];
      return words[number];
    }

  getDepartment()
  {
      this.depService.getDepartmentDatas(this.accYear.departmentId).then((data:any)=>{
      this.department = data;
      this.save1.course = this.department.degreeName.concat("(").concat(this.department.departmentName.toString()).concat(")");
    })
  }

  goBack() {
    this.router.navigate(['/bonafide/hodapproval', this.save1.bonafide,this.save1.purposeOfApplication,this.save1.registerNumber]);
  }

  next(postData,isvalid)
  {
    if(isvalid){
    postData =  this.removeEmptyStringsFrom(postData);
   
      this.loadingService.showLoading();

      var customData = [];

    for(var i=0;i<Object.keys(postData).length;i++)
    {
      if(Object.keys(postData)[i] == 'bonafideType')
      {
        continue;
      }
      customData.push({key:Object.keys(postData)[i],value:Object.values(postData)[i],order:'',show:'true'});
    }

    customData.push({key:'bonafideType',value:'default',order:'',show:'false'});

    var data = null;
    if(this.profId != undefined)
    {
      data = {customData,bonafide: postData.bonafide, purposeOfApplication:postData.purposeOfApplication,
        studentId:this.bonafide.studentId, id: this.profId};
    }
    else
    {
      data = {customData,bonafide: postData.bonafide, purposeOfApplication:postData.purposeOfApplication,
        studentId:this.student.id};
    }
      this.bonafideService.create(data).then((data:any)=>{
      this.loadingService.hideLoading();
      this.router.navigate(['/bonafide/proforma-text/'+data.id]);
      })
    }
  }

  removeEmptyStringsFrom(obj) {
    const clone = { ...obj };
    Object.entries(clone).forEach(([key, val]) => val === '' && delete clone[key]);
    if(clone.bankDetails != null || clone.bankDetails != undefined)
    {
    Object.entries(clone.bankDetails).forEach(([key,val])=> val === '' && delete clone.bankDetails);
    }
    return clone;
  }


}
