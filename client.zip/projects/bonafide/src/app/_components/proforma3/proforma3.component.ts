import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proforma3',
  templateUrl: './proforma3.component.html',
  styleUrls: ['./proforma3.component.css']
})
export class Proforma3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
