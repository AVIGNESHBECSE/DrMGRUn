import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoadingAlertService } from 'projects/admission/src/app/_services/loadingAlert.service';
import { StudentService } from 'src/services/StudentService';
import { BonafideService } from 'src/services/BonafideService';
import { Common } from 'src/app/common';
import { CookieService } from 'ngx-cookie';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-bonafide-hod',
  templateUrl: './bonafide-hod.component.html',
  styleUrls: ['./bonafide-hod.component.css']
})
export class BonafideHodComponent implements OnInit {
  bonafideData: any;
  currentUser: any;
  student: any;
  eachStudent: any;
  showStudent: boolean;
  userdatas: any;
  esign:any;
  viewData = {type:'',purposeOfApplication:'',registerNumber:''}
  save1={
    companyInfo:{
      contactOfPerson:'',
      designation:'',
      companyName:'',
      address:'',
      city:'',
      district:'',
      state:'',
      pincode:'',
    },
    curriculum:'',
    studentSign:'',  
    
  };
  formType:any;
  types: string[];
  types1: string[];
  showCreate: boolean;
  registerNumber : any
  bonafideType: any;
  studentData: any;
  proformaData: any;
  dataShow: boolean;
  bonafideArray: any[];
  fileName: string;
  url: string;

  constructor(private router: Router,
    private activatedRoute: ActivatedRoute, private loadingService: LoadingAlertService,private toastr: ToastrService,
    private bonafideService:BonafideService,private studentService : StudentService, private cookie : CookieService) { }

  ngOnInit(): void {
    this.dataShow = true;
    this.viewData.type = this.activatedRoute.snapshot.paramMap.get('type');
    this.viewData.purposeOfApplication = this.activatedRoute.snapshot.paramMap.get('purpose');
    this.viewData.registerNumber = this.activatedRoute.snapshot.paramMap.get('registerNo');
   
    this.showCreate = true;
    this.types=["PROFORMA1","PROFORMA2","PROFORMA3"];
  }

  getPurpose(type: any)
  {
      if(type == 'PROFORMA1')
      {
        this.types1=["INTERNSHIP","INPLANT","VOCATIONAL","INDUSTRIAL","PROJECT"];
      }
      if(type == 'PROFORMA2')
      {
        this.types1 = ["GENERAL_BONAFIDE_PASSEDOUT_STUDENTS","GENERAL_BONAFIDE_CURRENT_STUDENTS","MEDIUM_OF_INSTRUCTION_PASSEDOUT",
        "MEDIUM_OF_INSTRUCTION_CURRENT","CHARACTER",
        "EXPENDITURE",
        "EDUCATIONAL_LOAN","FIRST_GRADUATE_CURRENT","FIRST_GRADUATE_PASSEDOUT","NAME_VERIFICATION","DUE_LETTER"];
      }
      if(type == 'PROFORMA3')
      {
        this.types1=["BANK_LOAN_BONAFIDE","FOR_SCHOLARSHIP_BONAFIDE"];
      }
  }

  downloadProforma(id){
    this.fileName="Proforma";
    var showText = false;
    var printId = undefined;
    this.url=Common.URI + '/api/proforma/download/'+id+'/'+showText+'/'+printId+'?token='+this.cookie.get("token");
     fetch(this.url)
    //.then(res => res.blob()) 
    .then(response => {
      if (!response.ok) {
        response.json().then(errorData => {
          this.toastr.warning(errorData.error,'Error',{timeOut:2000});
        });
        throw new Error('Network response was not ok');
      }
      return response.blob();
    })
    .then(blob => {
        const data1 = window.URL.createObjectURL(blob); 
     const link = document.createElement('a');
     link.href = data1; 
     link.target="_blank";
     document.body.appendChild(link)
     link.download= this.fileName + '.pdf';
          link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); 
      link.remove();
    })
    }

  create(viewData)
  {
    if(viewData.type == 'PROFORMA1')
    {
      this.router.navigate(['/bonafide/proforma/',viewData.type,viewData.purposeOfApplication,viewData.registerNumber]);
    }
    if(viewData.type == 'PROFORMA2')
    {
      this.router.navigate(['/bonafide/proforma2/',viewData.type,viewData.purposeOfApplication,viewData.registerNumber]);
    }
    if(viewData.type == 'PROFORMA3')
    {
      this.router.navigate(['/bonafide/proforma3/',viewData.type,viewData.purposeOfApplication,viewData.registerNumber]);
    }
  }

  custom(viewData)
  {
    this.router.navigate(['/bonafide/proforma4/',viewData.type,viewData.purposeOfApplication,viewData.registerNumber]);
  }

  search()
  {
    this.studentService.getStudentByRegNo(this.viewData.registerNumber).then((data:any)=>{
      this.studentData = data;
      this.showCreate = this.studentData.length != 0 ? false:true;
      this.dataShow = this.studentData.length != 0 ? true:false;
      if(this.studentData != null)
      {
        this.getUserDetails(this.studentData[0].id);
      }
    })
  }

   getUserDetails(id){
    this.loadingService.showLoading();
    this.bonafideService.getProformaByStudent(id).then((data:any)=>{
    this.proformaData=data;

      this.bonafideArray = [];
       for(var j=0;j<this.proformaData.length;j++)
       {
        var bonafide  = {};
        for(var i=0;i<this.proformaData[j].customData.length;i++)
        {
           bonafide[this.proformaData[j].customData[i].key] = this.proformaData[j].customData[i].value;
        }
        bonafide["id"] = this.proformaData[j].id;
        bonafide["purposeOfApplication"] = this.proformaData[j].purposeOfApplication;
        bonafide["bonafide"] = this.proformaData[j].bonafide;
        if(this.proformaData[j].bonafideQrCode != undefined)
        {
        bonafide["url"] = this.proformaData[j].bonafideQrCode.url;
        }
        this.bonafideArray.push(bonafide);
      }
      this.loadingService.hideLoading();
    })
  }

  deleteProforma(id)
  {
      this.bonafideService.deleteProforma(id).then((data:any)=>{
      this.toastr.success("Sucessfully Deleted");
      this.search();
    })
  }

}
