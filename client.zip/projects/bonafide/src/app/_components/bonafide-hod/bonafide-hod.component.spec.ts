import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BonafideHodComponent } from './bonafide-hod.component';

describe('BonafideHodComponent', () => {
  let component: BonafideHodComponent;
  let fixture: ComponentFixture<BonafideHodComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BonafideHodComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BonafideHodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
