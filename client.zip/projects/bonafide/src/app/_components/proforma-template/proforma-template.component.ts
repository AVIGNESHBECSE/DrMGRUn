import { Component, OnInit, ViewChild } from '@angular/core';
import { AccyearService } from 'src/services/AccyearService';
import { DepartmentService } from 'src/services/DepartmentService';
import { GroupService } from 'src/services/GroupService';
import { BonafideService } from 'src/services/BonafideService';
import { Common } from 'src/app/common';
import { CookieService } from 'ngx-cookie';
import { LoadingAlertService } from 'src/app/common/service/loadingAlert.service';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { UserService } from 'src/services/UserService';

@Component({
  selector: 'app-proforma-template',
  templateUrl: './proforma-template.component.html',
  styleUrls: ['./proforma-template.component.css']
})
export class ProformaTemplateComponent implements OnInit {
  @ViewChild('userForm') public createForm:NgForm;
  @ViewChild('alignForm') public alignSizeForm:NgForm;
  bonafide={
    stu_name:'',
    regNo:'',
    sex:'',
    par_name:'',
    religion:'',
    community:'',
    dob:'',
    modeOfAdmn:'',
    "courseInWhichAdmitted4Cc,Con&Mig":'',
    courseInWhichAdmitted:'',
    studiedIn:'',
    "year/SemInWhichAdmitted":'',
    "completed/Discontinued":'',
    "month&YearOfAddmn":'',
    yearOfLeaving:'',
    "leavingYear/Semester":'',
    medium:'',
    whetherQualified:'',
    courseDuration:'',
    facultyOf:'',
    batch:'',
    conduct:'',
    date:'',
  };
  
  tab: number=1;
  departments: any;
  accyears: any;
  groups: any;
  students: any;
  dept:any;
  accYearId:any;
  groupId:any;
  file: File;
  proformaGroup: any;
  studentIds:any = [];
  templateDatas: any;
  fileName: string;
  url: string;
  cccIds:any = [];
  occcIds:any = [];
  ccIds:any = [];
  mcIds:any = [];
  tcIds:any = [];
  typeIds: any = [];
  loading:boolean = false;
  uploadLoading: boolean;
  proformaId: any;
  purpose: any;
  cccDiv: boolean;
  occcDiv: boolean;
  ccDiv: boolean;
  mcDiv: boolean;
  tcDiv: boolean;
  purposes:any;
  printerId:any;
  proformaPrint: any;
  aicteIds: any[];
  admitIds:any[];
  aicteDiv: boolean;
  studentApproveIds: any=[];
  rollType:any=[];
  selectAll: boolean = false;
  

  certificateValues: string[] = [];
  admitDiv: boolean;
  
  constructor(private accYearService : AccyearService,private bonafideService : BonafideService, private loadingService : LoadingAlertService,
    private depService : DepartmentService, private groupService : GroupService, private cookie : CookieService, private toastr : ToastrService,
    private userService : UserService) { }

  ngOnInit(): void {
    this.purposes = ['COURSE_COMPLETION_CERTIFICATE','CONDUCT_CERTIFICATE','MIGRATION_CERTIFICATE','TRANSFER_CERTIFICATE','AICTE_CERTIFICATE','ONLINE_COURSE_COMPLETION_CERTIFICATE','ADMIT_CARD_CERTIFICATE'];
    this.getDepartments();
    this.getSingleUser();
  }

  getSingleUser(){
    this.userService.getSingleUser().then((data:any)=>{
      this.rollType = data.rollType;
    })
  }

  changeTab(type)
  {
    if(type == 'group')
    {
    this.tab = 1;
    }
  }

  getDepartments()
  {
   this.depService.getDepartment().then((data:[])=>{
     this.departments = data;
    });
  }

  getAccyears(deptId){
    this.accYearService.getAcademicyear(deptId).then((data:[])=>{
    this.accyears=data;
    })
  }

  getGroup(accId){
    this.groupService.getCurrentGroup(accId).then((data:[])=>{
      this.groups=data;
      
  });
}

getProformaPrint()
  {
    this.bonafideService.getProformaPrint().then((data:any)=>{
      this.proformaPrint = data;
    })
  }

getStudentList(grpId){
  this.groupService.getGroupStudents(grpId).then((data:[])=>{
this.students=data;
for(var i=0 ; i<this.students.length;i++)
{
    this.studentIds.push(this.students[i].id);
}
this.getProformaTemplateData();
});
}

onSelect(e: File[])
  {
    this.file = e[0];
  }

  upload()
  {
    this.uploadLoading = true;
    const formData: FormData = new FormData();
    formData.append('file', this.file);
          return new Promise((resolve, reject) => {
            this.bonafideService.importProformaData(formData).then((data:any) => {
                resolve(data);
                if(data.error != undefined){
                  if(data.error.error != undefined)
                  {
                   window.alert(data.error.error);
                  }
              }
              else{
                this.uploadLoading = false;
                let ref = document.getElementById('close');
                ref?.click();
                this.getProformaTemplateData();
              }
            },
                (error) => {console.log("Error :: " + error)});
        });
  }

  async getProformaTemplateData()
  {
     this.cccIds = [];
     this.occcIds = [];
      this.ccIds = [];
      this.mcIds = [];
      this.tcIds = [];
      this.aicteIds = [];
      this.admitIds=[];
   await this.bonafideService.getProformaTemplateData(this.studentIds).then((data:any)=>{
        this.templateDatas = data;
  })
   for(var i=0;i<this.students.length;i++)
        {
          for(var j=0; j<this.templateDatas.length; j++)
          {
          if(this.students[i].id == this.templateDatas[j].studentId)
          {
            if(this.templateDatas[j].purposeOfApplication == 'COURSE_COMPLETION_CERTIFICATE'){
              this.students[i]['ccc'] = this.templateDatas[j].id ;
              this.students[i]['cccStatus'] = this.templateDatas[j].approvedStatus;
              if(this.templateDatas[j].approvedStatus != undefined && this.templateDatas[j].approvedStatus == "YES"){
                this.cccIds.push(this.templateDatas[j].id);
              }}
            if(this.templateDatas[j].purposeOfApplication == 'ONLINE_COURSE_COMPLETION_CERTIFICATE'){
              this.students[i]['occc'] = this.templateDatas[j].id ;
              this.students[i]['occcStatus'] = this.templateDatas[j].approvedStatus;
              if(this.templateDatas[j].approvedStatus != undefined && this.templateDatas[j].approvedStatus == "YES"){
                this.occcIds.push(this.templateDatas[j].id);
              }}
            if(this.templateDatas[j].purposeOfApplication == 'CONDUCT_CERTIFICATE'){
              this.students[i]['cc'] = this.templateDatas[j].id ;
              this.students[i]['ccStatus'] = this.templateDatas[j].approvedStatus;
              if(this.templateDatas[j].approvedStatus != undefined && this.templateDatas[j].approvedStatus == "YES"){
                this.ccIds.push(this.templateDatas[j].id);
              }}
            if(this.templateDatas[j].purposeOfApplication == 'MIGRATION_CERTIFICATE'){
              this.students[i]['mc'] = this.templateDatas[j].id ;
              this.students[i]['mcStatus'] = this.templateDatas[j].approvedStatus;
              if(this.templateDatas[j].approvedStatus != undefined && this.templateDatas[j].approvedStatus == "YES"){
                this.mcIds.push(this.templateDatas[j].id);
              }}
            if(this.templateDatas[j].purposeOfApplication == 'TRANSFER_CERTIFICATE'){
              this.students[i]['tc'] = this.templateDatas[j].id ;
              this.students[i]['tcStatus'] = this.templateDatas[j].approvedStatus;
              if(this.templateDatas[j].approvedStatus != undefined && this.templateDatas[j].approvedStatus == "YES"){
                this.tcIds.push(this.templateDatas[j].id);
              }}
            if(this.templateDatas[j].purposeOfApplication == 'AICTE_CERTIFICATE'){
              this.students[i]['aicte'] = this.templateDatas[j].id ;
              this.students[i]['aicteStatus'] = this.templateDatas[j].approvedStatus;
              if(this.templateDatas[j].approvedStatus != undefined && this.templateDatas[j].approvedStatus == "YES"){
                this.aicteIds.push(this.templateDatas[j].id);
              }}
              if(this.templateDatas[j].purposeOfApplication=='ADMIT_CARD_CERTIFICATE'){
                this.students[i]['admit'] = this.templateDatas[j].id ;
                this.students[i]['admitStatus'] = this.templateDatas[j].approvedStatus;
                if(this.templateDatas[j].approvedStatus != undefined && this.templateDatas[j].approvedStatus  == "YES"){
                  this.admitIds.push(this.templateDatas[j].id);
                }
              }
          }
         }
        }
  }

  exportAsXLSX(){ 
    this.bonafideService.getTemplateExcel(this.groupId);
  } 

  downloadProforma(id){
    if(this.printerId == '')
    {
      this.printerId = undefined;
    }
    if(id != undefined)
    {
    this.fileName="Proforma";
    var showText = false;
    this.url=Common.URI + '/api/proforma/download/'+id+'/'+showText+'/'+this.printerId+'?token='+this.cookie.get("token");
     fetch(this.url)
   // .then(res => res.blob()) 
    .then(response => {
    if (!response.ok) {
      response.json().then(errorData => {
        this.toastr.warning(errorData.error,'Error',{timeOut:2000});
      });
      throw new Error('Network response was not ok');
    }
    return response.blob();
  })
    .then(blob => {
     const data1 = window.URL.createObjectURL(blob); 
     const link = document.createElement('a');
     link.href = data1; 
     link.target="_blank";
     document.body.appendChild(link)
     link.download= this.fileName + '.pdf';
          link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); 
      link.remove();
    })
  }
  else
    {
    this.toastr.error("Sorry! No Data Found");
    }
  }


   downloadMultipleProforma(type)
    {
      if(this.printerId == '')
      {
      this.printerId = undefined;
      }
      this.typeIds = [];
      this.fileName="";
      if(type == 'COURSE_COMPLETION_CERTIFICATE')
      {
        if(this.cccIds.length > 0){
        this.typeIds.push(this.cccIds);
        this.fileName = type;}
        else
        {
          return this.toastr.error("Sorry! No Data Found");
        }
      }
      if(type == 'ONLINE_COURSE_COMPLETION_CERTIFICATE')
      {
        if(this.occcIds.length > 0){
        this.typeIds.push(this.occcIds);
        this.fileName = type;}
        else
        {
          return this.toastr.error("Sorry! No Data Found");
        }
      }
      if(type == 'CONDUCT_CERTIFICATE')
      {
        if(this.ccIds.length > 0){
        this.typeIds.push(this.ccIds);
        this.fileName = type;}
        else
        {
          return this.toastr.error("Sorry! No Data Found");
        }
      }
      if(type == 'MIGRATION_CERTIFICATE')
      {
        if(this.mcIds.length > 0){
        this.typeIds.push(this.mcIds);
        this.fileName = type;}
        else
        {
          return this.toastr.error("Sorry! No Data Found");
        }
      }
      if(type == 'TRANSFER_CERTIFICATE')
      {
        if(this.tcIds.length > 0){
        this.typeIds.push(this.tcIds);
        this.fileName = type;}
        else
        {
          return this.toastr.error("Sorry! No Data Found");
        }
      }
      if(type == 'AICTE_CERTIFICATE')
      {
        if(this.aicteIds.length > 0){
        this.typeIds.push(this.aicteIds);
        this.fileName = type;}
        else
        {
          return this.toastr.error("Sorry! No Data Found");
        }
      }
      if(type == 'ADMIT_CARD_CERTIFICATE'){
      if(this.admitIds.length > 0){
        this.typeIds.push(this.admitIds);
        this.fileName = type;
      }
      else{
        return this.toastr.error("Sorry! No Data Found");
      }
      
      }
      // this.loading = true;
      // this.url=Common.URI + '/api/proforma/mergeAndDownload/'+this.printerId+'?token='+this.cookie.get("token"),this.typeIds;
      //  fetch(this.url)
      // .then(res => res.blob()) 
      // .then(blob => {
      //   this.loading = false;
      //  const data1 = window.URL.createObjectURL(blob); 
      //  const link = document.createElement('a');
      //  link.href = data1; 
      //  link.target="_blank";
      //  document.body.appendChild(link)
      //  link.download= this.fileName + '.pdf';
      //       link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); 
      //   link.remove();
      // })
      this.loading = true;
const url = Common.URI + '/api/proforma/mergeAndDownload/' + this.printerId + '?token=' + this.cookie.get("token");
const requestData = this.typeIds[0]; 
fetch(url, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify(requestData), 
})
  .then(response => {
    if (!response.ok) {
      response.json().then(errorData => {
        this.toastr.warning(errorData.error,'Error',{timeOut:2000});
      });
      throw new Error('Network response was not ok');
    }
    return response.blob();
  })
  .then(blob => {
    this.loading = false;
    const dataURL = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = dataURL;
    link.target = "_blank";
    link.download = this.fileName + '.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(dataURL);
  })
  .catch(error => {
    console.error('Error:', error);
    this.loading = false;
  });

    }

    deleteProforma(id)
     {
      this.bonafideService.deleteProforma(id).then((data:any)=>{
      this.toastr.success("Sucessfully Deleted");
      this.getStudentList(this.groupId);
    })
  }

  async editProformaById(id)
  {
    if(id != undefined){
  await this.bonafideService.getProformaStudent(id).then((data:any)=>{
      this.proformaId = data.id;
      this.purpose = data.purposeOfApplication;
      this.showDivElement();
      for(var i=0;i<data.customData.length;i++)
      {
        this.bonafide[data.customData[i].key] = data.customData[i].value;
      }
    })
  }
  else
  {
    this.toastr.error("Sorry! No Data Found");
  }
  }

  updateProformaById(postData,valid)
  {
    postData = this.removeEmptyStringsFrom(postData);
      if(valid)
      {
       var customData = [];
       for(var i=0;i<Object.keys(postData).length;i++)
         {
          if(Object.values(postData)[i] != null && Object.values(postData)[i] != undefined)
          {
          customData.push({key:Object.keys(postData)[i],value:Object.values(postData)[i],order:'',show:'true'});
          }
         }
         var data = {customData,id:this.proformaId};
         this.bonafideService.updateProformaStudent(data).then((data:any)=>{
          let ref = document.getElementById('close2');
          ref?.click();
          this.createForm.resetForm();
         })
      }
  }

  removeEmptyStringsFrom(obj) {
    const clone = { ...obj };
    Object.entries(clone).forEach(([key, val]) => val === '' && delete clone[key]);
    return clone;
  }

  reset()
  {
    this.createForm.resetForm();
  }

  showDivElement()
  {
    this.cccDiv = this.purpose == 'COURSE_COMPLETION_CERTIFICATE' || this.purpose == 'ONLINE_COURSE_COMPLETION_CERTIFICATE' ? true : false;
    this.ccDiv  = this.purpose == 'CONDUCT_CERTIFICATE' ? true : false;
    this.mcDiv  = this.purpose == 'MIGRATION_CERTIFICATE' ? true : false;
    this.tcDiv  = this.purpose == 'TRANSFER_CERTIFICATE' ? true : false;
    this.aicteDiv = this.purpose == 'AICTE_CERTIFICATE' ? true : false;
    this.admitDiv = this.purpose== 'ADMIT_CARD_CERTIFICATE' ? true : false;
  }

  checkAllCheckBox(checked,std){
    let index=this.studentApproveIds.indexOf(std.id);
  if(checked){
    if(index == -1){
      this.studentApproveIds.push(std.id);
     }
  }else if(index !=-1){
    this.studentApproveIds.splice(index,1);
  }
  }  

  updateSelectedCheckboxValues(value: string) {
    const index = this.certificateValues.indexOf(value);
    if (index === -1) {
      this.certificateValues.push(value);
    } else {
      this.certificateValues.splice(index, 1);
    }
  }
  
  approveStudentCertificate(){
     this.bonafideService.approveStudentsCertificate(this.certificateValues,this.studentApproveIds).then((data:any)=>{
      let ref = document.getElementById('close3');
      ref?.click();
      this.studentApproveIds = [];
      this.certificateValues = [];
      this.selectAll = false;
      this.getStudentList(this.groupId);
     })
  }

checkAll() {
  for (const student of this.students){
    student.checked = this.selectAll;
    this.studentApproveIds.push(student.id);    
  }
  if(this.selectAll == false){
    this.studentApproveIds = [];
  }
}

}
