import { Component, OnInit,ViewChild } from '@angular/core';
import { BonafideService } from 'src/services/BonafideService';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-create-group',
  templateUrl: './create-group.component.html',
  styleUrls: ['./create-group.component.css']
})
export class CreateGroupComponent implements OnInit {
  @ViewChild('composeform') public createForm:NgForm;
  group={name:'',type:''}
  proformaGroups:any;
  types:any;
  constructor(private bonafideService : BonafideService, private router : Router) { }

  ngOnInit(): void {
    this.getProformaGroup();
    this.types=["COURSE_COMPLETION_CERTIFICATE","TRANSFER_CERTIFICATE","MIGRATION_CERTIFICATE","CONDUCT_CERTIFICATE"];
  }

  getProformaGroup()
  {
    this.bonafideService.getProformaPrint().then((data:any)=>{
      this.proformaGroups = data;
    })
  }

  createProformaGroup(valid)
  {
    if(valid){
    this.bonafideService.createProformaPrint(this.group).then((data:any)=>{
        let ref = document.getElementById('close');
        ref?.click();
        this.getProformaGroup();
        this.createForm.resetForm();
    })
   }
  }

  deleteGroup(id)
  {
     this.bonafideService.deleteProformaPrint(id).then((data:any)=>{
      this.getProformaGroup();
     });
  }

  viewProformaGroup(id)
  {
    this.router.navigate(['/bonafide/proforma-import/',id]);
  }

  clearBind()
  {
    this.createForm.resetForm();
  }

}
