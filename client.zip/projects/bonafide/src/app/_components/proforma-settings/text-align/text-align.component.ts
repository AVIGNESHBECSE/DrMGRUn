import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BonafideService } from 'src/services/BonafideService';
declare var $:any;
@Component({
  selector: 'app-text-align',
  templateUrl: './text-align.component.html',
  styleUrls: ['./text-align.component.css']
})
export class TextAlignComponent implements OnInit {
  @ViewChild('composeform') public createForm:NgForm;
  @ViewChild('mainForm') public MainForm:NgForm;
  proforma={
    proformaPrintId:'',
    proformaType:'',
    qrCode:{x:0,y:0},
    studentName:{x:0,y:0},
    regNo:{x:0,y:0},
    sex:{x:0,y:0},
    parentName:{x:0,y:0},
    religion:{x:0,y:0},
    community:{x:0,y:0},
    dob:{x:0,y:0},
    modeOfAdmn:{x:0,y:0},
    courseAdmitted:{x:0,y:0},
    courseAdmittedTc:{x:0,y:0},
    yearSemAdmitted:{x:0,y:0},
    completedDiscontinued:{x:0,y:0},
    monthYearOfAddmn:{x:0,y:0},
    yearOfLeaving:{x:0,y:0},
    leavingYearSemester:{x:0,y:0},
    medium:{x:0,y:0},
    whetherQualified:{x:0,y:0},
    courseDuration:{x:0,y:0},
    faculty:{x:0,y:0},
    batch:{x:0,y:0},
    studiedIn:{x:0,y:0},
    conduct:{x:0,y:0},
    date:{x:0,y:0},
    onlineText:{x:0,y:0},
    admitNo:{x:0,y:0}
  };
  printer = {name:''}
  types: any;
  proformaPrint: any;
  radioSelected : any;
  cccDiv: boolean;
  occcDiv: boolean;
  ccDiv: boolean;
  mcDiv: boolean;
  tcDiv: boolean;
  profType: any;
  showFields: boolean;
  proformaId: any;
  showMainDiv: boolean;
  showEdit: boolean;
  showCreate: boolean;
  showNext: boolean;
  showCreate1: boolean;
  showEdit1: boolean;
  aicteDiv: any;
  accDiv: boolean;

  constructor(private bonafideService : BonafideService) { }

  ngOnInit(): void {
    this.types=["COURSE_COMPLETION_CERTIFICATE","TRANSFER_CERTIFICATE","MIGRATION_CERTIFICATE","CONDUCT_CERTIFICATE","AICTE_CERTIFICATE","ONLINE_COURSE_COMPLETION_CERTIFICATE","ADMIT_CARD_CERTIFICATE"];
  }

  clearBind()
  {
    this.createForm.resetForm();
  }

  fieldReset()
  {
    this.showFields = false;
    this.showCreate = false;
    this.showEdit = false;
    this.showNext = true;

    this.proforma={
      proformaPrintId:'',
      proformaType:'',
      qrCode:{x:0,y:0},
      studentName:{x:0,y:0},
      regNo:{x:0,y:0},
      sex:{x:0,y:0},
      parentName:{x:0,y:0},
      religion:{x:0,y:0},
      community:{x:0,y:0},
      dob:{x:0,y:0},
      modeOfAdmn:{x:0,y:0},
      courseAdmitted:{x:0,y:0},
      courseAdmittedTc:{x:0,y:0},
      yearSemAdmitted:{x:0,y:0},
      completedDiscontinued:{x:0,y:0},
      monthYearOfAddmn:{x:0,y:0},
      yearOfLeaving:{x:0,y:0},
      leavingYearSemester:{x:0,y:0},
      medium:{x:0,y:0},
      whetherQualified:{x:0,y:0},
      courseDuration:{x:0,y:0},
      faculty:{x:0,y:0},
      batch:{x:0,y:0},
      studiedIn:{x:0,y:0},
      conduct:{x:0,y:0},
      date:{x:0,y:0},
      onlineText:{x:0,y:0},
      admitNo:{x:0,y:0}
    };
  }

  showPrint(type)
  {
     this.showMainDiv = true;
     this.showFields = false;
     this.showNext = false;

     this.profType = type;
     this.proforma.proformaType = this.profType;
   
    this.cccDiv = this.profType == 'COURSE_COMPLETION_CERTIFICATE' || this.profType == 'ONLINE_COURSE_COMPLETION_CERTIFICATE' ? true : false;
    this.occcDiv = this.profType == 'ONLINE_COURSE_COMPLETION_CERTIFICATE' ? true : false; //afterwards have to change online div to this....
    this.ccDiv  = this.profType == 'CONDUCT_CERTIFICATE' ? true : false;
    this.mcDiv  = this.profType == 'MIGRATION_CERTIFICATE' ? true : false;
    this.tcDiv  = this.profType == 'TRANSFER_CERTIFICATE' ? true : false;
    this.aicteDiv = this.profType == 'AICTE_CERTIFICATE' ? true : false;
    this.accDiv = this.profType == 'ADMIT_CARD_CERTIFICATE' ? true: false;
  
     this.getProformaPrint()
  }

  getProformaPrint()
  {
    this.bonafideService.getProformaPrint().then((data:any)=>{
      this.proformaPrint = data;
      this.showCreate1 = false;
      this.showEdit1 = true;
    })
  }

  createProformaPrint(valid)
  {
    if(valid){
    this.bonafideService.createProformaPrint(this.printer).then((data:any)=>{
        let ref = document.getElementById('close');
        ref?.click();
        this.getProformaPrint();
        this.createForm.resetForm();
    })
   }
  }

  updateProformaPrint(valid)
  {
     if(valid)
     {
      this.bonafideService.updateProformaPrint(this.proforma.proformaPrintId,this.printer).then((data:any)=>{
        let ref = document.getElementById('close');
        ref?.click();
        this.getProformaPrint();
      })
     }
  }

  changePrintName(id,name)
  {
    $('#staticBackdrop').modal('show');
    this.showCreate1 = true;
    this.showEdit1 = false;
    this.proforma.proformaPrintId = id;
    this.printer.name = name;
  }

  deletePrint(id)
  {
     this.bonafideService.deleteProformaPrint(id).then((data:any)=>{
      this.getProformaPrint();
     });
  }

  getProformaTextAlign()
  {
    this.proforma.proformaPrintId = this.radioSelected;

    this.bonafideService.getByPrintAndType(this.profType,this.radioSelected).then((data:any)=>{
      if(data.length > 0 && data[0] != undefined)
      {
       this.proformaId = data[0].id;
       this.proforma = Object.assign({}, this.proforma, data[0]);
       this.showEdit = true;
       this.showFields = true;
      }
      else{
        this.showFields = true;
        this.showCreate = true;
      }
    })

  }

  createProformaTextAlign()
  {
    this.proforma.proformaType = this.profType;
    this.deleteObject();
    this.bonafideService.createProformaTextAlign(this.proforma).then((data:any)=>{
      this.showFields = false;
    })
  }

  editProformaTextAlign()
  {
    this.deleteObject();
    this.bonafideService.updateProformaTextAlign(this.proformaId,this.proforma).then((data:any)=>{
      this.showFields = false;
    })
  }

  deleteObject()
  {

    if(this.proforma.proformaType == 'COURSE_COMPLETION_CERTIFICATE' || this.proforma.proformaType == 'ONLINE_COURSE_COMPLETION_CERTIFICATE')
    {
    delete this.proforma.sex;
    delete this.proforma.parentName;
    delete this.proforma.religion;
    delete this.proforma.community;
    delete this.proforma.dob;
    delete this.proforma.modeOfAdmn;
    delete this.proforma.courseAdmittedTc;
    delete this.proforma.yearSemAdmitted;
    delete this.proforma.completedDiscontinued;
    delete this.proforma.leavingYearSemester;
    delete this.proforma.medium;
    delete this.proforma.whetherQualified;
    delete this.proforma.batch;
    delete this.proforma.conduct;
    delete this.proforma.admitNo;
    if(this.proforma.proformaType == 'COURSE_COMPLETION_CERTIFICATE')
      {
        delete this.proforma.onlineText;
      }
    }

    if(this.proforma.proformaType == 'CONDUCT_CERTIFICATE')
    {
    delete this.proforma.sex;
    delete this.proforma.parentName;
    delete this.proforma.religion;
    delete this.proforma.community;
    delete this.proforma.dob;
    delete this.proforma.modeOfAdmn;
    delete this.proforma.courseAdmittedTc;
    delete this.proforma.yearSemAdmitted;
    delete this.proforma.completedDiscontinued;
    delete this.proforma.monthYearOfAddmn;
    delete this.proforma.yearOfLeaving;
    delete this.proforma.leavingYearSemester;
    delete this.proforma.medium;
    delete this.proforma.whetherQualified;
    delete this.proforma.courseDuration;
    delete this.proforma.faculty;
    delete this.proforma.onlineText;
    delete this.proforma.admitNo;
    }

    if(this.proforma.proformaType == 'MIGRATION_CERTIFICATE')
    {
      delete this.proforma.sex;
      delete this.proforma.parentName;
      delete this.proforma.religion;
      delete this.proforma.community;
      delete this.proforma.dob;
      delete this.proforma.modeOfAdmn;
      delete this.proforma.courseAdmittedTc;
      delete this.proforma.yearSemAdmitted;
      delete this.proforma.completedDiscontinued;
      delete this.proforma.monthYearOfAddmn;
      delete this.proforma.yearOfLeaving;
      delete this.proforma.leavingYearSemester;
      delete this.proforma.medium;
      delete this.proforma.whetherQualified;
      delete this.proforma.courseDuration;
      delete this.proforma.faculty;
      delete this.proforma.conduct;
      delete this.proforma.onlineText;
      delete this.proforma.admitNo;
    }

    if(this.proforma.proformaType == 'TRANSFER_CERTIFICATE')
    {
      delete this.proforma.courseAdmitted;
      delete this.proforma.courseDuration;
      delete this.proforma.faculty;
      delete this.proforma.batch;
      delete this.proforma.onlineText;
      delete this.proforma.admitNo;
    }

    if(this.proforma.proformaType == 'AICTE_CERTIFICATE')
    {
      delete this.proforma.sex;
      delete this.proforma.parentName;
      delete this.proforma.religion;
      delete this.proforma.community;
      delete this.proforma.dob;
      delete this.proforma.modeOfAdmn;
      delete this.proforma.courseAdmitted;
      delete this.proforma.courseAdmittedTc;
      delete this.proforma.courseDuration;
      delete this.proforma.yearSemAdmitted;
      delete this.proforma.completedDiscontinued;
      delete this.proforma.monthYearOfAddmn;
      delete this.proforma.yearOfLeaving;
      delete this.proforma.leavingYearSemester;
      delete this.proforma.medium;
      delete this.proforma.whetherQualified;
      delete this.proforma.courseDuration;
      delete this.proforma.faculty;
      delete this.proforma.conduct;
      delete this.proforma.onlineText;
      delete this.proforma.admitNo;
    }

    if(this.proforma.proformaType == 'ADMIT_CARD_CERTIFICATE')
    {
      delete this.proforma.sex;
      delete this.proforma.religion;
      delete this.proforma.community;
      delete this.proforma.dob;
      delete this.proforma.modeOfAdmn;
      delete this.proforma.courseAdmittedTc;
      delete this.proforma.courseDuration;
      delete this.proforma.yearSemAdmitted;
      delete this.proforma.completedDiscontinued;
      delete this.proforma.monthYearOfAddmn;
      delete this.proforma.yearOfLeaving;
      delete this.proforma.leavingYearSemester;
      delete this.proforma.medium;
      delete this.proforma.whetherQualified;
      delete this.proforma.courseDuration;
      delete this.proforma.faculty;
      delete this.proforma.conduct;
      delete this.proforma.onlineText;
      delete this.proforma.studiedIn;
    }

  }

}
