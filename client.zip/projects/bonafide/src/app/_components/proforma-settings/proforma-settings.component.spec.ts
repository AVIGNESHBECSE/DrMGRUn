import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProformaSettingsComponent } from './proforma-settings.component';

describe('ProformaSettingsComponent', () => {
  let component: ProformaSettingsComponent;
  let fixture: ComponentFixture<ProformaSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProformaSettingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProformaSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
