import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proforma-settings',
  templateUrl: './proforma-settings.component.html',
  styleUrls: ['./proforma-settings.component.css']
})
export class ProformaSettingsComponent implements OnInit {
  tab: number = 1;

  constructor() { }

  ngOnInit(): void {
  }

  changeTab(type)
  {
    if(type == 'text-align')
    {
    this.tab = 1;
    }
  }
  
}
