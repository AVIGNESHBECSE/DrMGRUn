import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BonafidepdfComponent } from './bonafidepdf.component';

describe('BonafidepdfComponent', () => {
  let component: BonafidepdfComponent;
  let fixture: ComponentFixture<BonafidepdfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BonafidepdfComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BonafidepdfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
