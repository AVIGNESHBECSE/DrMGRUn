import { Component, OnInit, SystemJsNgModuleLoader } from '@angular/core';
import { LoadingAlertService } from 'projects/admission/src/app/_services/loadingAlert.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie';
import { Common } from 'src/app/common';
import { DatePipe } from '@angular/common';
import { BonafideService } from 'src/services/BonafideService';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-bonafidepdf',
  templateUrl: './bonafidepdf.component.html',
  styleUrls: ['./bonafidepdf.component.css']
})
export class BonafidepdfComponent implements OnInit {
  bonafideData: any;
  id: string;

  userDetail: any;
  fileName: string;
  url: string;
  issueDate: string;
  loanDiv: boolean;
  internDiv: boolean;
  prof4Div: boolean;
  data: string;
  studentName: any;
  refNo: any;
  registerNumber: any;
  currentYear: any;
  bonafide:any = {};
  pronoun1:any;
  pronoun2:any;
  pronoun3:any;
  prof1purpose: any;
  
constructor(private bonafideService:BonafideService,
      private activatedRoute: ActivatedRoute, private cookie : CookieService, private datePipe :DatePipe,
      private router: Router,private route: ActivatedRoute,private loading: LoadingAlertService,private toastr:ToastrService) {}

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get("id");
    this.data = this.activatedRoute.snapshot.paramMap.get("data");
    this.getProformaStudent();
  }

  getProformaStudent(){ 
    this.bonafideService.getProformaStudent(this.id).then((data:any)=>{
    this.bonafideData=data; 
    this.showDivElement();
    this.bonafide = {};
    for(var i=0;i<this.bonafideData.customData.length;i++)
     {
      this.bonafide[this.bonafideData.customData[i].key] = this.bonafideData.customData[i].value;
     }
     if(this.bonafide.gender != undefined)
     {
     this.pronoun1 = this.bonafide.gender.toUpperCase() == 'MALE' ? 'Mr':'Ms';
     this.pronoun2 = this.bonafide.gender.toUpperCase() == 'MALE' ? 'he':'she';
     this.pronoun3 = this.bonafide.gender.toUpperCase() == 'MALE' ? 'him':'her';
     }
    })
  }

  showDivElement()
  {
    this.internDiv = this.bonafideData.purposeOfApplication == 'INTERNSHIP' ||
                     this.bonafideData.purposeOfApplication == 'INPLANT' || 
                     this.bonafideData.purposeOfApplication == 'VOCATIONAL' ||
                     this.bonafideData.purposeOfApplication == 'INDUSTRIAL' ||
                     this.bonafideData.purposeOfApplication == 'PROJECT' && this.data != 'custom' ? true : false;

    this.loanDiv = this.bonafideData.purposeOfApplication == 'EDUCATIONAL_LOAN' && this.data != 'custom' ? true : false;
    
    this.prof4Div = this.data == 'custom' ? true : false;

    this.convertPurpose();
  }

  convertPurpose()
  {
    this.prof1purpose = this.bonafideData.purposeOfApplication == 'INTERNSHIP' ||
    this.bonafideData.purposeOfApplication == 'INPLANT' || 
    this.bonafideData.purposeOfApplication == 'VOCATIONAL' ||
    this.bonafideData.purposeOfApplication == 'INDUSTRIAL' ||
    this.bonafideData.purposeOfApplication == 'PROJECT' && this.data != 'custom' ? this.bonafideData.purposeOfApplication.toLowerCase() : this.bonafideData.purposeOfApplication;
  }

  downloadProforma(){
  this.fileName="Proforma";
  this.data = this.data == 'true' || this.data == 'false' ? this.data : undefined;
  var printId = undefined;
  this.url=Common.URI + '/api/proforma/download/'+this.id+'/'+this.data+'/'+printId+'?token='+this.cookie.get("token");
   fetch(this.url)
  //.then(res => res.blob()) 
  .then(response => {
    if (!response.ok) {
      response.json().then(errorData => {
        this.toastr.warning(errorData.error,'Error',{timeOut:2000});
      });
      throw new Error('Network response was not ok');
    }
    return response.blob();
  })
  .then(blob => {
      const data1 = window.URL.createObjectURL(blob); 
   const link = document.createElement('a');
   link.href = data1; 
   link.target="_blank";
   document.body.appendChild(link)
   link.download= this.fileName + '.pdf';
        link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); 
    link.remove();
  })
  }

  goBack() {   

    if(this.bonafideData.bonafide == 'PROFORMA1' && this.data != 'custom')
    {
      this.data = this.data != null ? this.data : 'true';
      this.router.navigate(['/bonafide/proforma/',this.bonafideData.id,this.data]);
    }
    if(this.bonafideData.bonafide == 'PROFORMA2' && this.data != 'custom')
    {
      this.router.navigate(['/bonafide/proforma-text/',this.bonafideData.id]);
    }
    if(this.data == 'custom')
    {
      this.router.navigate(['/bonafide/proforma4/',this.bonafideData.id]);
    }
  }
 
}