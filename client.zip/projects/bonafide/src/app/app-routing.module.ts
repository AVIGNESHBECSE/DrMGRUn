import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BonafideHodComponent } from './_components/bonafide-hod/bonafide-hod.component';
import { BonafideParentComponent } from './_components/bonafide-parent/bonafide-parent.component';
import { BonafideComponent } from './_components/bonafide/bonafide.component';
import { BonafidepopUpComponent } from './_components/bonafidepop-up/bonafidepop-up.component';
import { BonafidesignComponent } from './_components/bonafidesign/bonafidesign.component';
import { BonafidepdfComponent } from './_components/bonafidepdf/bonafidepdf.component';
import { BonafideEsignPopupComponent } from './_components/bonafide-esign-popup/bonafide-esign-popup.component';
import { ProformaComponent } from './_components/proforma/proforma.component';
import { ProformaViewComponent } from './_components/proforma-view/proforma-view.component';
import { Profoma2Component } from './_components/profoma2/profoma2.component';
import { Proforma3Component } from './_components/proforma3/proforma3.component';
import { Proforma4Component } from './_components/proforma4/proforma4.component';
import { ProformaTextComponent } from './_components/proforma-text/proforma-text.component';
import { ProformaSettingsComponent } from './_components/proforma-settings/proforma-settings.component';
import { ProformaImportComponent } from './_components/proforma-import/proforma-import.component';
import { ProformaTemplateComponent } from './_components/proforma-template/proforma-template.component';
import { ProformaFilterComponent } from './_components/proforma-filter/proforma-filter.component';

const routes: Routes = [
  {path:'', redirectTo:'home',pathMatch:'full'},
  { path: '', component: BonafideParentComponent ,children:[
   { path: 'home', component: BonafideComponent },
   { path: 'hodapproval', component: BonafideHodComponent},
   { path: 'hodapproval/:type/:purpose/:registerNo', component: BonafideHodComponent},
   { path: 'popup', component: BonafidepopUpComponent},
   { path: 'esign', component: BonafidesignComponent},
   { path: 'pdf/:id', component: BonafidepdfComponent},
   { path: 'pdf/:id/:data', component: BonafidepdfComponent},
   { path: 'esignPopup', component: BonafideEsignPopupComponent},
   { path: 'proforma/:type/:purpose/:registerNo', component: ProformaComponent},
   { path: 'proforma/:id/:include', component: ProformaComponent},
   { path: 'proforma2/:type/:purpose/:registerNo', component: Profoma2Component},
   { path: 'proforma2/:id', component: Profoma2Component},
   { path: 'proforma3/:type/:purpose/:registerNo', component: Proforma3Component},
   { path: 'proforma3/:id', component: Proforma3Component},
   { path: 'proforma4/:type/:purpose/:registerNo', component: Proforma4Component},
   { path: 'proforma4/:id', component: Proforma4Component},
   { path: 'proforma-text/:id',component : ProformaTextComponent},
   { path: 'proforma-view/:id', component: ProformaViewComponent},
   { path: 'proforma-settings', component: ProformaSettingsComponent},
   { path: 'proforma-template', component: ProformaTemplateComponent},
   { path: 'proforma-filter', component: ProformaFilterComponent},
   { path: 'proforma-import/:id', component: ProformaImportComponent}
  ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
