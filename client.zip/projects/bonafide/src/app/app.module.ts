import { BrowserModule } from '@angular/platform-browser';
import { ModuleWithProviders, NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { BonafideComponent } from './_components/bonafide/bonafide.component';
import { BonafideParentComponent } from './_components/bonafide-parent/bonafide-parent.component';
import { BonafideHodComponent } from './_components/bonafide-hod/bonafide-hod.component';
import { BonafidepopUpComponent } from './_components/bonafidepop-up/bonafidepop-up.component';
import { BonafidesignComponent } from './_components/bonafidesign/bonafidesign.component';
import { CommonModule, DatePipe } from '@angular/common';
import { CommonNavModule } from 'src/app/common/common-nav.module';
import { HttpClientModule } from '@angular/common/http';
import { NgbAlertModule, NgbModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BonafidepdfComponent } from './_components/bonafidepdf/bonafidepdf.component';
import { BonafideEsignPopupComponent } from './_components/bonafide-esign-popup/bonafide-esign-popup.component';
import { ProformaComponent } from './_components/proforma/proforma.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ProformaViewComponent } from './_components/proforma-view/proforma-view.component';
import { Profoma2Component } from './_components/profoma2/profoma2.component';
import { Proforma3Component } from './_components/proforma3/proforma3.component';
import { Proforma4Component } from './_components/proforma4/proforma4.component';
import { ProformaTextComponent } from './_components/proforma-text/proforma-text.component';
import { ProformaSettingsComponent } from './_components/proforma-settings/proforma-settings.component';
import { CreateGroupComponent } from './_components/proforma-settings/create-group/create-group.component';
import { ProformaImportComponent } from './_components/proforma-import/proforma-import.component';
import { MainPipe } from 'src/app/common/pipe/main-pipe.module';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ProformaTemplateComponent } from './_components/proforma-template/proforma-template.component';
import { TextAlignComponent } from './_components/proforma-settings/text-align/text-align.component';
import { ProformaFilterComponent } from './_components/proforma-filter/proforma-filter.component';


// @NgModule({  declarations: []
// })
// export class BonafideSharedModule {
//   static forRoot(): ModuleWithProviders<any> {
//     return {
//       ngModule: AppModule,
//       providers: []
//     }
//   }
// }
@NgModule({
  declarations: [
    AppComponent,
    BonafideComponent,
    BonafideParentComponent,
    BonafideHodComponent,
    BonafidepopUpComponent,
    BonafidesignComponent,
    BonafidepdfComponent,
    BonafideEsignPopupComponent,
    ProformaComponent,
    ProformaViewComponent,
    Profoma2Component, 
    Proforma3Component,
    Proforma4Component,
    ProformaTextComponent,
    ProformaSettingsComponent,
    CreateGroupComponent,
    ProformaImportComponent,
    ProformaTemplateComponent,
    TextAlignComponent,
    ProformaFilterComponent
  ],
  imports: [
    //BrowserModule,
    AppRoutingModule,
    // HttpClientModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    NgbAlertModule,
    NgbTooltipModule,
    // BrowserAnimationsModule,
    CommonModule,
    CommonNavModule,
    BsDatepickerModule,
    MainPipe,
    MatProgressSpinnerModule
    ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class BonafideModule { }
